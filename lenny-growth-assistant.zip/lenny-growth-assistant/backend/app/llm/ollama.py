"""Ollama provider — talks to a local Ollama server over its HTTP API.

Never silently substitutes another model: errors are raised with an actionable hint.
"""

from __future__ import annotations

import httpx

from ..config import Settings
from ..logging_setup import get_logger
from .base import (
    GenerationRequest,
    GenerationResult,
    LLMProvider,
    ProviderBadResponse,
    ProviderModelMissing,
    ProviderStatus,
    ProviderTimeout,
    ProviderUnavailable,
)

log = get_logger("llm.ollama")


class OllamaProvider(LLMProvider):
    name = "ollama"

    def __init__(self, settings: Settings, transport: httpx.AsyncBaseTransport | None = None) -> None:
        self.base_url = settings.ollama_base_url.rstrip("/")
        self.model = settings.ollama_model
        self.num_ctx = settings.ollama_num_ctx
        self._transport = transport  # injectable for tests

    def _client(self, timeout: float) -> httpx.AsyncClient:
        return httpx.AsyncClient(base_url=self.base_url, timeout=httpx.Timeout(timeout, connect=3.0), transport=self._transport)

    def _unavailable(self, exc: Exception) -> ProviderUnavailable:
        return ProviderUnavailable(
            f"Ollama is not reachable at {self.base_url}.",
            hint=(
                "Start it with `ollama serve` (or open the Ollama app), then retry. "
                "Running the backend in Docker? Set OLLAMA_BASE_URL=http://host.docker.internal:11434."
            ),
            provider=self.name,
        )

    async def generate(self, req: GenerationRequest) -> GenerationResult:
        messages = [{"role": "system", "content": req.system}] + [
            {"role": t.role, "content": t.content} for t in req.turns
        ]
        body = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "options": {"temperature": req.temperature, "num_ctx": self.num_ctx, "num_predict": req.max_tokens},
        }
        try:
            async with self._client(req.timeout_s) as client:
                resp = await client.post("/api/chat", json=body)
        except httpx.TimeoutException as exc:
            if isinstance(exc, httpx.ConnectTimeout):
                raise self._unavailable(exc) from exc
            raise ProviderTimeout(
                f"Ollama did not finish within {int(req.timeout_s)}s.",
                hint="Try a smaller model, shorten the request, or raise LLM_TIMEOUT_SECONDS.",
                provider=self.name,
            ) from exc
        except (httpx.ConnectError, httpx.NetworkError, httpx.RemoteProtocolError) as exc:
            raise self._unavailable(exc) from exc

        if resp.status_code == 404:
            raise ProviderModelMissing(
                f"Model '{self.model}' is not installed in Ollama.",
                hint=f"Run `ollama pull {self.model}` or set OLLAMA_MODEL to a model you have (`ollama list`).",
                provider=self.name,
            )
        if resp.status_code != 200:
            log.warning("ollama non-200", extra={"status": resp.status_code, "body": resp.text[:300]})
            raise ProviderBadResponse(
                f"Ollama returned HTTP {resp.status_code}.",
                hint="Check the Ollama server logs.",
                provider=self.name,
            )
        try:
            data = resp.json()
            text = data["message"]["content"]
        except (ValueError, KeyError, TypeError) as exc:
            raise ProviderBadResponse("Ollama returned an unexpected response shape.", provider=self.name) from exc
        return GenerationResult(
            text=text.strip(),
            provider=self.name,
            model=self.model,
            usage={"prompt_tokens": data.get("prompt_eval_count"), "completion_tokens": data.get("eval_count")},
        )

    async def status(self) -> ProviderStatus:
        def mk(ready: bool, detail: str, hint: str | None = None) -> ProviderStatus:
            return ProviderStatus(name=self.name, model=self.model, ready=ready, detail=detail, hint=hint, kind="local", agentic=False)

        try:
            async with self._client(2.5) as client:
                resp = await client.get("/api/tags")
            resp.raise_for_status()
            installed = [m.get("name", "") for m in resp.json().get("models", [])]
        except (httpx.HTTPError, ValueError):
            return mk(False, f"Ollama not reachable at {self.base_url}", "Start Ollama (`ollama serve`) and make sure OLLAMA_BASE_URL is correct.")
        wanted = {self.model, f"{self.model}:latest"}
        if not any(n in wanted or n.split(":")[0] == self.model for n in installed):
            return mk(False, f"Ollama is running but '{self.model}' is not installed", f"Run `ollama pull {self.model}`.")
        return mk(True, f"Ollama running; {self.model} installed")
