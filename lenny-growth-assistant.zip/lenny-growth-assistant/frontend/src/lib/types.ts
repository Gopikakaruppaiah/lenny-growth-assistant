export type ProviderName = "ollama" | "anthropic";
export type MessageKind = "chat" | "essay" | "artifact";
export type MessageStatus = "pending" | "complete" | "error";

export interface Source {
  n: number;
  chunk_id: number;
  slug: string;
  guest: string;
  title: string;
  publish_date: string | null;
  youtube_url: string | null;
  deep_link: string | null;
  transcript_url: string | null;
  timestamp_label: string | null;
  snippet: string;
  cited: boolean;
  score: number;
}

export interface ArtifactRef { id: string; kind: "markdown" | "html"; title: string }

export interface QualityCheck { name: string; passed: boolean; detail: string }

export interface Message {
  id: string;
  session_id: string;
  role: "user" | "assistant";
  kind: MessageKind;
  status: MessageStatus;
  content: string;
  provider: ProviderName | null;
  model: string | null;
  fallback_from: ProviderName | null;
  sources: Source[];
  meta: {
    grounded?: boolean;
    verdict?: string | null;
    word_count?: number;
    target_words?: number;
    meets_target?: boolean;
    quality_checks?: QualityCheck[];
    citation_warnings?: string[];
    model_called?: boolean;
    [k: string]: unknown;
  };
  error: { code: string; message: string; hint?: string | null } | null;
  artifact: ArtifactRef | null;
  latency_ms: number | null;
  created_at: string;
  completed_at: string | null;
}

export interface Session { id: string; title: string; created_at: string; updated_at: string; message_count: number }

export interface Artifact {
  id: string; session_id: string; message_id: string | null; kind: "markdown" | "html"; title: string; content: string;
  provider: string | null; model: string | null; sanitizer_report: Record<string, unknown>; created_at: string;
}

export interface ProviderStatus {
  name: ProviderName; model: string; kind: "local" | "cloud"; ready: boolean; detail: string; hint?: string | null;
  agentic: boolean; is_default: boolean; is_fallback: boolean;
}
export interface ProvidersResponse { default: ProviderName; fallback: string | null; providers: ProviderStatus[] }

export interface Accepted { user_message: Message; assistant_message: Message; routed_as: MessageKind }

export interface CorpusStats { episodes: number; chunks: number; last_ingested_at: string | null; source_repo: string | null; source_commit: string | null }
