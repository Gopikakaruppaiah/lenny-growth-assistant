"""Ranked retrieval over the PostgreSQL full-text index, with attribution and a sufficiency gate."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession

from ..logging_setup import get_logger
from .query import BuiltQuery, build_query

log = get_logger("retrieval")


def format_timestamp(seconds: int | None) -> str | None:
    if seconds is None:
        return None
    h, rem = divmod(int(seconds), 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


@dataclass
class SourceRef:
    chunk_id: int
    slug: str
    guest: str
    title: str
    publish_date: str | None
    youtube_url: str | None
    deep_link: str | None  # YouTube URL jumping to the passage, when timestamps exist
    transcript_url: str | None  # commit-pinned file in the source repo (verifiable)
    start_seconds: int | None
    timestamp_label: str | None
    text: str
    score: float
    n: int = 0  # citation number, assigned by SourceRegistry
    cited: bool = False

    def to_public(self, snippet_chars: int = 700) -> dict[str, Any]:
        d = asdict(self)
        body = d.pop("text")
        d["snippet"] = body if len(body) <= snippet_chars else body[:snippet_chars].rsplit(" ", 1)[0] + "…"
        return d


@dataclass
class SourceRegistry:
    """Per-request source numbering shared by retrieval and the agent's search tool."""

    items: list[SourceRef] = field(default_factory=list)

    def add(self, ref: SourceRef) -> SourceRef:
        for existing in self.items:
            if existing.chunk_id == ref.chunk_id:
                return existing
        ref.n = len(self.items) + 1
        self.items.append(ref)
        return ref

    def get(self, n: int) -> SourceRef | None:
        return self.items[n - 1] if 1 <= n <= len(self.items) else None


@dataclass
class RetrievalResult:
    sources: list[SourceRef]
    query: BuiltQuery
    sufficient: bool
    best_coverage: float
    reason: str


_SQL = text(
    """
    SELECT c.id AS chunk_id, c.text, c.start_seconds, d.slug, d.guest, d.title, d.publish_date,
           d.youtube_url, d.source_repo, d.source_commit, d.source_path,
           ts_rank_cd(c.tsv, q.query, 32) AS score
    FROM transcript_chunks c
    JOIN transcript_documents d ON d.id = c.document_id,
         to_tsquery('english', :tsq) AS q(query)
    WHERE c.tsv @@ q.query
    ORDER BY score DESC
    LIMIT :pool
    """
)


def _deep_link(url: str | None, start: int | None) -> str | None:
    if not url:
        return None
    if start is None:
        return url
    sep = "&" if "?" in url else "?"
    return f"{url}{sep}t={int(start)}s"


def _transcript_url(repo: str, commit: str | None, path: str) -> str | None:
    if not repo.startswith("http") or not commit:
        return None
    return f"{repo.rstrip('/')}/blob/{commit}/{path}"


def _coverage(chunk_text: str, terms: list[str]) -> float:
    if not terms:
        return 0.0
    low = chunk_text.lower()
    hit = 0
    for t in terms:
        stem = t[:5] if len(t) > 5 else t  # crude prefix stem: "retention" ~ "retain"? no, "reten"
        if stem in low:
            hit += 1
    return hit / len(terms)


async def retrieve(
    session: AsyncSession,
    message: str,
    previous_user_messages: list[str] | None = None,
    *,
    top_k: int = 8,
    max_per_episode: int = 2,
    min_coverage: float = 0.5,
    registry: SourceRegistry | None = None,
) -> RetrievalResult:
    built = build_query(message, previous_user_messages)
    if not built.tsquery:
        return RetrievalResult([], built, False, 0.0, "no_searchable_terms")

    rows = (await session.execute(_SQL, {"tsq": built.tsquery, "pool": top_k * 6})).mappings().all()
    picked: list[SourceRef] = []
    per_episode: dict[str, int] = {}
    for r in rows:
        if per_episode.get(r["slug"], 0) >= max_per_episode:
            continue
        per_episode[r["slug"]] = per_episode.get(r["slug"], 0) + 1
        ref = SourceRef(
            chunk_id=r["chunk_id"],
            slug=r["slug"],
            guest=r["guest"],
            title=r["title"],
            publish_date=r["publish_date"].isoformat() if r["publish_date"] else None,
            youtube_url=r["youtube_url"],
            deep_link=_deep_link(r["youtube_url"], r["start_seconds"]),
            transcript_url=_transcript_url(r["source_repo"], r["source_commit"], r["source_path"]),
            start_seconds=r["start_seconds"],
            timestamp_label=format_timestamp(r["start_seconds"]),
            text=r["text"],
            score=float(r["score"]),
        )
        picked.append(registry.add(ref) if registry else ref)
        if len(picked) >= top_k:
            break

    if not picked:
        return RetrievalResult([], built, False, 0.0, "no_matches")

    best = max(_coverage(s.text, built.focus_terms) for s in picked)
    if best < min_coverage:
        log.info("retrieval insufficient", extra={"best_coverage": round(best, 2), "terms": built.focus_terms})
        return RetrievalResult(picked, built, False, best, "low_coverage")
    if not registry:
        for i, s in enumerate(picked, 1):
            s.n = i
    return RetrievalResult(picked, built, True, best, "ok")
