# Design

## Direction
A calm, editorial research tool rather than a generic chat template: warm paper background, ink-black text, **one** accent
(burnt orange), and a serif display face (Iowan Old Style/Palatino/Georgia stack — no web-font dependency) for headings and
documents, with the system UI font for controls. Sources, provenance and honesty badges are first-class visual elements.

## Information architecture
```
┌ Sidebar (nav: "Chat history") ┬ Topbar: title · provider pill ─────────────┐
│ Brand                         ├ Banner (API-level errors)                    │
│ + New chat                    ├ Chat (log)                 │ Artifact viewer │
│ History (sessions)            │  messages · sources        │ (aside)         │
│ Attribution footer            │  composer: Send · Essay ·  │ Preview|Source  │
│                               │            Create artifact │ Copy · Download │
└───────────────────────────────┴────────────────────────────┴─────────────────┘
```
Landmarks: `nav`, `main`, `section[aria-label=Conversation]` (`role=log`, `aria-live=polite`), `aside[aria-label=Artifact viewer]`.

## Responsive behaviour
| Width | Layout |
|---|---|
| ≥ 1181 px | sidebar 276 px · chat · viewer side-by-side when something is open |
| 901–1180 px | narrower sidebar; chat/viewer share space (min 320/360) |
| ≤ 900 px | sidebar becomes a drawer (☰); chat and viewer become **tabs** at the bottom ("Chat" / "Artifact"); safe-area insets respected |
| ≤ 520 px | composer actions stack full-width; dialog options single column |

## Components and states
| Component | States designed |
|---|---|
| Message (assistant) | pending (animated dots + elapsed seconds + hint for long essays) · complete · error (message, hint, code, **Retry**) |
| Badges | `Ollama (local)` · `Claude (cloud)` · `Fallback — X was unavailable` (amber) · `No model used` · `Grounded · n cited` · `Not grounded in transcripts` |
| Sources | cited vs "also retrieved"; expandable quote, guest, episode, timestamp, "Watch at m:ss ↗", commit-pinned transcript link; citation chips `[n]` scroll/open the source |
| Essay card | headline, word count vs target (✓ / outside ±10 %), 8-check list with ✓/✕ and screen-reader text, Open · Copy · Download |
| Artifact viewer | empty · loading · error + Try again · Markdown preview · HTML preview (sandboxed) · Source tab · copy/download · safety note |
| Provider menu | readiness dot, per-provider detail & hint, server-default option, Esc/outside-click to close |
| Empty chat | headline, corpus stats ("303 episodes · 19,038 passages · source be8ab89"), four starter prompts; **empty-knowledge-base warning** with the ingest command |
| Composer | Enter sends, Shift+Enter newline, auto-grow, 4,000-char limit with counter, disabled while a reply is pending |

## Accessibility
* Text/background pairs chosen for ≥ 4.5:1 in light and dark themes (`prefers-color-scheme`); accent on white ≈ 5.6:1.
* Visible 3 px focus ring on all controls; full keyboard path (sidebar → composer → actions → dialog → viewer tabs).
* Dialog is `role=dialog aria-modal`, focuses its textarea, closes with Esc; menu uses `menuitemradio`; tabs use `role=tab`/`aria-selected`.
* Status changes announced via `role=status`/`aria-live`; errors use `role=alert`; icons are `aria-hidden` with text alternatives.
* `prefers-reduced-motion` disables animation. Colour is never the only signal (✓/✕ glyphs, labels).
* The sandboxed iframe has a descriptive `title`.
* Not yet verified: screen-reader pass with real assistive tech and an automated axe audit (no browser in the build environment).

## Visual tokens
Light: bg `#faf7f2`, surface `#fff`, ink `#1c1917`, muted `#5f5850`, accent `#b83c0a`. Dark: bg `#14120f`, ink `#f4efe6`, accent `#fb9a4f`.
Provider hues: local = teal, cloud = violet (so provenance is visible at a glance, independent of the accent). Radius 14 px; one soft shadow.
