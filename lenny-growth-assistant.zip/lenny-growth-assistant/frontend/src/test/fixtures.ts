import { vi } from "vitest";
import type { Message, ProvidersResponse, Session, Source } from "../lib/types";

export const now = "2026-10-10T10:00:00Z";
export const SID = "11111111-1111-4111-8111-111111111111";

export const providers: ProvidersResponse = {
  default: "ollama", fallback: null,
  providers: [
    { name: "ollama", model: "llama3.2:3b", kind: "local", ready: true, detail: "Ollama running; llama3.2:3b installed", agentic: false, is_default: true, is_fallback: false },
    { name: "anthropic", model: "claude-sonnet-5-5", kind: "cloud", ready: false, detail: "ANTHROPIC_API_KEY is not set", hint: "Add ANTHROPIC_API_KEY to the backend environment to enable Claude.", agentic: true, is_default: false, is_fallback: false },
  ],
};

export const source: Source = {
  n: 1, chunk_id: 7, slug: "a", guest: "Test Guest Alpha", title: "Synthetic episode", publish_date: "2024-01-15",
  youtube_url: "https://www.youtube.com/watch?v=AAAAAAAAAAA", deep_link: "https://www.youtube.com/watch?v=AAAAAAAAAAA&t=60s",
  transcript_url: null, timestamp_label: "1:00", snippet: "Activation is the moment a user first experiences value.", cited: true, score: 0.5,
};

export function msg(over: Partial<Message>): Message {
  return {
    id: "m-" + Math.random().toString(36).slice(2), session_id: SID, role: "assistant", kind: "chat", status: "complete", content: "",
    provider: "ollama", model: "llama3.2:3b", fallback_from: null, sources: [], meta: {}, error: null, artifact: null,
    latency_ms: 1200, created_at: now, completed_at: now, ...over,
  };
}
export const session = (over: Partial<Session> = {}): Session => ({ id: SID, title: "New chat", created_at: now, updated_at: now, message_count: 0, ...over });

type Handler = (url: URL, init: RequestInit) => unknown | { __status: number; body: unknown } | Promise<unknown>;
/** Route-table fetch mock. Keys are "METHOD /path-after-/api/v1". */
export function mockApi(routes: Record<string, Handler>) {
  const calls: { key: string; init: RequestInit }[] = [];
  const fn = vi.fn(async (input: RequestInfo | URL, init: RequestInit = {}) => {
    const url = new URL(String(input));
    const key = `${(init.method ?? "GET").toUpperCase()} ${url.pathname.replace("/api/v1", "")}`;
    calls.push({ key, init });
    const h = routes[key];
    if (!h) return new Response(JSON.stringify({ error: { code: "not_found", message: `no mock for ${key}` } }), { status: 404 });
    const out = (await h(url, init)) as { __status?: number; body?: unknown };
    if (out && typeof out === "object" && "__status" in out) {
      return out.__status === 204 ? new Response(null, { status: 204 }) : new Response(JSON.stringify(out.body), { status: out.__status });
    }
    return new Response(JSON.stringify(out), { status: 200 });
  });
  vi.stubGlobal("fetch", fn);
  return { fn, calls };
}
