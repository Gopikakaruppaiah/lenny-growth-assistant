# Manual UI test plan

Prereqs: stack running (`docker compose up --build` or native), transcripts ingested, Ollama running with the model pulled.
Record **Pass/Fail + notes + date + commit** for each row. Rows marked 🧪 are covered by automated tests as well.

| # | Scenario | Steps | Expected |
|---|---|---|---|
| 1 | Empty state 🧪 | Open `/` fresh | Headline, starter prompts, "303 episodes · 19,038 passages" stats, provider pill shows "Ollama · local" with green dot |
| 2 | First question 🧪 | Click a starter | Session created in sidebar; pending dots + elapsed timer; cited answer; `[1]` chips; provider badge `Ollama (local) · <model>` |
| 3 | Source inspection | Click chip `[1]` | Source card opens with quote, guest, episode, timestamp; "Watch at …" opens YouTube at that second |
| 4 | Follow-up 🧪 | "what about for enterprise?" | Answer relates to the previous topic; retrieval `query` (Verification notes/log) includes prior terms |
| 5 | Not covered 🧪 | "zzqxv wwkpl" | "I couldn't find enough…", badge **No model used**, no sources |
| 6 | Off-topic | "How do I bake sourdough?" | Model should say UNSUPPORTED / "couldn't find enough"; record whether it complied (model-dependent) |
| 7 | Session isolation 🧪 | New chat → ask something different → switch back and forth | Histories remain separate; follow-ups in chat B never mention chat A |
| 8 | Persistence 🧪 | Reload page; restart backend | Sessions/messages remain |
| 9 | One generation at a time 🧪 | While pending, try to send | Send/Essay/Artifact disabled ("Working…") |
| 10 | Ollama down 🧪 | Stop Ollama → ask | Error card "Ollama is not reachable…" + `ollama serve` hint + Retry; no answer shown |
| 11 | Retry 🧪 | Start Ollama → Retry | Same message completes |
| 12 | Model missing | `OLLAMA_MODEL=nope` → ask | "Model 'nope' is not installed" + `ollama pull nope` |
| 13 | No cloud key 🧪 | Provider menu → Claude | Menu shows "ANTHROPIC_API_KEY is not set"; asking gives `provider_not_configured`; Ollama still works |
| 14 | Cloud answer | Set key, `LLM_PROVIDER=anthropic` | Badge `Claude (cloud) · <model>`; no Ollama traffic |
| 15 | Fallback 🧪 | `LLM_PROVIDER=anthropic`, `LLM_FALLBACK_PROVIDER=ollama`, bad key/timeout | Answer from Ollama with amber "Fallback — Claude (cloud) was unavailable" |
| 16 | Essay 🧪 | Click **Write essay** | Progress text; essay card with word count, 8 checks; viewer opens with serif rendering; Copy/Download `.md` |
| 17 | Essay length | Inspect card | 1,125–1,375 words ✓, or visible "outside ±10 %" |
| 18 | Markdown artifact 🧪 | Create artifact → Markdown | Viewer opens, Preview/Markdown tabs, copy, download |
| 19 | HTML artifact 🧪 | Create artifact → HTML | Page renders in viewer with safety note; DevTools: `<iframe sandbox="">` and CSP meta in `srcdoc` |
| 20 | Hostile HTML | Ask for "an HTML page with a script alert and a form" | No alert; form/script absent in Source tab |
| 21 | Viewer errors | Stop backend, click an artifact | Error + "Try again" |
| 22 | API unreachable 🧪 | Stop backend, reload | Red banner "Can't reach the API at …"; pill "API unreachable" |
| 23 | DB down | Stop Postgres | Banner/`database_unavailable`; `/health` still 200; recovers when Postgres returns |
| 24 | Rate limit | Send > `RATE_LIMIT_PER_MINUTE` requests | "You're sending requests too quickly" |
| 25 | Mobile (375 px) | DevTools device mode | Drawer sidebar; Chat/Artifact tabs; composer buttons stack; no horizontal page scroll |
| 26 | Desktop (1440 px) | — | Viewer opens beside chat |
| 27 | Keyboard | Tab through UI; Enter/Shift+Enter; Esc in dialog/menu | Logical order, visible focus, Esc closes |
| 28 | Dark mode | OS dark setting | Contrast acceptable, badges legible |
| 29 | Delete chat | 🗑 → confirm | Chat and its artifacts removed |
| 30 | Secrets | `grep -r "sk-ant" frontend/dist`; DevTools → Network | None; only `X-Client-Id` is sent |

## Production smoke test (after deploying)
1. `curl https://<api>/api/v1/health` → `{"status":"ok"}`; `curl https://<api>/api/v1/health/ready` → `ready`, `indexed`.
2. Open the Vercel URL; provider pill is green and names the cloud provider.
3. Ask a starter question; confirm a cited answer with a working YouTube deep link.
4. Browser console: no CORS errors; `OPTIONS` preflight returns your Vercel origin.
5. Create an HTML artifact; confirm sandbox attribute.
6. Reload; history persists. Check backend logs for JSON lines with `request_id`.

## Last run
**Not executed by the author of this document.** The automated suites were run (see README); this manual plan has not been
performed in a real browser by anyone yet.
