import shutil
import uuid

import pytest
from sqlalchemy import create_engine, text

from app.llm.base import ChatTurn, GenerationRequest, ProviderAuthError, ProviderBadResponse, ProviderRateLimited, ProviderTimeout
from app.llm.claude_agent import TOOL_FQN, ClaudeAgentProvider
from app.skills import ship30
from app.skills.sanitize import sanitize_css, sanitize_html_document, sanitize_markdown

from .conftest import FIXTURES, TEST_DB_URL, build_harness, close_harness, make_settings
from .fakes import FakeOllama, sdk_stream

pytestmark = pytest.mark.asyncio(loop_scope="session")
API = "/api/v1"


# ------------------------------------------------------------------ essay skill
async def test_essay_skill_end_to_end(h):
    sid = await h.new_session()
    r = await h.client.post(f"{API}/sessions/{sid}/essay", json={"topic": "onboarding and activation"}, headers=h.headers())
    assert r.status_code == 202
    m = await h.wait(sid, r.json()["assistant_message"]["id"])
    assert m["status"] == "complete" and m["kind"] == "essay", m
    meta = m["meta"]
    assert meta["skill"] == "ship30@1.0" and meta["target_words"] == 1250
    assert 1125 <= meta["word_count"] <= 1375 and meta["meets_target"] is True
    checks = {c["name"]: c["passed"] for c in meta["quality_checks"]}
    assert checks["length"] and checks["headings"] and checks["bullets"] and checks["takeaway"] and checks["selective_bold"]
    md = m["content"]
    assert md.startswith("# 3 lessons PMs can steal") and "## Lesson 1: Start with activation" in md and "## Sources" in md
    assert all(s["cited"] for s in m["sources"]) and [s["n"] for s in m["sources"]] == list(range(1, len(m["sources"]) + 1))
    assert "Test Guest" in md.split("## Sources")[1]


async def test_essay_length_correction_loop_runs_when_too_short():
    def short(msgs):
        system = msgs[0]["content"]
        if "PLAN the essay" in system:
            return "HEADLINE: H\nANGLE: actionable\nAPPROACH: Steps\nSECTION 1: A | a\nSECTION 2: B | b\nSECTION 3: C | c"
        if "Revise one part" in system:
            return " ".join(["expanded"] * 400) + " [1]"
        return "Short text [1][2]."
    o = FakeOllama(short)
    h = await build_harness(ollama=o)
    try:
        sid = await h.new_session()
        r = await h.client.post(f"{API}/sessions/{sid}/essay", json={"topic": "onboarding and activation"}, headers=h.headers())
        m = await h.wait(sid, r.json()["assistant_message"]["id"])
        assert m["meta"]["corrections"], "expected at least one length-correction pass"
        assert "## Step 1: A" in m["content"]
        assert m["meta"]["meets_target"] is False or m["meta"]["word_count"] >= 1125
    finally:
        await close_harness(h)


async def test_essay_unparseable_plan_uses_flagged_fallback():
    o = FakeOllama(lambda msgs: "just prose, no plan lines" if "PLAN the essay" in msgs[0]["content"] else "Body text [1][2].")
    h = await build_harness(ollama=o)
    try:
        sid = await h.new_session()
        r = await h.client.post(f"{API}/sessions/{sid}/essay", json={"topic": "onboarding and activation"}, headers=h.headers())
        m = await h.wait(sid, r.json()["assistant_message"]["id"])
        assert m["meta"]["essay_plan"]["fallback_plan"] is True and any("could not be parsed" in w for w in m["meta"]["citation_warnings"])
    finally:
        await close_harness(h)


async def test_essay_refuses_when_evidence_is_insufficient(h):
    sid = await h.new_session()
    h.ollama.calls.clear()
    r = await h.client.post(f"{API}/sessions/{sid}/essay", json={"topic": "zzqxv wwkpl"}, headers=h.headers())
    m = await h.wait(sid, r.json()["assistant_message"]["id"])
    assert m["status"] == "complete" and "couldn't find enough" in m["content"] and m["meta"]["grounded"] is False
    assert h.ollama.calls == []


async def test_essay_defaults_to_last_question_and_requires_a_topic(h):
    sid = await h.new_session()
    assert (await h.client.post(f"{API}/sessions/{sid}/essay", json={}, headers=h.headers())).json()["error"]["code"] == "topic_required"
    await h.ask(sid, "How does onboarding drive activation?")
    r = await h.client.post(f"{API}/sessions/{sid}/essay", json={}, headers=h.headers())
    assert r.status_code == 202 and "onboarding" in r.json()["user_message"]["content"].lower()
    await h.wait(sid, r.json()["assistant_message"]["id"])


async def test_typing_an_essay_request_is_routed_to_the_skill(h):
    sid = await h.new_session()
    m = await h.ask(sid, "write a 1250 word essay on onboarding and activation")
    assert m["kind"] == "essay" and m["status"] == "complete"


def test_essay_checks_and_renumbering():
    from app.rag.retrieval import SourceRef, SourceRegistry
    reg = SourceRegistry()
    for i in range(1, 6):
        reg.add(SourceRef(i, f"s{i}", f"G{i}", f"T{i}", None, None, None, None, 0, "0:00", "x", 1.0))
    text_, refs = ship30.renumber_citations("A [4]. B [2][4]. C [5].", reg)
    assert text_ == "A [1]. B [2][1]. C [3]." and [r.guest for r in refs] == ["G4", "G2", "G5"] and all(r.cited for r in refs)
    checks = {c["name"]: c["passed"] for c in ship30.check_essay("# T\n\ntiny", 10, [])}
    assert not checks["length"] and not checks["headings"] and not checks["citations"]


# ------------------------------------------------------------------ artifacts + security
async def _make_artifact(h, sid, kind, instruction="onboarding and activation playbook"):
    r = await h.client.post(f"{API}/sessions/{sid}/artifacts", json={"kind": kind, "instruction": instruction}, headers=h.headers())
    assert r.status_code == 202, r.text
    return await h.wait(sid, r.json()["assistant_message"]["id"])


async def test_markdown_and_html_artifacts_are_generated_and_retrievable(h):
    sid = await h.new_session()
    md = await _make_artifact(h, sid, "markdown")
    assert md["status"] == "complete" and md["artifact"]["kind"] == "markdown" and md["artifact"]["title"] == "Onboarding checklist"
    html = await _make_artifact(h, sid, "html", "an HTML one-pager on onboarding and activation")
    assert html["artifact"]["kind"] == "html"
    art = (await h.client.get(f"{API}/artifacts/{html['artifact']['id']}", headers=h.headers())).json()
    assert art["content"].startswith("<!doctype html>") and "Onboarding" in art["content"] and art["provider"] == "ollama"
    listed = (await h.client.get(f"{API}/sessions/{sid}/artifacts", headers=h.headers())).json()
    assert len(listed) == 2
    msgs = (await h.client.get(f"{API}/sessions/{sid}/messages", headers=h.headers())).json()
    assert [m["artifact"]["kind"] for m in msgs if m.get("artifact")] == ["markdown", "html"]


EVIL = ('<!doctype html><html><head><title>x</title><script>alert(1)</script><style>@import url(http://e.test/a.css);'
        'body{background:url(http://e.test/p.png)}</style></head><body onload="alert(2)"><h1 onclick="x()">Hi</h1>'
        '<a href="javascript:alert(3)">l</a><img src="http://e.test/i.png" onerror="alert(4)"><iframe src="http://e.test"></iframe>'
        '<form action="http://e.test"><input></form><svg onload="alert(5)"></svg></body></html>')


async def test_hostile_model_output_is_neutralised_before_storage():
    o = FakeOllama(lambda m: EVIL if "Create this artifact" in m[-1]["content"] else "[[VERDICT: SUPPORTED]]\nok [1]")
    h = await build_harness(ollama=o)
    try:
        sid = await h.new_session()
        m = await _make_artifact(h, sid, "html", "html page about onboarding and activation")
        stored = (await h.client.get(f"{API}/artifacts/{m['artifact']['id']}", headers=h.headers())).json()
        for bad in ["<script", "onload", "onclick", "onerror", "javascript:", "e.test", "<iframe", "<form", "<svg", "@import"]:
            assert bad not in stored["content"].lower(), bad
        assert stored["sanitizer_report"]["external_urls_removed"] >= 2
    finally:
        await close_harness(h)


async def test_artifacts_are_private_to_their_owner(h):
    sid = await h.new_session()
    m = await _make_artifact(h, sid, "markdown")
    aid = m["artifact"]["id"]
    assert (await h.client.get(f"{API}/artifacts/{aid}", headers=h.headers(uuid.uuid4().hex))).status_code == 404
    assert (await h.client.get(f"{API}/artifacts/{uuid.uuid4()}", headers=h.headers())).status_code == 404


async def test_artifact_with_no_evidence_is_refused(h):
    sid = await h.new_session()
    m = await _make_artifact(h, sid, "html", "zzqxv wwkpl page")
    assert m["status"] == "complete" and m["artifact"] is None and "couldn't find enough" in m["content"]


async def test_artifact_validation(h):
    sid = await h.new_session()
    for body in [{"kind": "pdf", "instruction": "abc def"}, {"kind": "html", "instruction": "x"}, {"kind": "html"}]:
        assert (await h.client.post(f"{API}/sessions/{sid}/artifacts", json=body, headers=h.headers())).status_code == 422


@pytest.mark.parametrize("payload,needle", [
    ("<script>alert(1)</script><p>a</p>", "<script"),
    ('<p onmouseover="x()">a</p>', "onmouseover"),
    ('<a href="JaVaScRiPt:alert(1)">a</a>', "javascript"),
    ('<a href="  javascript:alert(1)">a</a>', "javascript"),
    ('<a href="data:text/html;base64,PHNjcmlwdD4=">a</a>', "data:text"),
    ('<img src=x onerror=alert(1)>', "onerror"),
    ('<meta http-equiv="refresh" content="0;url=http://e.test">', "refresh"),
    ('<base href="http://e.test/">', "<base"),
    ('<link rel=stylesheet href="http://e.test/a.css">', "<link"),
    ('<object data="x"></object><embed src="x">', "<embed"),
    ('<svg><script>alert(1)</script></svg>', "<svg"),
    ('<math><mi xlink:href="javascript:alert(1)">x</mi></math>', "<math"),
    ('<div style="width:expression(alert(1))">a</div>', "expression"),
    ('<div style="behavior:url(x.htc)">a</div>', "behavior"),
    ('<style>@import "http://e.test/x.css";</style><p>a</p>', "@import"),
    ('<style>p{background:url(\'http://e.test/x\')}</style>', "e.test"),
    ('<form action="http://e.test"><button>go</button></form>', "<form"),
    ('<iframe srcdoc="<script>alert(1)</script>"></iframe>', "srcdoc"),
    ('<p>x</p><!--[if IE]><script>alert(1)</script><![endif]-->', "<script"),
    ('<noscript><img src=x onerror=alert(1)></noscript>', "onerror"),
    ('<template><script>alert(1)</script></template>', "<script"),
    ('<style></style><script>alert(1)</script>', "<script"),
])
def test_sanitizer_blocks_known_xss_and_exfil_vectors(payload, needle):
    doc, _, _ = sanitize_html_document(payload)
    assert needle not in doc.lower()


def test_sanitizer_keeps_legitimate_content_and_css():
    doc, title, rep = sanitize_html_document(
        "<html><head><title>My Page</title><style>.card > h2{color:#123;display:grid}</style></head>"
        "<body><section class='card'><h2>Title</h2><ul><li><b>one</b></li></ul><table><tr><td>1</td></tr></table>"
        "<a href='https://ok.example/p'>link</a><img alt='d' src='data:image/png;base64,iVBORw0KGgo='></section></body></html>")
    assert title == "My Page" and ".card > h2{color:#123;display:grid}" in doc
    assert "<table>" in doc and "<li><b>one</b></li>" in doc and 'href="https://ok.example/p"' in doc and "data:image/png;base64" in doc
    assert 'rel="noopener noreferrer nofollow"' in doc


def test_sanitizer_truncates_oversized_input_and_escapes_title():
    doc, title, rep = sanitize_html_document("<title><img src=x></title>" + "<p>a</p>" * 60000)
    assert rep.truncated and "<img" not in title and len(doc) < 260_000
    doc2, _, _ = sanitize_html_document("<p>x</p>", fallback_title="<script>alert(1)</script>")
    assert "<script" not in doc2


def test_css_filter_edge_cases():
    out = sanitize_css("a{background:url(javascript:alert(1));color:red}b{content:'url('}c{background:URL ( 'x' )}")
    assert "javascript" not in out and "color:red" in out and "url" not in out.lower().replace("content:'url('", "")


def test_markdown_scrub():
    out, rep = sanitize_markdown("# T\n<script>x</script>\n[a](javascript:alert(1)) [b](https://ok.example)")
    assert "<script" not in out and "javascript:" not in out and "https://ok.example" in out and rep.removed_tags == 1 and rep.removed_urls == 1


# ------------------------------------------------------------------ Claude Agent SDK adapter
def _req(tool=False):
    async def search(q):
        return "x"
    return GenerationRequest(system="sys", turns=[ChatTurn("user", "hello")], timeout_s=1.0, search_tool=search if tool else None)


async def test_agent_provider_success_and_locked_down_options(anthropic_settings):
    q = sdk_stream(text="hi there", tool_uses=2)
    p = ClaudeAgentProvider(anthropic_settings, query_fn=q)
    res = await p.generate(_req(tool=True))
    assert res.text == "hi there" and res.provider == "anthropic" and res.tool_calls == 2 and res.usage["cost_usd"] == 0.01
    o = q.last_options
    assert o.tools == [] and o.allowed_tools == [TOOL_FQN] and o.setting_sources == [] and o.permission_mode == "dontAsk"
    assert o.max_budget_usd == anthropic_settings.anthropic_max_budget_usd and list(o.mcp_servers) == ["lenny"]
    assert o.env["ANTHROPIC_API_KEY"].startswith("sk-ant-")


async def test_agent_provider_without_tool_has_no_mcp_server_and_one_turn(anthropic_settings):
    q = sdk_stream(text="ok")
    await ClaudeAgentProvider(anthropic_settings, query_fn=q).generate(_req(tool=False))
    assert q.last_options.mcp_servers == {} and q.last_options.allowed_tools == [] and q.last_options.max_turns == 1


@pytest.mark.parametrize("kw,exc", [
    ({"error": "rate_limit"}, ProviderRateLimited),
    ({"error": "authentication_failed"}, ProviderAuthError),
    ({"error": "billing_error"}, ProviderAuthError),
    ({"result_error": {"is_error": True, "api_error_status": 429}}, ProviderRateLimited),
    ({"result_error": {"is_error": True, "api_error_status": 401}}, ProviderAuthError),
    ({"result_error": {"is_error": True, "subtype": "error_max_budget_usd"}}, ProviderBadResponse),
    ({"text": "  ", "result_error": {"result": ""}}, ProviderBadResponse),
])
async def test_agent_provider_error_mapping(anthropic_settings, kw, exc):
    with pytest.raises(exc):
        await ClaudeAgentProvider(anthropic_settings, query_fn=sdk_stream(**kw)).generate(_req())


async def test_agent_provider_timeout(anthropic_settings):
    with pytest.raises(ProviderTimeout):
        await ClaudeAgentProvider(anthropic_settings, query_fn=sdk_stream(delay=3)).generate(_req())


async def test_agent_search_tool_runs_inside_the_request_registry(h):
    """The agent's search tool must add to the SAME numbering as the initial retrieval."""
    from pydantic import SecretStr
    seen = {}
    async def fake_query(*, prompt, options=None, transport=None):
        # Simulate the model calling the in-process MCP tool the SDK was configured with.
        server = options.mcp_servers["lenny"]
        tool = server["instance"]
        seen["has_server"] = tool is not None
        import claude_agent_sdk as sdk
        yield sdk.AssistantMessage(content=[sdk.TextBlock(text="[[VERDICT: SUPPORTED]]\nok [1]")], model="m")
        yield sdk.ResultMessage(subtype="success", duration_ms=1, duration_api_ms=1, is_error=False, num_turns=1, session_id="s", result="[[VERDICT: SUPPORTED]]\nok [1]")
    s = make_settings(llm_provider="anthropic", anthropic_api_key=SecretStr("sk-ant-test-0000000000000000"))
    hh = await build_harness(s, claude_query=fake_query)
    try:
        m = await hh.ask(await hh.new_session(), "How does onboarding drive activation?")
        assert m["status"] == "complete" and seen["has_server"]
    finally:
        await close_harness(hh)


# ------------------------------------------------------------------ Ollama status + ingest
async def test_ollama_status_reports_actionable_states(h):
    st = await h.app.state.providers.get("ollama").status()
    assert st.ready and "installed" in st.detail
    h.ollama.installed = ["mistral:7b"]
    st = await h.app.state.providers.get("ollama").status()
    assert not st.ready and "ollama pull llama3.2:3b" in st.hint
    h.ollama.mode = "down"
    st = await h.app.state.providers.get("ollama").status()
    assert not st.ready and "ollama serve" in st.hint


def test_ingest_is_incremental_and_prunes(migrated_db, tmp_path):
    from app.ingest import ingest_directory
    root = tmp_path / "src"
    shutil.copytree(FIXTURES, root)
    eng = create_engine(TEST_DB_URL, connect_args={"prepare_threshold": None})
    kw = dict(repo_label="test://synthetic", commit="deadbeef", target_words=120, overlap_words=20)
    again = ingest_directory(eng, root, **kw)
    assert again.skipped == 3 and again.changed == 0
    f = root / "episodes/test-guest-alpha/transcript.md"
    f.write_text(f.read_text() + "\nTest Guest Alpha (00:30:00):\nA brand new zebra paragraph about quokkas. " + "pad " * 80 + "\n")
    assert ingest_directory(eng, root, **kw).changed == 1
    with eng.connect() as c:
        assert c.execute(text("select count(*) from transcript_chunks where text ilike '%quokkas%'")).scalar() >= 1
    shutil.rmtree(root / "episodes/test-guest-gamma")
    assert ingest_directory(eng, root, **kw).pruned == 1
    with eng.connect() as c:
        assert c.execute(text("select count(*) from transcript_documents")).scalar() == 2
    # restore baseline for other tests
    ingest_directory(eng, FIXTURES, **kw)
    with eng.connect() as c:
        assert c.execute(text("select count(*) from transcript_documents")).scalar() == 3
    eng.dispose()


def test_ingest_fails_loudly_when_nothing_parses(migrated_db, tmp_path):
    from app.ingest import ingest_directory
    (tmp_path / "episodes/bad").mkdir(parents=True)
    (tmp_path / "episodes/bad/transcript.md").write_text("not a transcript")
    eng = create_engine(TEST_DB_URL, connect_args={"prepare_threshold": None})
    with pytest.raises(RuntimeError, match="failed to parse"):
        ingest_directory(eng, tmp_path, repo_label="x", commit=None, target_words=100, overlap_words=10, prune=False)
    with pytest.raises(FileNotFoundError):
        ingest_directory(eng, tmp_path / "missing", repo_label="x", commit=None, target_words=100, overlap_words=10)
    eng.dispose()
