"""Request-scoped dependencies: DB session, anonymous client identity, ownership checks."""

from __future__ import annotations

import re
import uuid
from collections.abc import AsyncIterator

from fastapi import Depends, Header, Request
from sqlalchemy import select, text
from sqlalchemy.ext.asyncio import AsyncSession

from .errors import AppError
from .models import ChatSession, User

_CLIENT_ID = re.compile(r"^[A-Za-z0-9_\-]{16,64}$")


async def get_db(request: Request) -> AsyncIterator[AsyncSession]:
    async with request.app.state.session_factory() as session:
        yield session


async def get_user(
    request: Request,
    db: AsyncSession = Depends(get_db),
    x_client_id: str | None = Header(default=None),
    user_agent: str | None = Header(default=None),
    accept_language: str | None = Header(default=None),
) -> User:
    if not x_client_id or not _CLIENT_ID.match(x_client_id):
        raise AppError(400, "missing_client_id", "A valid X-Client-Id header is required.",
                       "The web app sends this automatically; for API use, send a random 16-64 char id (letters, digits, - _).")
    meta = {"user_agent": (user_agent or "")[:200], "locale": (accept_language or "")[:35]}
    await db.execute(
        text(
            "INSERT INTO users (client_id, metadata) VALUES (:c, CAST(:m AS jsonb)) "
            "ON CONFLICT (client_id) DO UPDATE SET last_seen_at = now(), metadata = users.metadata || EXCLUDED.metadata"
        ),
        {"c": x_client_id, "m": __import__("json").dumps(meta)},
    )
    user = (await db.execute(select(User).where(User.client_id == x_client_id))).scalar_one()
    await db.commit()
    return user


async def owned_session(session_id: uuid.UUID, user: User, db: AsyncSession) -> ChatSession:
    """404 (not 403) for other people's sessions so existence is not leaked."""
    s = (await db.execute(select(ChatSession).where(ChatSession.id == session_id, ChatSession.user_id == user.id))).scalar_one_or_none()
    if s is None:
        raise AppError(404, "session_not_found", "Chat session not found.")
    return s


def enforce_rate_limit(request: Request, user: User = Depends(get_user)) -> User:
    wait = request.app.state.rate_limiter.check(str(user.id))
    if wait is not None:
        raise AppError(429, "rate_limited", "You're sending requests too quickly.", f"Wait about {wait}s and try again.")
    return user
