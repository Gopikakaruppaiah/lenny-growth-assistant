import { useEffect, useState } from "react";
import { copyText, download, safeFileName } from "../lib/artifactFrame";
import type { Message } from "../lib/types";
import { Markdown } from "./Markdown";
import { Sources } from "./Sources";

const PROVIDER_LABEL = { ollama: "Ollama (local)", anthropic: "Claude (cloud)" } as const;

function useElapsed(active: boolean) {
  const [s, setS] = useState(0);
  useEffect(() => {
    if (!active) return;
    setS(0);
    const t = setInterval(() => setS((x) => x + 1), 1000);
    return () => clearInterval(t);
  }, [active]);
  return s;
}

function Pending({ m }: { m: Message }) {
  const s = useElapsed(true);
  const what = m.kind === "essay" ? "Writing your Ship 30 essay — plan, sections, then a length check" : m.kind === "artifact" ? "Building your artifact" : "Searching transcripts and drafting an answer";
  return (
    <div className="pending" role="status">
      <span className="dots" aria-hidden="true"><i /><i /><i /></span>
      <span>{what}… <span className="muted">{s}s</span></span>
      {m.kind === "essay" && s > 20 && <span className="muted block">Essays make several model calls; local models can take a few minutes.</span>}
    </div>
  );
}

export function ProviderBadge({ m }: { m: Message }) {
  if (m.status !== "complete") return null;
  if (!m.provider)
    return <span className="badge neutral" title="Nothing relevant was retrieved, so no model was called.">No model used</span>;
  return (
    <>
      <span className={`badge ${m.provider === "ollama" ? "local" : "cloud"}`} title={m.model ?? undefined}>
        {PROVIDER_LABEL[m.provider]}{m.model ? ` · ${m.model}` : ""}
      </span>
      {m.fallback_from && (
        <span className="badge warn" title="The configured provider failed, so the fallback answered.">
          Fallback — {PROVIDER_LABEL[m.fallback_from]} was unavailable
        </span>
      )}
    </>
  );
}

export function MessageView({
  m, onRetry, onOpenEssay, onOpenArtifact,
}: {
  m: Message; onRetry: (id: string) => void; onOpenEssay: (m: Message) => void; onOpenArtifact: (id: string) => void;
}) {
  const [openN, setOpenN] = useState<number | null>(null);
  const [copied, setCopied] = useState(false);

  if (m.role === "user") {
    return <div className="msg user"><div className="bubble">{m.content}</div></div>;
  }

  const grounded = m.meta.grounded;
  const cite = (n: number) => {
    setOpenN(n);
    requestAnimationFrame(() => document.getElementById(`${m.id}-src-${n}`)?.scrollIntoView({ block: "nearest", behavior: "smooth" }));
  };

  return (
    <article className="msg assistant" aria-label="Assistant reply">
      <div className="avatar" aria-hidden="true">L</div>
      <div className="body">
        {m.status === "pending" && <Pending m={m} />}

        {m.status === "error" && m.error && (
          <div className="error-card" role="alert">
            <strong>{m.error.message}</strong>
            {m.error.hint && <p>{m.error.hint}</p>}
            <div className="row">
              <button type="button" className="btn small" onClick={() => onRetry(m.id)}>Retry</button>
              <code className="muted">{m.error.code}</code>
            </div>
          </div>
        )}

        {m.status === "complete" && m.kind === "chat" && (
          <>
            <Markdown text={m.content} onCite={cite} />
            <Sources sources={m.sources} openN={openN} idPrefix={m.id} />
          </>
        )}

        {m.status === "complete" && m.kind === "essay" && m.sources.length > 0 && (
          <div className="card essay-card">
            <div className="card-kicker">Ship 30 for 30 essay</div>
            <h3>{m.content.match(/^#\s+(.+)$/m)?.[1] ?? "Essay"}</h3>
            <p className="muted">
              {m.meta.word_count} words · target {m.meta.target_words}
              {m.meta.meets_target ? " ✓" : " — outside ±10%"} · {m.sources.length} sources cited
            </p>
            <ul className="checks" aria-label="Quality checks">
              {(m.meta.quality_checks ?? []).map((c) => (
                <li key={c.name} className={c.passed ? "ok" : "bad"}>
                  <span aria-hidden="true">{c.passed ? "✓" : "✕"}</span> {c.detail}
                  <span className="sr-only">{c.passed ? " (passed)" : " (not met)"}</span>
                </li>
              ))}
            </ul>
            <div className="row">
              <button type="button" className="btn primary small" onClick={() => onOpenEssay(m)}>Open in viewer</button>
              <button type="button" className="btn small" onClick={async () => { setCopied(await copyText(m.content)); setTimeout(() => setCopied(false), 1500); }}>
                {copied ? "Copied" : "Copy Markdown"}
              </button>
              <button type="button" className="btn small" onClick={() => download(safeFileName(m.content.match(/^#\s+(.+)$/m)?.[1] ?? "essay", "md"), m.content, "text/markdown")}>
                Download .md
              </button>
            </div>
          </div>
        )}

        {m.status === "complete" && m.kind === "essay" && m.sources.length === 0 && <Markdown text={m.content} />}

        {m.status === "complete" && m.kind === "artifact" && (
          <>
            <Markdown text={m.content} />
            {m.artifact && (
              <div className="card artifact-card">
                <div className="card-kicker">{m.artifact.kind === "html" ? "HTML / CSS artifact" : "Markdown artifact"}</div>
                <h3>{m.artifact.title}</h3>
                <button type="button" className="btn primary small" onClick={() => onOpenArtifact(m.artifact!.id)}>Open in viewer</button>
              </div>
            )}
            {m.artifact && <Sources sources={m.sources} openN={openN} idPrefix={m.id} />}
          </>
        )}

        {m.status === "complete" && (
          <div className="meta-row">
            <ProviderBadge m={m} />
            {grounded === true && m.kind === "chat" && <span className="badge ok">Grounded · {m.sources.filter((s) => s.cited).length} cited</span>}
            {grounded === false && <span className="badge warn">Not grounded in transcripts</span>}
            {m.latency_ms != null && <span className="muted">{(m.latency_ms / 1000).toFixed(1)}s</span>}
          </div>
        )}
        {m.status === "complete" && (m.meta.citation_warnings?.length ?? 0) > 0 && (
          <details className="warnings"><summary>Verification notes ({m.meta.citation_warnings!.length})</summary>
            <ul>{m.meta.citation_warnings!.map((w) => <li key={w}>{w}</li>)}</ul>
          </details>
        )}
      </div>
    </article>
  );
}
