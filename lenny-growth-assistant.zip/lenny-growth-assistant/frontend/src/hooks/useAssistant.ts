import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError, api } from "../lib/api";
import type { Accepted, CorpusStats, Message, ProviderName, ProvidersResponse, Session } from "../lib/types";

export type Viewer = { type: "artifact"; id: string } | { type: "essay"; message: Message } | null;
const PROVIDER_KEY = "lga.provider";
const POLL_MS = 1200;

function readProviderChoice(): ProviderName | null {
  try {
    const v = localStorage.getItem(PROVIDER_KEY);
    return v === "ollama" || v === "anthropic" ? v : null;
  } catch { return null; }
}

export function useAssistant(pollMs = POLL_MS) {
  const [sessions, setSessions] = useState<Session[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loadingSessions, setLoadingSessions] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [banner, setBanner] = useState<ApiError | null>(null);
  const [providers, setProviders] = useState<ProvidersResponse | null>(null);
  const [providersError, setProvidersError] = useState<ApiError | null>(null);
  const [stats, setStats] = useState<CorpusStats | null>(null);
  const [providerChoice, setProviderChoiceState] = useState<ProviderName | null>(readProviderChoice);
  const [viewer, setViewer] = useState<Viewer>(null);
  const activeRef = useRef<string | null>(null);
  activeRef.current = activeId;

  const setProviderChoice = useCallback((p: ProviderName | null) => {
    setProviderChoiceState(p);
    try { p ? localStorage.setItem(PROVIDER_KEY, p) : localStorage.removeItem(PROVIDER_KEY); } catch { /* storage blocked */ }
  }, []);

  const fail = useCallback((e: unknown) => setBanner(e instanceof ApiError ? e : new ApiError("unknown", "Something went wrong.", 0)), []);

  const refreshSessions = useCallback(async () => {
    try { setSessions(await api.listSessions()); setBanner((b) => (b?.code === "network_error" ? null : b)); }
    catch (e) { fail(e); }
    finally { setLoadingSessions(false); }
  }, [fail]);

  const refreshProviders = useCallback(async () => {
    try { setProviders(await api.providers()); setProvidersError(null); }
    catch (e) { setProvidersError(e instanceof ApiError ? e : null); }
  }, []);

  useEffect(() => {
    void refreshSessions();
    void refreshProviders();
    api.stats().then(setStats).catch(() => undefined);
    const t = setInterval(refreshProviders, 15000);
    return () => clearInterval(t);
  }, [refreshSessions, refreshProviders]);

  // Load messages when the active session changes.
  useEffect(() => {
    if (!activeId) { setMessages([]); return; }
    let cancelled = false;
    setLoadingMessages(true);
    api.listMessages(activeId)
      .then((m) => { if (!cancelled) setMessages(m); })
      .catch((e) => { if (!cancelled) fail(e); })
      .finally(() => { if (!cancelled) setLoadingMessages(false); });
    return () => { cancelled = true; };
  }, [activeId, fail]);

  // Poll the (single) pending assistant message of the active session.
  const pending = messages.find((m) => m.role === "assistant" && m.status === "pending");
  const pendingId = pending?.id;
  useEffect(() => {
    if (!pendingId || !activeId) return;
    let failures = 0;
    let stopped = false;
    const sid = activeId;
    const tick = async () => {
      try {
        const m = await api.getMessage(sid, pendingId);
        failures = 0;
        if (stopped || activeRef.current !== sid) return;
        if (m.status !== "pending") {
          setMessages((prev) => prev.map((x) => (x.id === m.id ? m : x)));
          void refreshSessions();
          if (m.status === "complete" && m.artifact) setViewer({ type: "artifact", id: m.artifact.id });
          else if (m.status === "complete" && m.kind === "essay" && m.sources.length) setViewer({ type: "essay", message: m });
        }
      } catch (e) {
        failures += 1;
        if (failures === 3) fail(e);
      }
    };
    const t = setInterval(tick, pollMs);
    return () => { stopped = true; clearInterval(t); };
  }, [pendingId, activeId, pollMs, fail, refreshSessions]);

  const ensureSession = useCallback(async (): Promise<string> => {
    if (activeRef.current) return activeRef.current;
    const s = await api.createSession();
    setSessions((prev) => [s, ...prev]);
    setActiveId(s.id);
    activeRef.current = s.id;
    return s.id;
  }, []);

  const accept = useCallback((a: Accepted) => {
    setMessages((prev) => [...prev, a.user_message, a.assistant_message]);
    void refreshSessions();
  }, [refreshSessions]);

  const guarded = useCallback(async (fn: (sid: string) => Promise<Accepted>): Promise<boolean> => {
    setBanner(null);
    try { const sid = await ensureSession(); accept(await fn(sid)); return true; }
    catch (e) { fail(e); return false; }
  }, [ensureSession, accept, fail]);

  const send = useCallback((text: string) => guarded((sid) => api.send(sid, text, providerChoice)), [guarded, providerChoice]);
  const makeEssay = useCallback((topic: string | null) => guarded((sid) => api.essay(sid, topic, providerChoice)), [guarded, providerChoice]);
  const makeArtifact = useCallback((kind: "markdown" | "html", instruction: string) => guarded((sid) => api.artifact(sid, kind, instruction, providerChoice)), [guarded, providerChoice]);

  const retry = useCallback(async (mid: string) => {
    if (!activeRef.current) return;
    setBanner(null);
    try {
      const m = await api.retry(activeRef.current, mid);
      setMessages((prev) => prev.map((x) => (x.id === m.id ? m : x)));
    } catch (e) { fail(e); }
  }, [fail]);

  const newChat = useCallback(() => { setActiveId(null); setMessages([]); setViewer(null); setBanner(null); }, []);
  const selectSession = useCallback((id: string) => { setActiveId(id); setViewer(null); setBanner(null); }, []);
  const removeSession = useCallback(async (id: string) => {
    try {
      await api.deleteSession(id);
      setSessions((prev) => prev.filter((s) => s.id !== id));
      if (activeRef.current === id) newChat();
    } catch (e) { fail(e); }
  }, [fail, newChat]);

  return {
    sessions, activeId, messages, loadingSessions, loadingMessages, banner, dismissBanner: () => setBanner(null),
    providers, providersError, stats, providerChoice, setProviderChoice, viewer, setViewer,
    isGenerating: Boolean(pending), pending, send, makeEssay, makeArtifact, retry, newChat, selectSession, removeSession,
    refreshProviders,
  };
}
