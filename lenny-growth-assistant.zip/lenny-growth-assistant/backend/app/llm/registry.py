"""Provider selection, availability, and visible fallback."""

from __future__ import annotations

from ..config import ProviderName, Settings
from ..logging_setup import get_logger
from .base import GenerationRequest, GenerationResult, LLMProvider, ProviderError, ProviderStatus
from .claude_agent import ClaudeAgentProvider
from .ollama import OllamaProvider

log = get_logger("llm.registry")


class ProviderRegistry:
    def __init__(self, settings: Settings, providers: dict[str, LLMProvider] | None = None) -> None:
        self.settings = settings
        self._providers: dict[str, LLMProvider] = providers or {
            "ollama": OllamaProvider(settings),
            "anthropic": ClaudeAgentProvider(settings),
        }

    @property
    def default_name(self) -> ProviderName:
        return self.settings.llm_provider

    @property
    def fallback_name(self) -> str | None:
        f = self.settings.llm_fallback_provider
        return None if f == "none" or f == self.settings.llm_provider else f

    def get(self, name: str) -> LLMProvider:
        return self._providers[name]

    async def statuses(self) -> list[ProviderStatus]:
        return [await p.status() for p in self._providers.values()]

    async def generate(
        self, req: GenerationRequest, preferred: str | None = None
    ) -> tuple[GenerationResult, str | None]:
        """Run on ``preferred`` (or the configured default). Returns (result, fallback_from).

        ``fallback_from`` is the name of the provider that failed when the fallback answered, so the
        UI can say so — a fallback is never presented as if the primary had answered.
        """
        primary = preferred or self.default_name
        try:
            return await self._providers[primary].generate(req), None
        except ProviderError as exc:
            fb = self.fallback_name
            if not fb or fb == primary:
                raise
            log.warning(
                "primary provider failed; using fallback",
                extra={"primary": primary, "fallback": fb, "error_code": exc.code},
            )
            try:
                return await self._providers[fb].generate(req), primary
            except ProviderError:
                raise exc from None  # report the *primary* failure; it is the actionable one
