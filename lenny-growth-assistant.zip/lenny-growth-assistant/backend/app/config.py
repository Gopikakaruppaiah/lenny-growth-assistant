"""Application configuration.

Every tunable lives here and is read from environment variables (or a local
``.env`` file). Switching LLM provider, model, or database never requires a code
change — see ``.env.example`` for the full list and ``docs/architecture.md`` for
the provider-routing rules.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

ProviderName = Literal["ollama", "anthropic"]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # --- runtime ---------------------------------------------------------
    app_env: Literal["development", "test", "production"] = "development"
    log_level: str = "INFO"
    log_format: Literal["json", "console"] = "json"

    # --- database --------------------------------------------------------
    # Any standard Postgres URL works (Supabase, Railway, Neon, local). A bare
    # ``postgresql://`` or ``postgres://`` scheme is rewritten to psycopg3.
    database_url: str = "postgresql+psycopg://lenny:lenny@localhost:5432/lenny"
    db_connect_timeout_seconds: int = 5
    db_pool_size: int = 5

    # --- HTTP ------------------------------------------------------------
    # Comma-separated *exact* origins (scheme + host + port). No wildcards.
    cors_allowed_origins: str = "http://localhost:5173,http://localhost:3000"
    max_message_chars: int = 4000
    rate_limit_per_minute: int = 20  # generation requests per client per minute; 0 disables

    # --- LLM routing -----------------------------------------------------
    llm_provider: ProviderName = "ollama"
    # Used only when the primary provider fails with a timeout/unavailable error.
    # The UI always shows which provider actually produced an answer.
    llm_fallback_provider: Literal["none", "ollama", "anthropic"] = "none"
    llm_timeout_seconds: float = 120.0  # per model call (chat, outline, one essay section)
    essay_total_timeout_seconds: float = 900.0  # whole essay job

    ollama_base_url: str = "http://localhost:11434"
    ollama_model: str = "llama3.2:3b"
    ollama_num_ctx: int = 8192

    anthropic_api_key: SecretStr | None = None
    anthropic_model: str = "claude-sonnet-5-5"
    anthropic_max_budget_usd: float = 0.50  # hard per-request cap enforced by the Agent SDK
    anthropic_max_turns: int = 6

    # --- knowledge base --------------------------------------------------
    transcripts_repo_url: str = "https://github.com/ChatPRD/lennys-podcast-transcripts"
    transcripts_dir: str = "./data/lennys-podcast-transcripts"
    chunk_target_words: int = 300
    chunk_overlap_words: int = 40
    retrieval_top_k: int = 8
    retrieval_max_per_episode: int = 2
    retrieval_min_coverage: float = Field(default=0.34, ge=0.0, le=1.0)
    history_max_messages: int = 8

    @field_validator("database_url")
    @classmethod
    def _normalise_db_url(cls, v: str) -> str:
        if v.startswith("postgres://"):
            v = "postgresql://" + v[len("postgres://") :]
        if v.startswith("postgresql://"):
            v = "postgresql+psycopg://" + v[len("postgresql://") :]
        return v

    @field_validator("cors_allowed_origins")
    @classmethod
    def _no_wildcards(cls, v: str) -> str:
        if "*" in v:
            raise ValueError("CORS_ALLOWED_ORIGINS must list exact origins; wildcards are not allowed")
        return v

    @property
    def cors_origins(self) -> list[str]:
        return [o.strip().rstrip("/") for o in self.cors_allowed_origins.split(",") if o.strip()]

    @property
    def anthropic_configured(self) -> bool:
        return bool(self.anthropic_api_key and self.anthropic_api_key.get_secret_value().strip())


@lru_cache
def get_settings() -> Settings:
    return Settings()
