import type { Source } from "../lib/types";

export function Sources({ sources, openN, idPrefix }: { sources: Source[]; openN: number | null; idPrefix: string }) {
  if (!sources.length) return null;
  const cited = sources.filter((s) => s.cited);
  const other = sources.filter((s) => !s.cited);
  const render = (s: Source) => (
    <details key={s.n} id={`${idPrefix}-src-${s.n}`} className="source" open={openN === s.n}>
      <summary>
        <span className={`cite static ${s.cited ? "" : "dim"}`} aria-hidden="true">{s.n}</span>
        <span className="source-main">
          <strong>{s.guest}</strong>
          <span className="source-title">{s.title}</span>
        </span>
        {s.timestamp_label && <span className="source-time">{s.timestamp_label}</span>}
      </summary>
      <blockquote>{s.snippet}</blockquote>
      <div className="source-links">
        {s.deep_link && <a href={s.deep_link} target="_blank" rel="noopener noreferrer">Watch{s.timestamp_label ? ` at ${s.timestamp_label}` : ""} ↗</a>}
        {s.transcript_url && <a href={s.transcript_url} target="_blank" rel="noopener noreferrer">Transcript file ↗</a>}
        {s.publish_date && <span className="muted">Published {s.publish_date}</span>}
      </div>
    </details>
  );
  return (
    <section className="sources" aria-label="Sources">
      {cited.length > 0 && <h4>Sources cited</h4>}
      {cited.map(render)}
      {other.length > 0 && (
        <details className="also">
          <summary>{cited.length ? `Also retrieved (${other.length})` : `Closest passages found (${other.length}) — not cited`}</summary>
          {other.map(render)}
        </details>
      )}
    </section>
  );
}
