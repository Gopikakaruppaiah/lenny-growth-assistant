"""Test doubles. These are NOT product code: they stand in for external services in unit tests.

* FakeOllama   - an httpx.MockTransport that behaves like Ollama's /api/tags and /api/chat.
* sdk_stream   - builds a fake claude_agent_sdk.query() message stream from real SDK dataclasses.
"""

from __future__ import annotations

import asyncio
import json
import re
from collections.abc import Callable

import claude_agent_sdk as sdk
import httpx


class FakeOllama:
    def __init__(self, responder: Callable[[list[dict]], str] | None = None, model: str = "llama3.2:3b") -> None:
        self.model = model
        self.responder = responder or default_responder
        self.mode = "ok"  # ok | down | timeout | missing_model | http500 | garbage
        self.calls: list[dict] = []
        self.gate: asyncio.Event | None = None  # when set, /api/chat blocks until released
        self.installed = [model]

    def transport(self) -> httpx.MockTransport:
        async def handler(request: httpx.Request) -> httpx.Response:
            if self.mode == "down":
                raise httpx.ConnectError("connection refused", request=request)
            if request.url.path == "/api/tags":
                return httpx.Response(200, json={"models": [{"name": n} for n in self.installed]})
            body = json.loads(request.content)
            self.calls.append(body)
            if self.mode == "timeout":
                raise httpx.ReadTimeout("slow", request=request)
            if self.mode == "missing_model":
                return httpx.Response(404, json={"error": "model not found"})
            if self.mode == "http500":
                return httpx.Response(500, text="boom")
            if self.mode == "garbage":
                return httpx.Response(200, json={"unexpected": True})
            if self.gate is not None:
                await self.gate.wait()
            text = self.responder(body["messages"])
            return httpx.Response(200, json={"message": {"role": "assistant", "content": text}, "prompt_eval_count": 10, "eval_count": 20})

        return httpx.MockTransport(handler)


def excerpt_numbers(prompt: str) -> list[int]:
    return [int(n) for n in re.findall(r'<excerpt n="(\d+)"', prompt)]


def default_responder(messages: list[dict]) -> str:
    """Behaves like a well-behaved grounded model, whatever the task is."""
    system = messages[0]["content"]
    user = messages[-1]["content"]
    nums = excerpt_numbers(user) or [1]
    if "PLAN the essay" in system:
        return ("HEADLINE: 3 lessons PMs can steal from Lenny's guests on onboarding\nANGLE: actionable\nAPPROACH: Lessons\n"
                "SECTION 1: Start with activation | Define the moment of value | 1,2\n"
                "SECTION 2: Remove friction | Cut steps before the aha | 2,3\n"
                "SECTION 3: Measure it | Track the cohort curve | 1,3")
    if "Create this artifact" in user:
        if "one complete HTML document" in system:
            return "<!doctype html><html><head><title>Onboarding Playbook</title><style>body{font-family:sans-serif}</style></head><body><h1>Onboarding</h1><p>Test Guest Alpha says activation matters [1].</p></body></html>"
        return "# Onboarding checklist\n\n- Define activation [1]\n- Remove friction [2]\n"
    if "Revise one part" in system:
        return " ".join(["word"] * 300) + f" [{nums[0]}]"
    if system.startswith("You are a ghostwriter"):
        budget = {"introduction": 170, "main point": 300, "takeaway": 180}
        words = next((w for k, w in budget.items() if k in system), 250)
        cites = " ".join(f"[{n}]" for n in nums[:3])
        body = ("**Key idea.** " + " ".join(["insight"] * (words - 12)) + f" {cites}.")
        if "takeaway" in system:
            body += "\n\n- one\n- two\n- three"
        return body
    return f"[[VERDICT: SUPPORTED]]\nTest Guest Alpha says activation drives retention [{nums[0]}]. Another guest agrees [{nums[-1]}]."


def sdk_stream(*, text: str = "ok", tool_uses: int = 0, error: str | None = None, result_error: dict | None = None,
               delay: float = 0.0, model: str = "claude-test"):
    """Return a replacement for claude_agent_sdk.query that yields real SDK message objects."""

    async def fake_query(*, prompt, options=None, transport=None):
        fake_query.last_prompt, fake_query.last_options = prompt, options  # type: ignore[attr-defined]
        if delay:
            await asyncio.sleep(delay)
        blocks = [sdk.ToolUseBlock(id=f"t{i}", name="mcp__lenny__search_transcripts", input={"query": "x"}) for i in range(tool_uses)]
        if blocks:
            yield sdk.AssistantMessage(content=blocks, model=model)
        yield sdk.AssistantMessage(content=[sdk.TextBlock(text=text)], model=model, error=error)  # type: ignore[arg-type]
        kw = dict(subtype="success", duration_ms=1, duration_api_ms=1, is_error=False, num_turns=1, session_id="s", result=text,
                  total_cost_usd=0.01, usage={"input_tokens": 5})
        kw.update(result_error or {})
        yield sdk.ResultMessage(**kw)  # type: ignore[arg-type]

    return fake_query
