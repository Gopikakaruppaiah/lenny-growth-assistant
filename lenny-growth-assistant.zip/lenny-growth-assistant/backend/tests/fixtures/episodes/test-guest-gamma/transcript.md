---
guest: Test Guest Gamma
title: "Synthetic - retention and growth loops"
youtube_url: https://www.youtube.com/watch?v=CCCCCCCCCCC
video_id: CCCCCCCCCCC
publish_date: 2024-01-15
description: SYNTHETIC TEST FIXTURE - not real transcript content.
duration_seconds: 3600.0
keywords:
- onboarding
---

# Synthetic: retention and growth loops

## Transcript

Lenny (00:00:00):
Tell me more about this part. Retention is the foundation of growth loops, and a retention curve that flattens signals product market fit.

Test Guest Gamma (00:01:00):
Retention is the foundation of growth loops, and a retention curve that flattens signals product market fit. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

Lenny (00:03:00):
Tell me more about this part. Growth loops compound when each new user activation creates content that attracts more users.

Test Guest Gamma (00:04:00):
Growth loops compound when each new user activation creates content that attracts more users. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

Lenny (00:06:00):
Tell me more about this part. Onboarding experiments should target the activation step that predicts long term retention.

Test Guest Gamma (00:07:00):
Onboarding experiments should target the activation step that predicts long term retention. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

