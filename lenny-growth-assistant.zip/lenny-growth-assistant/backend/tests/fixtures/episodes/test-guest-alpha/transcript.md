---
guest: Test Guest Alpha
title: "Synthetic - activation and onboarding"
youtube_url: https://www.youtube.com/watch?v=AAAAAAAAAAA
video_id: AAAAAAAAAAA
publish_date: 2024-01-15
description: SYNTHETIC TEST FIXTURE - not real transcript content.
duration_seconds: 3600.0
keywords:
- onboarding
---

# Synthetic: activation and onboarding

## Transcript

Lenny (00:00:00):
Tell me more about this part. Activation is the moment a new user first experiences value, and onboarding should drive users toward that activation moment.

Test Guest Alpha (00:01:00):
Activation is the moment a new user first experiences value, and onboarding should drive users toward that activation moment. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

Lenny (00:03:00):
Tell me more about this part. Reducing onboarding friction by removing signup steps improved activation for new users in our product.

Test Guest Alpha (00:04:00):
Reducing onboarding friction by removing signup steps improved activation for new users in our product. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

Lenny (00:06:00):
Tell me more about this part. We measure onboarding with a cohort retention curve after activation.

Test Guest Alpha (00:07:00):
We measure onboarding with a cohort retention curve after activation. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

