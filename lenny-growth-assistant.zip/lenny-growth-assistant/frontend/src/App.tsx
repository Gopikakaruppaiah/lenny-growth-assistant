import { useState } from "react";
import { ArtifactDialog } from "./components/ArtifactDialog";
import { ArtifactPanel } from "./components/ArtifactPanel";
import { Chat } from "./components/Chat";
import { ProviderMenu } from "./components/ProviderMenu";
import { Sidebar } from "./components/Sidebar";
import { useAssistant } from "./hooks/useAssistant";

export default function App() {
  const a = useAssistant();
  const [navOpen, setNavOpen] = useState(false);
  const [dialogSeed, setDialogSeed] = useState<string | null>(null);
  const [mobileTab, setMobileTab] = useState<"chat" | "viewer">("chat");
  const showViewer = a.viewer !== null;

  const openViewer: typeof a.setViewer = (v) => { a.setViewer(v); if (v) setMobileTab("viewer"); };

  return (
    <div className={`app ${showViewer ? "with-viewer" : ""} tab-${mobileTab}`}>
      <Sidebar sessions={a.sessions} activeId={a.activeId} loading={a.loadingSessions} onNew={a.newChat} onSelect={a.selectSession} onDelete={a.removeSession} open={navOpen} onClose={() => setNavOpen(false)} />

      <main className="main">
        <header className="topbar">
          <button type="button" className="icon-btn mobile-only" aria-label="Open chat history" onClick={() => setNavOpen(true)}>☰</button>
          <h1 className="top-title">{a.sessions.find((s) => s.id === a.activeId)?.title ?? "New chat"}</h1>
          <ProviderMenu data={a.providers} error={a.providersError} choice={a.providerChoice} onChoose={a.setProviderChoice} />
        </header>

        {a.banner && (
          <div className="banner" role="alert">
            <div><strong>{a.banner.message}</strong>{a.banner.hint && <span> {a.banner.hint}</span>}</div>
            <button type="button" className="icon-btn" aria-label="Dismiss" onClick={a.dismissBanner}>✕</button>
          </div>
        )}

        <div className="workspace">
          <Chat
            messages={a.messages} loading={a.loadingMessages} generating={a.isGenerating} stats={a.stats}
            onSend={a.send} onEssay={a.makeEssay} onArtifactDialog={setDialogSeed} onRetry={a.retry}
            onOpenEssay={(m) => openViewer({ type: "essay", message: m })} onOpenArtifact={(id) => openViewer({ type: "artifact", id })}
          />
          <ArtifactPanel viewer={a.viewer} onClose={() => { a.setViewer(null); setMobileTab("chat"); }} />
        </div>

        {showViewer && (
          <div className="tabbar mobile-only" role="tablist" aria-label="Switch between chat and artifact">
            <button role="tab" aria-selected={mobileTab === "chat"} className={mobileTab === "chat" ? "on" : ""} onClick={() => setMobileTab("chat")}>Chat</button>
            <button role="tab" aria-selected={mobileTab === "viewer"} className={mobileTab === "viewer" ? "on" : ""} onClick={() => setMobileTab("viewer")}>Artifact</button>
          </div>
        )}
      </main>

      {dialogSeed !== null && (
        <ArtifactDialog initial={dialogSeed} onCancel={() => setDialogSeed(null)} onSubmit={(kind, instr) => { setDialogSeed(null); void a.makeArtifact(kind, instr); }} />
      )}
    </div>
  );
}
