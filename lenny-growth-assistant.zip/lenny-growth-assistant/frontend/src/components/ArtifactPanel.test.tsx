import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it, vi } from "vitest";
import { ArtifactPanel } from "./ArtifactPanel";
import { SID, mockApi, msg } from "../test/fixtures";

const htmlArtifact = { id: "a1", session_id: SID, message_id: null, kind: "html", title: "Playbook", provider: "ollama", model: "m", sanitizer_report: {}, created_at: "", content: "<!doctype html><html><head><title>Playbook</title></head><body><h1>Hello</h1></body></html>" };

describe("ArtifactPanel", () => {
  it("shows an empty state when nothing is open", () => {
    render(<ArtifactPanel viewer={null} onClose={() => {}} />);
    expect(screen.getByRole("heading", { name: /artifact viewer/i })).toBeInTheDocument();
  });

  it("renders HTML ONLY in a fully sandboxed iframe with a CSP", async () => {
    mockApi({ "GET /artifacts/a1": () => htmlArtifact });
    render(<ArtifactPanel viewer={{ type: "artifact", id: "a1" }} onClose={() => {}} />);
    const frame = (await screen.findByTitle(/preview of playbook/i)) as HTMLIFrameElement;
    expect(frame.getAttribute("sandbox")).toBe(""); // present but empty: no allow-scripts, no allow-same-origin
    expect(frame.getAttribute("sandbox")).not.toMatch(/allow-/);
    expect(frame.getAttribute("srcdoc")).toContain("Content-Security-Policy");
    expect(frame.getAttribute("srcdoc")).toContain("default-src 'none'");
    expect(frame.getAttribute("referrerpolicy")).toBe("no-referrer");
    expect(frame.getAttribute("src")).toBeNull();
  });

  it("shows a loading state, then content", async () => {
    let release!: () => void;
    mockApi({ "GET /artifacts/a1": () => new Promise((r) => { release = () => r(htmlArtifact); }) });
    render(<ArtifactPanel viewer={{ type: "artifact", id: "a1" }} onClose={() => {}} />);
    expect(await screen.findByText(/loading artifact/i)).toBeInTheDocument();
    release();
    expect(await screen.findByTitle(/preview of playbook/i)).toBeInTheDocument();
  });

  it("shows an error with a working retry", async () => {
    let fail = true;
    mockApi({ "GET /artifacts/a1": () => (fail ? { __status: 404, body: { error: { code: "artifact_not_found", message: "Artifact not found." } } } : htmlArtifact) });
    render(<ArtifactPanel viewer={{ type: "artifact", id: "a1" }} onClose={() => {}} />);
    expect(await screen.findByRole("alert")).toHaveTextContent("Artifact not found.");
    fail = false;
    await userEvent.click(screen.getByRole("button", { name: /try again/i }));
    expect(await screen.findByTitle(/preview of playbook/i)).toBeInTheDocument();
  });

  it("renders markdown without executing raw HTML, and neutralises javascript: links", async () => {
    mockApi({ "GET /artifacts/m1": () => ({ ...htmlArtifact, id: "m1", kind: "markdown", title: "Doc", content: "# Title\n\n<script>window.__pwned=1</script><img src=x onerror=\"window.__pwned=1\">\n\n[bad](javascript:window.__pwned=1) **bold**" }) });
    const { container } = render(<ArtifactPanel viewer={{ type: "artifact", id: "m1" }} onClose={() => {}} />);
    expect(await screen.findByRole("heading", { level: 1, name: "Title" })).toBeInTheDocument();
    expect(container.querySelector("script")).toBeNull();
    expect(container.querySelector("img")).toBeNull();
    expect((window as unknown as { __pwned?: number }).__pwned).toBeUndefined();
    const bad = container.querySelector("a");
    expect(bad?.getAttribute("href") ?? "").not.toMatch(/^javascript:/i);
  });

  it("opens an essay from the message without a network call, with copy/download controls", async () => {
    const { fn } = mockApi({});
    const m = msg({ kind: "essay", content: "# Great essay\n\nBody [1]", meta: { word_count: 1250 } });
    render(<ArtifactPanel viewer={{ type: "essay", message: m }} onClose={() => {}} />);
    expect(await screen.findByRole("heading", { level: 1, name: "Great essay" })).toBeInTheDocument();
    expect(fn).not.toHaveBeenCalled();
    expect(screen.getByRole("button", { name: "Copy" })).toBeEnabled();
    expect(screen.getByRole("button", { name: "Download" })).toBeEnabled();
    await userEvent.click(screen.getByRole("tab", { name: /markdown/i }));
    expect(screen.getByText(/# Great essay/)).toBeInTheDocument();
  });

  it("closes", async () => {
    const onClose = vi.fn();
    mockApi({ "GET /artifacts/a1": () => htmlArtifact });
    render(<ArtifactPanel viewer={{ type: "artifact", id: "a1" }} onClose={onClose} />);
    await userEvent.click(await screen.findByRole("button", { name: /close viewer/i }));
    expect(onClose).toHaveBeenCalled();
  });
});
