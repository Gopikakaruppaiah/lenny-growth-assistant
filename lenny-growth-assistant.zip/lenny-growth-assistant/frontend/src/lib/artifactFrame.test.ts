import { describe, expect, it } from "vitest";
import { ARTIFACT_CSP, IFRAME_SANDBOX, buildSrcDoc, linkifyCitations, safeFileName } from "./artifactFrame";

describe("artifact isolation", () => {
  it("uses an empty sandbox (every capability denied)", () => {
    expect(IFRAME_SANDBOX).toBe("");
  });
  it("CSP forbids network, scripts, forms and base tags", () => {
    expect(ARTIFACT_CSP).toContain("default-src 'none'");
    expect(ARTIFACT_CSP).not.toMatch(/script-src|connect-src|https?:/);
    expect(ARTIFACT_CSP).toContain("form-action 'none'");
    expect(ARTIFACT_CSP).toContain("base-uri 'none'");
  });
  it("injects the CSP as the first thing in <head>", () => {
    const doc = buildSrcDoc('<!doctype html><html><head><title>x</title></head><body>hi</body></html>');
    expect(doc.indexOf("Content-Security-Policy")).toBeGreaterThan(-1);
    expect(doc.indexOf("Content-Security-Policy")).toBeLessThan(doc.indexOf("<title>"));
  });
  it("wraps headless fragments and strips attacker-supplied CSP metas", () => {
    const doc = buildSrcDoc('<meta http-equiv="Content-Security-Policy" content="default-src *"><p>x</p>');
    expect(doc).not.toContain("default-src *");
    expect(doc).toContain(ARTIFACT_CSP);
    expect(doc.startsWith("<!doctype html>")).toBe(true);
  });
});

describe("helpers", () => {
  it("turns [n] into citation links but leaves real markdown links alone", () => {
    expect(linkifyCitations("a [1] b [2][3] [link](http://x)")).toBe("a [1](#src-1) b [2](#src-2)[3](#src-3) [link](http://x)");
  });
  it("makes safe file names", () => {
    expect(safeFileName("../../Etc/Passwd: My Essay!", "md")).toBe("etc-passwd-my-essay.md");
    expect(safeFileName("???", "html")).toBe("artifact.html");
  });
});
