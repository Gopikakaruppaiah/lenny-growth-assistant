# Deployment guide & checklist

> **Nothing has been deployed by the author of this repository.** No Vercel/Render/Supabase account or deploy tool was
> available. Everything below is configuration + exact steps for *you* to run. No live URL exists until you complete them.

## Where each variable belongs

| Variable | Vercel (frontend) | Render/backend host | Local `.env` |
|---|:-:|:-:|:-:|
| `VITE_API_BASE_URL` (public URL of the API, no trailing slash) | ✅ **build-time** | – | `frontend/.env` |
| `DATABASE_URL` (Supabase) | ❌ never | ✅ secret | ✅ |
| `ANTHROPIC_API_KEY` | ❌ never | ✅ secret | optional |
| `CORS_ALLOWED_ORIGINS` (your Vercel URL(s)) | – | ✅ | ✅ |
| `LLM_PROVIDER` / `LLM_FALLBACK_PROVIDER` / `ANTHROPIC_MODEL` / limits | – | ✅ | ✅ |
| `OLLAMA_*` | – | only if your host can reach an Ollama server | ✅ |

`VITE_*` variables are embedded in the public JavaScript bundle (Vercel docs: *never store a secret in a `VITE_` variable*).

## Order of operations
1. **Supabase** → New project → Project Settings → Database → copy the **connection pooling** string (transaction mode, port 6543) or direct string.
   Use it as `DATABASE_URL` (`postgresql://…` is auto-converted; the driver disables prepared statements so the pooler works).
2. **Migrate + ingest from your laptop** (one-time; ~11 s, ~66 MB):
   ```bash
   cd backend && source .venv/bin/activate
   export DATABASE_URL='<supabase string>'
   alembic upgrade head
   python -m app.ingest            # clones the transcripts locally, indexes into Supabase
   ```
   (The backend container also runs `alembic upgrade head` on every start.)
3. **Backend on Render** → New → Blueprint → select this repo (uses `render.yaml`) → fill the three `sync: false` values:
   `DATABASE_URL`, `ANTHROPIC_API_KEY`, `CORS_ALLOWED_ORIGINS` (put a placeholder first; fix after step 4).
   Keep **one instance**. Free plan spins down after ~15 min idle (first request is slow); use a paid plan for a smooth demo.
   Verify field names against Render's current Blueprint docs — they were checked only through secondary sources.
   Note the URL, e.g. `https://lenny-growth-assistant-api.onrender.com`.
4. **Frontend on Vercel** → Import repo → **Root Directory `frontend`** → Framework preset *Vite* (auto-detected) →
   Environment Variable `VITE_API_BASE_URL=https://<render-url>` → Deploy. Note the URL.
5. **CORS** → in Render set `CORS_ALLOWED_ORIGINS=https://<your-app>.vercel.app` (exact origin; add preview URLs separated by commas if needed) → redeploy backend.
6. **Smoke test** (below).

Alternative backend hosts that satisfy "persistent process": Railway, Fly.io, any VM/Docker host. Vercel Functions are **not** suitable (in-process background jobs, long-running essays).

## Ollama in the deployed setup
The deployed backend cannot see your machine's Ollama. Options: (a) demo locally with Ollama and use the deployed site with Claude;
(b) tunnel (Tailscale/Cloudflare Tunnel) to your Ollama and set `OLLAMA_BASE_URL` — you take on exposing a port; (c) run Ollama on
a GPU host. None are configured here, and the UI will correctly show Ollama as "not reachable" in production.

## Production smoke test
```bash
API=https://<render-url>/api/v1
curl -s $API/health                      # {"status":"ok","version":"1.0.0"}
curl -s $API/health/ready                # "status":"ready","database":"up","knowledge_base":"indexed"
curl -s $API/providers                   # default "anthropic", ready true; no key in output
curl -s -i -X OPTIONS $API/sessions -H 'Origin: https://<app>.vercel.app' \
     -H 'Access-Control-Request-Method: POST' -H 'Access-Control-Request-Headers: x-client-id,content-type' \
     | grep -i access-control-allow-origin   # echoes your Vercel origin
```
Then in the browser follow *Production smoke test* in `docs/manual-test-plan.md`.

## Pre-submission checklist
- [ ] `git grep -nE "sk-ant|postgres(ql)?://[^:]+:[^@]+@"` finds only examples (`lenny:lenny@` local defaults)
- [ ] `.env` is not committed; `data/` is not committed (transcripts are not redistributed)
- [ ] Repo is **public** on GitHub; README link works
- [ ] Supabase migrated + ingested; `/health/ready` is `ready`
- [ ] Render service healthy, single instance; Vercel build green; CORS exact origin set
- [ ] Production smoke test passed; manual test plan executed and results recorded
- [ ] Demo video recorded (≤3 min), uploaded, link pasted into README
- [ ] `agent-logs/` reviewed for secrets before pushing
- [ ] Budget alert set on the Anthropic account; `RATE_LIMIT_PER_MINUTE` is low
