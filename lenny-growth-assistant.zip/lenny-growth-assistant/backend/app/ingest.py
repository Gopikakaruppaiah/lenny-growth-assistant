"""Transcript ingestion CLI.

    python -m app.ingest                      # clone/update the upstream repo, then index it
    python -m app.ingest --path ./my-files    # index user-supplied transcripts (same layout)
    python -m app.ingest --refresh            # git pull first, then re-index only what changed
    python -m app.ingest --limit 10           # quick dev run

Source: https://github.com/ChatPRD/lennys-podcast-transcripts. The upstream README states the
transcripts are "provided for personal and educational use" and has no LICENSE file, so this
project NEVER commits transcript text: it is cloned at runtime into a gitignored directory
and indexed into your own database.

Layout expected under the root: ``episodes/<slug>/transcript.md``.
"""

from __future__ import annotations

import argparse
import hashlib
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

from sqlalchemy import create_engine, delete, insert, select, update
from sqlalchemy.engine import Engine

from .config import get_settings
from .logging_setup import configure_logging, get_logger
from .models import IngestionRun, TranscriptChunk, TranscriptDocument
from .rag.chunking import chunk_turns
from .rag.parsing import TranscriptParseError, parse_transcript

log = get_logger("ingest")


@dataclass
class IngestStats:
    seen: int = 0
    changed: int = 0
    skipped: int = 0
    failed: int = 0
    pruned: int = 0
    chunks: int = 0


def _git(args: list[str], cwd: Path | None = None) -> str:
    out = subprocess.run(["git", *args], cwd=cwd, check=True, capture_output=True, text=True, timeout=600)
    return out.stdout.strip()


def ensure_source(repo_url: str, target: Path, refresh: bool) -> str | None:
    """Clone (or update) the upstream repo; return the commit SHA being indexed."""
    if not (target / ".git").exists():
        target.parent.mkdir(parents=True, exist_ok=True)
        log.info("cloning transcript repository", extra={"repo": repo_url, "target": str(target)})
        _git(["clone", "--depth", "1", repo_url, str(target)])
    elif refresh:
        log.info("updating transcript repository", extra={"target": str(target)})
        _git(["fetch", "--depth", "1", "origin"], cwd=target)
        _git(["reset", "--hard", "origin/HEAD"], cwd=target)
    return _git(["rev-parse", "HEAD"], cwd=target)


def _slug_to_guest(slug: str) -> str:
    return slug.replace("_", " ").replace("-", " ").title()


def ingest_directory(
    engine: Engine,
    root: Path,
    *,
    repo_label: str,
    commit: str | None,
    target_words: int,
    overlap_words: int,
    limit: int | None = None,
    prune: bool = True,
) -> IngestStats:
    episodes_dir = root / "episodes"
    if not episodes_dir.is_dir():
        raise FileNotFoundError(f"{episodes_dir} not found. Expected episodes/<slug>/transcript.md")
    files = sorted(episodes_dir.glob("*/transcript.md"))
    if limit:
        files = files[:limit]
    stats = IngestStats()

    with engine.begin() as conn:
        run_id = conn.execute(
            insert(IngestionRun).values(source_repo=repo_label, source_commit=commit).returning(IngestionRun.id)
        ).scalar_one()

    try:
        with engine.connect() as conn:
            existing = {r.slug: (r.id, r.content_hash) for r in conn.execute(select(TranscriptDocument))}
        seen_slugs: set[str] = set()

        for path in files:
            slug = path.parent.name
            seen_slugs.add(slug)
            stats.seen += 1
            raw = path.read_text(encoding="utf-8")
            digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
            if slug in existing and existing[slug][1] == digest:
                stats.skipped += 1
                continue
            try:
                parsed = parse_transcript(raw)
            except TranscriptParseError as exc:
                stats.failed += 1
                log.warning("skipping unparseable transcript", extra={"slug": slug, "reason": str(exc)})
                continue
            chunks = chunk_turns(parsed.turns, target_words, overlap_words)
            m = parsed.meta
            doc_values = dict(
                slug=slug,
                guest=str(m.get("guest") or _slug_to_guest(slug))[:300],
                title=str(m.get("title") or m.get("guest") or _slug_to_guest(slug))[:500],
                youtube_url=m.get("youtube_url"),
                video_id=m.get("video_id"),
                publish_date=m.get("publish_date"),
                description=(str(m["description"]).strip() if m.get("description") else None),
                keywords=[str(k) for k in (m.get("keywords") or [])],
                duration_seconds=float(m["duration_seconds"]) if m.get("duration_seconds") else None,
                source_repo=repo_label,
                source_commit=commit,
                source_path=f"episodes/{slug}/transcript.md",
                content_hash=digest,
            )
            with engine.begin() as conn:
                if slug in existing:
                    doc_id = existing[slug][0]
                    conn.execute(delete(TranscriptChunk).where(TranscriptChunk.document_id == doc_id))
                    conn.execute(update(TranscriptDocument).where(TranscriptDocument.id == doc_id).values(**doc_values))
                else:
                    doc_id = conn.execute(
                        insert(TranscriptDocument).values(**doc_values).returning(TranscriptDocument.id)
                    ).scalar_one()
                conn.execute(
                    insert(TranscriptChunk),
                    [
                        dict(
                            document_id=doc_id,
                            chunk_index=c.index,
                            start_seconds=c.start_seconds,
                            end_seconds=c.end_seconds,
                            speakers=c.speakers,
                            text=c.text,
                            word_count=c.word_count,
                        )
                        for c in chunks
                    ],
                )
            stats.changed += 1
            stats.chunks += len(chunks)
            if stats.changed % 25 == 0:
                log.info("progress", extra={"changed": stats.changed, "seen": stats.seen})

        if prune and not limit:
            gone = [s for s in existing if s not in seen_slugs]
            if gone:
                with engine.begin() as conn:
                    conn.execute(delete(TranscriptDocument).where(TranscriptDocument.slug.in_(gone)))
                stats.pruned = len(gone)

        if stats.failed and stats.changed + stats.skipped == 0:
            raise RuntimeError(f"all {stats.failed} document(s) failed to parse; check the transcript layout")
        warning = f"{stats.failed} document(s) failed to parse and were skipped" if stats.failed else None
        with engine.begin() as conn:
            conn.execute(
                update(IngestionRun)
                .where(IngestionRun.id == run_id)
                .values(
                    error=warning,
                    status="complete",
                    finished_at=__import__("sqlalchemy").func.now(),
                    documents_seen=stats.seen,
                    documents_changed=stats.changed,
                    documents_skipped=stats.skipped,
                    chunks_written=stats.chunks,
                )
            )
    except Exception as exc:
        with engine.begin() as conn:
            conn.execute(
                update(IngestionRun)
                .where(IngestionRun.id == run_id)
                .values(status="failed", error=str(exc)[:2000], finished_at=__import__("sqlalchemy").func.now())
            )
        raise
    return stats


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Index Lenny's Podcast transcripts into PostgreSQL.")
    ap.add_argument("--path", help="Index a local folder (layout: episodes/<slug>/transcript.md) instead of cloning.")
    ap.add_argument("--refresh", action="store_true", help="git fetch/reset the cloned repo before indexing.")
    ap.add_argument("--limit", type=int, help="Index only the first N episodes (dev/testing).")
    ap.add_argument("--no-prune", action="store_true", help="Keep documents that no longer exist upstream.")
    args = ap.parse_args(argv)

    s = get_settings()
    configure_logging(s.log_level, s.log_format)
    engine = create_engine(s.database_url, connect_args={"connect_timeout": s.db_connect_timeout_seconds, "prepare_threshold": None})

    try:
        if args.path:
            root, label, commit = Path(args.path).resolve(), f"local:{Path(args.path).name}", None
        else:
            root = Path(s.transcripts_dir).resolve()
            label = s.transcripts_repo_url
            commit = ensure_source(s.transcripts_repo_url, root, args.refresh)
    except (subprocess.SubprocessError, FileNotFoundError, OSError) as exc:
        log.error("could not obtain transcripts", extra={"reason": str(exc)})
        print(
            "\nCould not clone the transcript repository (network blocked?).\n"
            "Download it manually or supply your own permitted transcripts, then run:\n"
            "  python -m app.ingest --path /path/to/folder   # containing episodes/<slug>/transcript.md\n",
            file=sys.stderr,
        )
        return 2

    log.info("terms notice", extra={"notice": "Upstream README: transcripts are for personal and educational use."})
    try:
        stats = ingest_directory(
            engine,
            root,
            repo_label=label,
            commit=commit,
            target_words=s.chunk_target_words,
            overlap_words=s.chunk_overlap_words,
            limit=args.limit,
            prune=not args.no_prune,
        )
    except Exception as exc:
        log.error("ingestion failed", exc_info=exc)
        return 1
    log.info("ingestion complete", extra=stats.__dict__ | {"commit": commit})
    print(
        f"Ingested: seen={stats.seen} changed={stats.changed} skipped={stats.skipped} "
        f"failed={stats.failed} pruned={stats.pruned} chunks_written={stats.chunks} commit={commit}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
