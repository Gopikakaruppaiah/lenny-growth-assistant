from __future__ import annotations

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from sqlalchemy import text

from .. import __version__
from ..schemas import HealthOut, ReadyOut
from .providers import provider_statuses

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthOut)
async def liveness() -> HealthOut:
    """Process is up. Touches no dependencies, so orchestrators can use it for liveness."""
    return HealthOut(version=__version__)


@router.get("/health/ready", response_model=ReadyOut, responses={503: {"model": ReadyOut}})
async def readiness(request: Request):
    """Database reachable + knowledge base indexed + provider status. 503 only if the database is down."""
    providers = await provider_statuses(request)
    try:
        async with request.app.state.session_factory() as db:
            await db.execute(text("SELECT 1"))
            n = (await db.execute(text("SELECT count(*) FROM transcript_chunks"))).scalar_one()
        body = ReadyOut(status="ready" if n else "degraded", database="up", knowledge_base="indexed" if n else "empty", providers=providers)
        return body
    except Exception:  # noqa: BLE001
        body = ReadyOut(status="degraded", database="down", knowledge_base="unknown", providers=providers)
        return JSONResponse(status_code=503, content=body.model_dump())
