"""Provider-neutral LLM interface and error taxonomy."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any, Literal


class ProviderError(Exception):
    """Base class. ``code`` is stable/machine-readable, ``hint`` is an actionable next step."""

    code = "provider_error"
    http_status = 502

    def __init__(self, message: str, hint: str | None = None, provider: str | None = None) -> None:
        super().__init__(message)
        self.message = message
        self.hint = hint
        self.provider = provider


class ProviderNotConfigured(ProviderError):
    code = "provider_not_configured"
    http_status = 503


class ProviderUnavailable(ProviderError):
    code = "provider_unavailable"
    http_status = 503


class ProviderModelMissing(ProviderError):
    code = "model_not_installed"
    http_status = 503


class ProviderTimeout(ProviderError):
    code = "model_timeout"
    http_status = 504


class ProviderRateLimited(ProviderError):
    code = "provider_rate_limited"
    http_status = 429


class ProviderAuthError(ProviderError):
    code = "provider_auth_failed"
    http_status = 502


class ProviderBadResponse(ProviderError):
    code = "provider_bad_response"
    http_status = 502


@dataclass
class ChatTurn:
    role: Literal["user", "assistant"]
    content: str


# A tool the agent may call to search the transcript index. Returns model-readable text.
SearchTool = Callable[[str], Awaitable[str]]


@dataclass
class GenerationRequest:
    system: str
    turns: list[ChatTurn]
    max_tokens: int = 1800
    temperature: float = 0.3
    timeout_s: float = 120.0
    search_tool: SearchTool | None = None  # only honoured by agentic providers


@dataclass
class GenerationResult:
    text: str
    provider: str
    model: str
    usage: dict[str, Any] = field(default_factory=dict)
    tool_calls: int = 0


@dataclass
class ProviderStatus:
    name: str
    model: str
    ready: bool
    detail: str
    hint: str | None = None
    kind: Literal["local", "cloud"] = "local"
    agentic: bool = False


class LLMProvider(ABC):
    name: str
    model: str

    @abstractmethod
    async def generate(self, req: GenerationRequest) -> GenerationResult: ...

    @abstractmethod
    async def status(self) -> ProviderStatus: ...
