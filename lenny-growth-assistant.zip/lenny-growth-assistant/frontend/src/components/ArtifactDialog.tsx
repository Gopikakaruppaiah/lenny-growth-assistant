import { useEffect, useRef, useState } from "react";

export function ArtifactDialog({ onSubmit, onCancel, initial }: { onSubmit: (kind: "markdown" | "html", instruction: string) => void; onCancel: () => void; initial: string }) {
  const [kind, setKind] = useState<"markdown" | "html">("markdown");
  const [text, setText] = useState(initial);
  const ref = useRef<HTMLTextAreaElement>(null);
  useEffect(() => { ref.current?.focus(); }, []);
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onCancel();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onCancel]);
  const valid = text.trim().length >= 3;
  return (
    <div className="scrim" onMouseDown={(e) => e.target === e.currentTarget && onCancel()}>
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="art-title">
        <h2 id="art-title">Create an artifact</h2>
        <p className="muted">Generated from this conversation and grounded in the transcripts.</p>
        <fieldset className="kinds">
          <legend className="sr-only">Format</legend>
          {(["markdown", "html"] as const).map((k) => (
            <label key={k} className={kind === k ? "on" : ""}>
              <input type="radio" name="kind" checked={kind === k} onChange={() => setKind(k)} />
              <strong>{k === "markdown" ? "Markdown document" : "HTML / CSS page"}</strong>
              <span className="muted">{k === "markdown" ? "Checklists, briefs, playbooks" : "Styled one-pagers, dashboards, posters"}</span>
            </label>
          ))}
        </fieldset>
        <label htmlFor="art-instr" className="field-label">What should it contain?</label>
        <textarea id="art-instr" ref={ref} value={text} maxLength={1000} rows={4} onChange={(e) => setText(e.target.value)} placeholder="e.g. A one-page checklist for improving onboarding activation" />
        <div className="row end">
          <button type="button" className="btn" onClick={onCancel}>Cancel</button>
          <button type="button" className="btn primary" disabled={!valid} onClick={() => onSubmit(kind, text.trim())}>Generate</button>
        </div>
      </div>
    </div>
  );
}
