"""Pure unit tests: parsing, chunking, query building, citations, routing, config, logging."""

import pytest

from app.config import Settings
from app.logging_setup import redact
from app.rag.chunking import chunk_turns
from app.rag.citations import split_verdict, validate_citations
from app.rag.parsing import TranscriptParseError, parse_transcript, ts_to_seconds
from app.rag.query import build_query, significant_terms
from app.rag.retrieval import SourceRef, SourceRegistry
from app.skills.router import route_message

FM = "---\nguest: G\ntitle: T\npublish_date: 2024-02-03\nkeywords:\n- a\n---\n\n# T\n\n## Transcript\n\n"


def test_parse_format_a_with_continuation_speaker():
    p = parse_transcript(FM + "Ann (00:00:05):\nHello there.\n\n(00:01:10):\nMore from Ann.\n\nLenny (01:02:03):\nQ?\n")
    assert [(t.speaker, t.start_seconds) for t in p.turns] == [("Ann", 5), ("Ann", 70), ("Lenny", 3723)]
    assert str(p.meta["publish_date"]) == "2024-02-03"


def test_parse_format_b_inline_and_c_untimed():
    b = parse_transcript(FM + "[00:00:00] Ryan: first\n[00:00:28] Lenny: second\n[00:01:00] Ryan: third\n")
    assert b.turns[1].speaker == "Lenny" and b.turns[1].start_seconds == 28
    c = parse_transcript(FM + "Adriel Frederick:\nfirst words\n\nLenny:\nsecond\n\nAdriel Frederick:\nthird\n")
    assert c.turns[0].start_seconds is None and len(c.turns) == 3


def test_parse_errors():
    with pytest.raises(TranscriptParseError):
        parse_transcript("no frontmatter here")
    with pytest.raises(TranscriptParseError):
        parse_transcript(FM + "just prose with no speaker turns at all\n")


def test_ts_to_seconds():
    assert ts_to_seconds("1:02:03") == 3723 and ts_to_seconds("02:03") == 123


def test_chunking_respects_target_and_keeps_timestamps():
    p = parse_transcript(FM + "".join(f"Ann ({i // 60:02d}:{i % 60:02d}:00):\n" + ("word " * 80) + "\n\n" for i in range(12)))
    chunks = chunk_turns(p.turns, target_words=200, overlap_words=100)
    assert len(chunks) > 3
    assert all(c.word_count <= 320 for c in chunks)
    assert chunks[0].start_seconds == 0
    assert [c.index for c in chunks] == list(range(len(chunks)))


def test_chunking_splits_a_giant_turn_and_rejects_bad_target():
    p = parse_transcript(FM + "Ann (00:00:00):\n" + ("Sentence one is here. " * 400) + "\n\nLenny (00:05:00):\nok\n\nAnn (00:06:00):\nfine\n\nLenny (00:07:00):\nyes\n")
    assert max(c.word_count for c in chunk_turns(p.turns, 100, 10)) < 200
    with pytest.raises(ValueError):
        chunk_turns(p.turns, 0)


def test_query_drops_stopwords_and_builds_phrases():
    q = build_query("How do I know if I have product-market fit?")
    assert "product-market" in q.terms and "how" not in q.terms
    assert "|" in q.tsquery or q.tsquery


def test_query_is_safe_against_tsquery_syntax_injection():
    q = build_query("pricing') | !drop & (table:* <-> x'; --")
    assert all(ch not in q.tsquery.replace(" | ", "").replace(" <-> ", "").replace("(", "").replace(")", "") for ch in "!&:*';-")


def test_followup_condenses_previous_user_message():
    q = build_query("what about enterprise?", ["How should I price a B2B SaaS product?"])
    assert "enterprise" in q.terms and "pricing" not in q.terms and "price" in q.terms
    standalone = build_query("What are the most common onboarding mistakes for consumer apps?", ["unrelated pricing question"])
    assert "pricing" not in standalone.terms


def test_empty_and_meta_only_queries_have_no_terms():
    assert build_query("write an essay please").tsquery == ""
    assert significant_terms("the and of") == []


def _reg(n=3):
    r = SourceRegistry()
    for i in range(1, n + 1):
        r.add(SourceRef(i, f"s{i}", f"G{i}", f"T{i}", None, None, None, None, 0, "0:00", "x", 1.0))
    return r


def test_verdict_split():
    assert split_verdict("[[VERDICT: partial]]\nbody") == ("PARTIAL", "body")
    assert split_verdict("no verdict") == (None, "no verdict")


def test_valid_citations_are_marked_and_invalid_are_stripped():
    reg = _reg(3)
    rep = validate_citations("[[VERDICT: SUPPORTED]]\nA claim [1]. Another [2, 9]. Fake [7].", reg)
    assert rep.cited == [1, 2] and rep.invalid == [7, 9]
    assert "[7]" not in rep.text and "[9]" not in rep.text and "[1]" in rep.text
    assert reg.get(1).cited and reg.get(2).cited and not reg.get(3).cited
    assert rep.grounded and any("Removed 2" in w for w in rep.warnings)


def test_supported_without_citations_is_not_grounded():
    rep = validate_citations("[[VERDICT: SUPPORTED]]\nNo cites here.", _reg())
    assert not rep.grounded and any("ungrounded" in w for w in rep.warnings)


def test_unsupported_verdict_is_never_grounded():
    assert not validate_citations("[[VERDICT: UNSUPPORTED]]\nNot covered [1].", _reg()).grounded


@pytest.mark.parametrize("text,intent,kind", [
    ("write a 1250 word essay on onboarding", "essay", None),
    ("Turn this into a Ship 30 post", "essay", None),
    ("create an HTML landing page for our pricing playbook", "artifact", "html"),
    ("make a markdown checklist for launches", "artifact", "markdown"),
    ("build me a one-pager on retention", "artifact", "markdown"),
    ("how do I improve onboarding?", "chat", None),
    ("what do guests say about writing PRDs?", "chat", None),
])
def test_router(text, intent, kind):
    r = route_message(text)
    assert (r.intent, r.artifact_kind) == (intent, kind)


def test_config_rejects_wildcard_cors_and_normalises_db_url():
    with pytest.raises(ValueError):
        Settings(cors_allowed_origins="*")
    assert Settings(database_url="postgres://u:p@h/db").database_url.startswith("postgresql+psycopg://")
    assert Settings(database_url="postgresql://u:p@h/db").database_url.startswith("postgresql+psycopg://")
    assert Settings(cors_allowed_origins="http://a.com/, https://b.com").cors_origins == ["http://a.com", "https://b.com"]


def test_anthropic_configured_flag():
    assert not Settings(anthropic_api_key=None).anthropic_configured
    assert not Settings(anthropic_api_key="  ").anthropic_configured
    assert Settings(anthropic_api_key="sk-ant-x").anthropic_configured


def test_log_redaction():
    assert "sk-ant-abcdefghijklmnop1234" not in redact("key sk-ant-abcdefghijklmnop1234 leaked")
    assert "hunter2" not in redact("postgresql://user:hunter2@host/db")
    assert "hunter2" not in redact('api_key="hunter2"')


def test_hyphenated_terms_become_phrases_not_fused_tokens():
    """Regression: 'product-market' used to become the never-matching token 'productmarket'."""
    q = build_query("How do I know if I have product-market fit?")
    assert "productmarket" not in q.tsquery
    assert "(product <-> market <-> fit)" in q.tsquery


def test_nonsense_after_a_real_question_does_not_inherit_the_previous_topic():
    """Regression found by the real-corpus smoke test."""
    q = build_query("zzqxv wwkpl", ["How should I price a B2B SaaS product?"])
    assert "price" not in q.terms and q.terms == ["zzqxv", "wwkpl"]
    assert "enterprise" in build_query("enterprise?", ["How should I price a B2B SaaS product?"]).terms and "price" in build_query("enterprise?", ["How should I price a B2B SaaS product?"]).terms
