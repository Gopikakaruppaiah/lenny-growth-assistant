"""Initial schema: users, sessions, messages, artifacts, transcript index, ingestion runs.

Revision ID: 0001
Revises:
"""

import sqlalchemy as sa
from sqlalchemy.dialects import postgresql as pg

from alembic import op

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

UUID = pg.UUID(as_uuid=True)
NOW = sa.text("now()")
GEN = sa.text("gen_random_uuid()")


def upgrade() -> None:
    op.create_table(
        "users",
        sa.Column("id", UUID, primary_key=True, server_default=GEN),
        sa.Column("client_id", sa.String(64), nullable=False, unique=True),
        sa.Column("metadata", pg.JSONB, nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=NOW),
        sa.Column("last_seen_at", sa.DateTime(timezone=True), nullable=False, server_default=NOW),
    )
    op.create_table(
        "chat_sessions",
        sa.Column("id", UUID, primary_key=True, server_default=GEN),
        sa.Column("user_id", UUID, sa.ForeignKey("users.id", ondelete="CASCADE"), nullable=False),
        sa.Column("title", sa.String(120), nullable=False, server_default="New chat"),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=NOW),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False, server_default=NOW),
    )
    op.create_index("ix_chat_sessions_user_updated", "chat_sessions", ["user_id", "updated_at"])
    op.create_table(
        "messages",
        sa.Column("id", UUID, primary_key=True, server_default=GEN),
        sa.Column("session_id", UUID, sa.ForeignKey("chat_sessions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("role", sa.String(16), nullable=False),
        sa.Column("kind", sa.String(16), nullable=False, server_default="chat"),
        sa.Column("status", sa.String(16), nullable=False, server_default="complete"),
        sa.Column("content", sa.Text, nullable=False, server_default=""),
        sa.Column("provider", sa.String(32)),
        sa.Column("model", sa.String(128)),
        sa.Column("fallback_from", sa.String(32)),
        sa.Column("sources", pg.JSONB, nullable=False, server_default=sa.text("'[]'::jsonb")),
        sa.Column("meta", pg.JSONB, nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("error_code", sa.String(64)),
        sa.Column("error_message", sa.Text),
        sa.Column("error_hint", sa.Text),
        sa.Column("latency_ms", sa.Integer),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=NOW),
        sa.Column("completed_at", sa.DateTime(timezone=True)),
        sa.CheckConstraint("role in ('user','assistant')", name="ck_messages_role"),
        sa.CheckConstraint("kind in ('chat','essay','artifact')", name="ck_messages_kind"),
        sa.CheckConstraint("status in ('pending','complete','error')", name="ck_messages_status"),
    )
    op.create_index("ix_messages_session_created", "messages", ["session_id", "created_at"])
    op.create_table(
        "artifacts",
        sa.Column("id", UUID, primary_key=True, server_default=GEN),
        sa.Column("session_id", UUID, sa.ForeignKey("chat_sessions.id", ondelete="CASCADE"), nullable=False),
        sa.Column("message_id", UUID, sa.ForeignKey("messages.id", ondelete="SET NULL")),
        sa.Column("kind", sa.String(16), nullable=False),
        sa.Column("title", sa.String(200), nullable=False),
        sa.Column("content", sa.Text, nullable=False),
        sa.Column("provider", sa.String(32)),
        sa.Column("model", sa.String(128)),
        sa.Column("sanitizer_report", pg.JSONB, nullable=False, server_default=sa.text("'{}'::jsonb")),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False, server_default=NOW),
        sa.CheckConstraint("kind in ('markdown','html')", name="ck_artifacts_kind"),
    )
    op.create_index("ix_artifacts_session_created", "artifacts", ["session_id", "created_at"])

    op.create_table(
        "transcript_documents",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("slug", sa.String(200), nullable=False, unique=True),
        sa.Column("guest", sa.String(300), nullable=False),
        sa.Column("title", sa.String(500), nullable=False),
        sa.Column("youtube_url", sa.String(300)),
        sa.Column("video_id", sa.String(32)),
        sa.Column("publish_date", sa.Date),
        sa.Column("description", sa.Text),
        sa.Column("keywords", pg.JSONB, nullable=False, server_default=sa.text("'[]'::jsonb")),
        sa.Column("duration_seconds", sa.Float),
        sa.Column("source_repo", sa.String(300), nullable=False),
        sa.Column("source_commit", sa.String(64)),
        sa.Column("source_path", sa.String(400), nullable=False),
        sa.Column("content_hash", sa.String(64), nullable=False),
        sa.Column("ingested_at", sa.DateTime(timezone=True), nullable=False, server_default=NOW),
    )
    op.create_table(
        "transcript_chunks",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("document_id", sa.BigInteger, sa.ForeignKey("transcript_documents.id", ondelete="CASCADE"), nullable=False),
        sa.Column("chunk_index", sa.Integer, nullable=False),
        sa.Column("start_seconds", sa.Integer),
        sa.Column("end_seconds", sa.Integer),
        sa.Column("speakers", pg.JSONB, nullable=False, server_default=sa.text("'[]'::jsonb")),
        sa.Column("text", sa.Text, nullable=False),
        sa.Column("word_count", sa.Integer, nullable=False),
        sa.Column("tsv", pg.TSVECTOR, sa.Computed("to_tsvector('english', text)", persisted=True)),
    )
    op.create_index("ix_chunks_doc_idx", "transcript_chunks", ["document_id", "chunk_index"], unique=True)
    op.create_index("ix_chunks_tsv", "transcript_chunks", ["tsv"], postgresql_using="gin")

    op.create_table(
        "ingestion_runs",
        sa.Column("id", sa.BigInteger, primary_key=True, autoincrement=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=False, server_default=NOW),
        sa.Column("finished_at", sa.DateTime(timezone=True)),
        sa.Column("source_repo", sa.String(300), nullable=False),
        sa.Column("source_commit", sa.String(64)),
        sa.Column("status", sa.String(16), nullable=False, server_default="running"),
        sa.Column("documents_seen", sa.Integer, nullable=False, server_default="0"),
        sa.Column("documents_changed", sa.Integer, nullable=False, server_default="0"),
        sa.Column("documents_skipped", sa.Integer, nullable=False, server_default="0"),
        sa.Column("chunks_written", sa.Integer, nullable=False, server_default="0"),
        sa.Column("error", sa.Text),
    )


def downgrade() -> None:
    for table in (
        "ingestion_runs",
        "transcript_chunks",
        "transcript_documents",
        "artifacts",
        "messages",
        "chat_sessions",
        "users",
    ):
        op.drop_table(table)
