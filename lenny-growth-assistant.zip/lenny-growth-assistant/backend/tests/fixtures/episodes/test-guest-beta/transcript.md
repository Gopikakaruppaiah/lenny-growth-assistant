---
guest: Test Guest Beta
title: "Synthetic - pricing and packaging"
youtube_url: https://www.youtube.com/watch?v=BBBBBBBBBBB
video_id: BBBBBBBBBBB
publish_date: 2024-01-15
description: SYNTHETIC TEST FIXTURE - not real transcript content.
duration_seconds: 3600.0
keywords:
- onboarding
---

# Synthetic: pricing and packaging

## Transcript

Lenny (00:00:00):
Tell me more about this part. Pricing for a B2B SaaS product should be anchored to value metrics like seats or usage and tested with customers.

Test Guest Beta (00:01:00):
Pricing for a B2B SaaS product should be anchored to value metrics like seats or usage and tested with customers. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

Lenny (00:03:00):
Tell me more about this part. Packaging tiers help enterprise buyers self-select, and annual contracts improve retention.

Test Guest Beta (00:04:00):
Packaging tiers help enterprise buyers self-select, and annual contracts improve retention. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

Lenny (00:06:00):
Tell me more about this part. Onboarding of enterprise customers needs a human touch to reach activation.

Test Guest Beta (00:07:00):
Onboarding of enterprise customers needs a human touch to reach activation. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. This is filler text for the synthetic test corpus. 

