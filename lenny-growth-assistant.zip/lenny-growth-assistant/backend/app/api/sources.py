from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..deps import get_db
from ..models import IngestionRun, TranscriptChunk, TranscriptDocument
from ..rag.retrieval import SourceRegistry, retrieve
from ..schemas import CorpusStats

router = APIRouter(prefix="/sources", tags=["sources"])


@router.get("/stats", response_model=CorpusStats)
async def stats(db: AsyncSession = Depends(get_db)) -> CorpusStats:
    episodes = (await db.execute(select(func.count()).select_from(TranscriptDocument))).scalar_one()
    chunks = (await db.execute(select(func.count()).select_from(TranscriptChunk))).scalar_one()
    run = (await db.execute(select(IngestionRun).where(IngestionRun.status == "complete").order_by(IngestionRun.id.desc()).limit(1))).scalar_one_or_none()
    return CorpusStats(episodes=episodes, chunks=chunks, last_ingested_at=run.finished_at if run else None,
                       source_repo=run.source_repo if run else None, source_commit=run.source_commit if run else None)


@router.get("/search")
async def search(request: Request, q: str = Query(min_length=2, max_length=300), limit: int = Query(5, ge=1, le=10),
                 db: AsyncSession = Depends(get_db)) -> dict:
    """Debug/inspection endpoint: what would be retrieved for this query (no model call)."""
    s = request.app.state.settings
    r = await retrieve(db, q, None, top_k=limit, max_per_episode=s.retrieval_max_per_episode, min_coverage=s.retrieval_min_coverage, registry=SourceRegistry())
    return {"query": r.query.condensed_text, "sufficient": r.sufficient, "reason": r.reason,
            "sources": [x.to_public() for x in r.sources]}
