"""Verdict protocol + citation validation.

The model is told to start with ``[[VERDICT: SUPPORTED|PARTIAL|UNSUPPORTED]]`` and to cite
excerpts as ``[n]``. We never trust either: every ``[n]`` is checked against the sources that
were actually retrieved for *this* request, and invalid ones are stripped and reported.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

from .retrieval import SourceRegistry

_VERDICT_RE = re.compile(r"\[\[\s*VERDICT\s*:\s*(SUPPORTED|PARTIAL|UNSUPPORTED)\s*\]\]", re.I)
_CITE_RE = re.compile(r"\[(\d{1,3}(?:\s*,\s*\d{1,3})*)\]")

NOT_ENOUGH = "I couldn't find enough in Lenny's Podcast transcripts to answer that."


@dataclass
class CitationReport:
    text: str
    verdict: str | None
    cited: list[int] = field(default_factory=list)
    invalid: list[int] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def grounded(self) -> bool:
        return self.verdict != "UNSUPPORTED" and bool(self.cited)


def split_verdict(text: str) -> tuple[str | None, str]:
    m = _VERDICT_RE.search(text)
    if not m:
        return None, text.strip()
    verdict = m.group(1).upper()
    return verdict, (text[: m.start()] + text[m.end() :]).strip()


def validate_citations(text: str, registry: SourceRegistry, *, mark: bool = True) -> CitationReport:
    verdict, body = split_verdict(text)
    cited: list[int] = []
    invalid: list[int] = []

    def repl(m: re.Match[str]) -> str:
        nums = [int(x) for x in re.split(r"\s*,\s*", m.group(1))]
        good = [n for n in nums if registry.get(n) is not None]
        for n in nums:
            if n in good:
                if n not in cited:
                    cited.append(n)
            elif n not in invalid:
                invalid.append(n)
        return "[" + ", ".join(str(n) for n in good) + "]" if good else ""

    cleaned = _CITE_RE.sub(repl, body)
    cleaned = re.sub(r"[ \t]+([.,;:!?])", r"\1", cleaned)
    cleaned = re.sub(r"[ \t]{2,}", " ", cleaned).strip()

    warnings: list[str] = []
    if invalid:
        warnings.append(f"Removed {len(invalid)} citation(s) that did not match any retrieved source: {sorted(invalid)}")
    if verdict is None:
        warnings.append("The model did not state a grounding verdict.")
    if verdict in (None, "SUPPORTED", "PARTIAL") and not cited:
        warnings.append("No valid transcript citation was produced; treat this answer as ungrounded.")
    if mark:
        for n in cited:
            ref = registry.get(n)
            if ref:
                ref.cited = True
    return CitationReport(cleaned, verdict, sorted(cited), sorted(invalid), warnings)
