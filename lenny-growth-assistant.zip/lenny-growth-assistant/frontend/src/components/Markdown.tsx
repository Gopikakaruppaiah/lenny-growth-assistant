import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { linkifyCitations } from "../lib/artifactFrame";

/**
 * Markdown renderer. react-markdown does NOT render raw HTML (no rehype-raw), so model output
 * can't inject elements; unsafe URL schemes are dropped by its default urlTransform.
 */
export function Markdown({ text, onCite }: { text: string; onCite?: (n: number) => void }) {
  return (
    <div className="md">
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          a({ href, children }) {
            const cite = href?.match(/^#src-(\d+)$/);
            if (cite) {
              const n = Number(cite[1]);
              return (
                <button type="button" className="cite" onClick={() => onCite?.(n)} aria-label={`Show source ${n}`}>
                  {n}
                </button>
              );
            }
            return <a href={href} target="_blank" rel="noopener noreferrer nofollow">{children}</a>;
          },
        }}
      >
        {linkifyCitations(text)}
      </ReactMarkdown>
    </div>
  );
}
