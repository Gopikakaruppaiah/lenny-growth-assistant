import type { Accepted, Artifact, CorpusStats, Message, ProviderName, ProvidersResponse, Session } from "./types";

/** Canonical API base URL. Injected at build time; see frontend/.env.example. */
export const API_BASE_URL: string = (import.meta.env.VITE_API_BASE_URL ?? "http://localhost:8000").replace(/\/+$/, "");
const API = `${API_BASE_URL}/api/v1`;

export class ApiError extends Error {
  constructor(
    public code: string,
    message: string,
    public status: number,
    public hint?: string,
    public requestId?: string,
  ) {
    super(message);
  }
}

const CLIENT_KEY = "lga.client_id";
export function getClientId(): string {
  try {
    let id = localStorage.getItem(CLIENT_KEY);
    if (!id || !/^[A-Za-z0-9_-]{16,64}$/.test(id)) {
      id = crypto.randomUUID();
      localStorage.setItem(CLIENT_KEY, id);
    }
    return id;
  } catch {
    const g = globalThis as { __lgaId?: string };
    return (g.__lgaId ??= crypto.randomUUID()); // storage blocked: per-tab identity
  }
}

async function request<T>(path: string, init: RequestInit = {}, timeoutMs = 20000): Promise<T> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  let res: Response;
  try {
    res = await fetch(`${API}${path}`, {
      ...init,
      signal: ctrl.signal,
      headers: { "Content-Type": "application/json", "X-Client-Id": getClientId(), ...(init.headers ?? {}) },
    });
  } catch (e) {
    const aborted = e instanceof DOMException && e.name === "AbortError";
    throw new ApiError(
      aborted ? "request_timeout" : "network_error",
      aborted ? "The server took too long to respond." : `Can't reach the API at ${API_BASE_URL}.`,
      0,
      aborted ? "Try again in a moment." : "Is the backend running, and are VITE_API_BASE_URL and CORS_ALLOWED_ORIGINS set correctly?",
    );
  } finally {
    clearTimeout(timer);
  }
  if (res.status === 204) return undefined as T;
  let body: unknown = null;
  try { body = await res.json(); } catch { /* non-JSON body */ }
  if (!res.ok) {
    const err = (body as { error?: { code?: string; message?: string; hint?: string; request_id?: string } } | null)?.error;
    throw new ApiError(err?.code ?? "http_error", err?.message ?? `Request failed (${res.status}).`, res.status, err?.hint, err?.request_id);
  }
  return body as T;
}

const json = (b: unknown) => JSON.stringify(b);

export const api = {
  providers: () => request<ProvidersResponse>("/providers", {}, 8000),
  stats: () => request<CorpusStats>("/sources/stats", {}, 8000),
  listSessions: () => request<Session[]>("/sessions"),
  createSession: () => request<Session>("/sessions", { method: "POST", body: json({}) }),
  deleteSession: (id: string) => request<void>(`/sessions/${id}`, { method: "DELETE" }),
  listMessages: (sid: string) => request<Message[]>(`/sessions/${sid}/messages`),
  getMessage: (sid: string, mid: string) => request<Message>(`/sessions/${sid}/messages/${mid}`),
  send: (sid: string, content: string, provider?: ProviderName | null) =>
    request<Accepted>(`/sessions/${sid}/messages`, { method: "POST", body: json({ content, provider: provider ?? null }) }),
  essay: (sid: string, topic: string | null, provider?: ProviderName | null) =>
    request<Accepted>(`/sessions/${sid}/essay`, { method: "POST", body: json({ topic, provider: provider ?? null }) }),
  artifact: (sid: string, kind: "markdown" | "html", instruction: string, provider?: ProviderName | null) =>
    request<Accepted>(`/sessions/${sid}/artifacts`, { method: "POST", body: json({ kind, instruction, provider: provider ?? null }) }),
  retry: (sid: string, mid: string) => request<Message>(`/sessions/${sid}/messages/${mid}/retry`, { method: "POST" }),
  getArtifact: (id: string) => request<Artifact>(`/artifacts/${id}`),
};
