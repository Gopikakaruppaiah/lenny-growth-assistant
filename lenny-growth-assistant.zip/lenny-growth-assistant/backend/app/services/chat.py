"""Orchestration: persistence + retrieval + provider routing + skills, run as background jobs."""

from __future__ import annotations

import asyncio
import time
import uuid
from collections.abc import Awaitable, Callable
from typing import Any

from sqlalchemy import func, select, update
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from ..config import Settings
from ..errors import AppError
from ..llm.base import ChatTurn, GenerationRequest, GenerationResult, ProviderError
from ..llm.registry import ProviderRegistry
from ..logging_setup import get_logger
from ..models import Artifact, ChatSession, Message
from ..rag.citations import NOT_ENOUGH, validate_citations
from ..rag.retrieval import SourceRegistry, retrieve
from ..skills import artifact as artifact_skill
from ..skills import ship30
from ..skills.prompts import AGENT_TOOL_ADDENDUM, GROUNDING_RULES, build_chat_user_turn, format_excerpts
from .jobs import JobManager

log = get_logger("chat")
HISTORY_MSG_CHARS = 1500
MAX_TOOL_SEARCHES = 3


class LLMRunner:
    """Runs model calls for one job. After a fallback, stays on the fallback (no repeated timeouts)."""

    def __init__(self, providers: ProviderRegistry, preferred: str | None) -> None:
        self.providers = providers
        self.preferred = preferred or providers.default_name
        self.fallback_from: str | None = None
        self.used: list[tuple[str, str]] = []
        self.tool_calls = 0
        self.usage: list[dict[str, Any]] = []

    async def run(self, req: GenerationRequest) -> GenerationResult:
        result, fb = await self.providers.generate(req, self.preferred)
        if fb:
            self.fallback_from = self.fallback_from or fb
            self.preferred = result.provider
        pair = (result.provider, result.model)
        if pair not in self.used:
            self.used.append(pair)
        self.tool_calls += result.tool_calls
        self.usage.append(result.usage)
        return result

    @property
    def provider(self) -> str | None:
        return self.used[-1][0] if self.used else None

    @property
    def model(self) -> str | None:
        return self.used[-1][1] if self.used else None


class ChatService:
    def __init__(self, settings: Settings, factory: async_sessionmaker[AsyncSession], providers: ProviderRegistry, jobs: JobManager) -> None:
        self.s = settings
        self.factory = factory
        self.providers = providers
        self.jobs = jobs

    # ------------------------------------------------------------- creating the message pair
    async def create_pair(
        self, db: AsyncSession, session: ChatSession, user_text: str, kind: str, params: dict[str, Any]
    ) -> tuple[Message, Message]:
        pending = (
            await db.execute(
                select(func.count()).select_from(Message).where(Message.session_id == session.id, Message.status == "pending")
            )
        ).scalar_one()
        if pending:
            raise AppError(
                409, "generation_in_progress", "This chat is still generating a reply.",
                "Wait for it to finish (or open a new chat) before sending another message.",
            )
        user_msg = Message(session_id=session.id, role="user", kind="chat", status="complete", content=user_text)
        asst = Message(session_id=session.id, role="assistant", kind=kind, status="pending", content="", meta={"params": params})
        db.add_all([user_msg, asst])
        if session.title == "New chat":
            session.title = (user_text[:60] + ("…" if len(user_text) > 60 else "")).replace("\n", " ")
        session.updated_at = func.now()
        await db.commit()
        await db.refresh(user_msg)
        await db.refresh(asst)
        return user_msg, asst

    def start(self, asst: Message, user_msg: Message, kind: str, provider: str | None, params: dict[str, Any]) -> None:
        self.jobs.spawn(str(asst.id), self.run_job(asst.id, asst.session_id, user_msg.id, user_msg.content, kind, provider, params))

    async def retry(self, db: AsyncSession, session: ChatSession, asst: Message) -> Message:
        if asst.role != "assistant" or asst.status != "error":
            raise AppError(409, "not_retryable", "Only failed assistant messages can be retried.")
        other = (
            await db.execute(select(func.count()).select_from(Message).where(Message.session_id == session.id, Message.status == "pending"))
        ).scalar_one()
        if other:
            raise AppError(409, "generation_in_progress", "This chat is still generating a reply.")
        user_msg = (
            await db.execute(
                select(Message).where(Message.session_id == session.id, Message.role == "user", Message.created_at <= asst.created_at)
                .order_by(Message.created_at.desc()).limit(1)
            )
        ).scalar_one()
        params = (asst.meta or {}).get("params", {})
        asst.status, asst.content, asst.error_code, asst.error_message, asst.error_hint = "pending", "", None, None, None
        asst.sources, asst.completed_at, asst.latency_ms = [], None, None
        asst.meta = {"params": params, "retry_of_error": True}
        await db.commit()
        self.start(asst, user_msg, asst.kind, params.get("provider"), params)
        return asst

    # ------------------------------------------------------------- job runner
    async def run_job(self, asst_id: uuid.UUID, session_id: uuid.UUID, user_msg_id: uuid.UUID, user_text: str,
                      kind: str, provider: str | None, params: dict[str, Any]) -> None:
        t0 = time.monotonic()
        runner = LLMRunner(self.providers, provider)
        log.info("job started", extra={"message_id": str(asst_id), "kind": kind, "provider": runner.preferred})
        try:
            async with self.factory() as db:
                total = self.s.essay_total_timeout_seconds if kind != "chat" else self.s.llm_timeout_seconds * 2
                async with asyncio.timeout(total):
                    handler: Callable[..., Awaitable[dict[str, Any]]] = {
                        "chat": self._chat, "essay": self._essay, "artifact": self._artifact,
                    }[kind]
                    fields = await handler(db, runner, session_id, user_msg_id, user_text, params, asst_id)
                await self._finish(db, asst_id, runner, t0, status="complete", **fields)
        except ProviderError as exc:
            await self._fail(asst_id, runner, t0, exc.code, exc.message, exc.hint)
        except ship30.InsufficientEvidence as exc:
            await self._finish_new(asst_id, runner, t0, status="complete", content=f"{NOT_ENOUGH}\n\n{exc}",
                                   sources=[], meta={"grounded": False, "verdict": "UNSUPPORTED", "reason": "insufficient_evidence"})
        except TimeoutError:
            await self._fail(asst_id, runner, t0, "job_timeout", "Generation took too long and was stopped.",
                             "Try a shorter request or a faster model, or raise ESSAY_TOTAL_TIMEOUT_SECONDS.")
        except asyncio.CancelledError:
            await self._fail(asst_id, runner, t0, "interrupted", "The server stopped while generating.", "Press Retry.")
            raise
        except Exception as exc:  # noqa: BLE001 - last line of defence for a background task
            log.error("job crashed", extra={"message_id": str(asst_id), "kind": kind}, exc_info=exc)
            await self._fail(asst_id, runner, t0, "internal_error", "Something went wrong while generating.", "Check the server logs, then Retry.")

    async def _finish(self, db: AsyncSession, asst_id: uuid.UUID, runner: LLMRunner, t0: float, **fields: Any) -> None:
        meta = {**fields.pop("meta", {}), "providers_used": [{"provider": p, "model": m} for p, m in runner.used],
                "tool_calls": runner.tool_calls}
        await db.execute(
            update(Message).where(Message.id == asst_id).values(
                provider=runner.provider, model=runner.model, fallback_from=runner.fallback_from, meta=meta,
                latency_ms=int((time.monotonic() - t0) * 1000), completed_at=func.now(), **fields,
            )
        )
        await db.commit()
        log.info("job complete", extra={"message_id": str(asst_id), "provider": runner.provider,
                                        "fallback_from": runner.fallback_from, "latency_ms": int((time.monotonic() - t0) * 1000)})

    async def _finish_new(self, asst_id, runner, t0, **fields) -> None:
        async with self.factory() as db:
            await self._finish(db, asst_id, runner, t0, **fields)

    async def _fail(self, asst_id: uuid.UUID, runner: LLMRunner, t0: float, code: str, message: str, hint: str | None) -> None:
        log.warning("job failed", extra={"message_id": str(asst_id), "error_code": code})
        try:
            async with self.factory() as db:
                await db.execute(
                    update(Message).where(Message.id == asst_id).values(
                        status="error", error_code=code, error_message=message, error_hint=hint,
                        provider=runner.provider, model=runner.model, fallback_from=runner.fallback_from,
                        latency_ms=int((time.monotonic() - t0) * 1000), completed_at=func.now(),
                    )
                )
                await db.commit()
        except Exception as exc:  # noqa: BLE001
            log.error("could not record job failure (database down?)", exc_info=exc)

    # ------------------------------------------------------------- context helpers
    async def _history(self, db: AsyncSession, session_id: uuid.UUID, exclude: uuid.UUID) -> list[Message]:
        rows = (
            await db.execute(
                select(Message).where(Message.session_id == session_id, Message.status == "complete", Message.id != exclude)
                .order_by(Message.created_at.desc()).limit(self.s.history_max_messages)
            )
        ).scalars().all()
        return list(reversed(rows))

    @staticmethod
    def _turns(history: list[Message]) -> list[ChatTurn]:
        return [ChatTurn(m.role, m.content[:HISTORY_MSG_CHARS]) for m in history if m.content]  # type: ignore[arg-type]

    # ------------------------------------------------------------- chat
    async def _chat(self, db, runner: LLMRunner, session_id, user_msg_id, user_text, params, asst_id) -> dict[str, Any]:
        history = await self._history(db, session_id, user_msg_id)
        prev_users = [m.content for m in history if m.role == "user"][-2:]
        registry = SourceRegistry()
        ret = await retrieve(db, user_text, prev_users, top_k=self.s.retrieval_top_k,
                             max_per_episode=self.s.retrieval_max_per_episode, min_coverage=self.s.retrieval_min_coverage, registry=registry)
        retrieval_meta = {"query": ret.query.condensed_text, "reason": ret.reason, "n_retrieved": len(ret.sources)}
        if not ret.sources:
            log.info("empty retrieval; skipping model call", extra={"reason": ret.reason})
            return {"content": f"{NOT_ENOUGH} No passages matched your question.\n\nTry rephrasing with product or growth terms (e.g. onboarding, pricing, retention).",
                    "sources": [], "meta": {"grounded": False, "verdict": "UNSUPPORTED", "retrieval": retrieval_meta, "model_called": False}}

        search_calls = 0

        async def search_tool(query: str) -> str:
            nonlocal search_calls
            search_calls += 1
            if search_calls > MAX_TOOL_SEARCHES:
                return "Search limit reached; answer with the excerpts you already have."
            r = await retrieve(db, query, None, top_k=5, max_per_episode=2, min_coverage=0.0, registry=registry)
            return format_excerpts(r.sources) if r.sources else "No matching passages."

        system = GROUNDING_RULES + (AGENT_TOOL_ADDENDUM if runner.preferred == "anthropic" else "")
        turns = self._turns(history) + [ChatTurn("user", build_chat_user_turn(user_text, registry.items))]
        req = GenerationRequest(system=system, turns=turns, max_tokens=1200, temperature=0.2,
                                timeout_s=self.s.llm_timeout_seconds, search_tool=search_tool)
        result = await runner.run(req)
        report = validate_citations(result.text, registry)
        content = report.text
        if report.verdict == "UNSUPPORTED":
            content = f"{NOT_ENOUGH}\n\n{content}" if not content.lower().startswith("i couldn") else content
        elif not report.cited:
            content += "\n\n> ⚠️ No transcript citation was produced for this answer. Treat it as ungrounded."
        sources = [s.to_public() for s in registry.items]  # cited ones carry cited=True; the rest are "also retrieved"
        return {"content": content, "sources": sources,
                "meta": {"grounded": report.grounded, "verdict": report.verdict, "citation_warnings": report.warnings,
                         "cited": report.cited, "retrieval": retrieval_meta, "model_called": True}}

    # ------------------------------------------------------------- essay
    async def _essay(self, db, runner: LLMRunner, session_id, user_msg_id, user_text, params, asst_id) -> dict[str, Any]:
        history = await self._history(db, session_id, user_msg_id)
        topic = params.get("topic") or user_text
        prev_users = [m.content for m in history if m.role == "user"][-2:]
        prior = next((m.content for m in reversed(history) if m.role == "assistant" and m.kind == "chat"), "")
        registry = SourceRegistry()
        ret = await retrieve(db, topic, prev_users, top_k=12, max_per_episode=2, min_coverage=0.0, registry=registry)
        result = await ship30.write_essay(run=runner.run, sources=ret.sources, registry=registry, topic=topic,
                                          prior_answer=prior, timeout_s=self.s.llm_timeout_seconds)
        return {"content": result.markdown, "sources": [s.to_public() for s in result.sources],
                "meta": {"grounded": bool(result.sources), "word_count": result.body_word_count, "target_words": ship30.TARGET_WORDS,
                         "meets_target": result.meets_target, "quality_checks": result.checks, "corrections": result.corrections,
                         "citation_warnings": result.warnings, "essay_plan": {"headline": result.plan.headline, "angle": result.plan.angle,
                         "approach": result.plan.approach, "fallback_plan": result.plan.used_fallback_plan}, "skill": "ship30@1.0"}}

    # ------------------------------------------------------------- artifact
    async def _artifact(self, db, runner: LLMRunner, session_id, user_msg_id, user_text, params, asst_id) -> dict[str, Any]:
        history = await self._history(db, session_id, user_msg_id)
        kind = params["kind"]
        instruction = params.get("instruction") or user_text
        prev_users = [m.content for m in history if m.role == "user"][-2:]
        registry = SourceRegistry()
        ret = await retrieve(db, instruction, prev_users, top_k=8, max_per_episode=2, min_coverage=0.0, registry=registry)
        if len(ret.sources) < 2:
            return {"content": f"{NOT_ENOUGH} I need at least a couple of relevant passages to build a grounded artifact.",
                    "sources": [], "meta": {"grounded": False, "verdict": "UNSUPPORTED", "model_called": False}}
        context = "\n".join(f"{m.role}: {m.content[:600]}" for m in history[-4:])
        res = await runner.run(artifact_skill.build_request(kind, instruction, ret.sources, context, self.s.llm_timeout_seconds))
        draft = artifact_skill.finalize_artifact(kind, res.text, instruction, registry)
        art = Artifact(session_id=session_id, message_id=asst_id, kind=draft.kind, title=draft.title, content=draft.content,
                       provider=runner.provider, model=runner.model, sanitizer_report=draft.report)
        db.add(art)
        await db.flush()
        used = [s.to_public() for s in registry.items if s.cited] or [s.to_public() for s in ret.sources[:5]]
        return {"content": f"Created a {draft.kind} artifact: **{draft.title}**. It is open in the viewer.", "sources": used,
                "meta": {"grounded": True, "artifact_id": str(art.id), "artifact_kind": draft.kind,
                         "sanitizer": draft.report, "citation_warnings": draft.warnings}}
