"""Consistent JSON error envelope.

Every non-2xx response has the shape::

    {"error": {"code": "...", "message": "...", "hint": "...", "request_id": "..."}}

``code`` is stable and machine-readable; ``message`` is safe to show to a user;
``hint`` tells them what to do next. Internal details are logged, never returned.
"""

from __future__ import annotations

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.exc import DBAPIError, InterfaceError, OperationalError, SQLAlchemyError
from starlette.exceptions import HTTPException as StarletteHTTPException

from .logging_setup import get_logger, request_id_var

log = get_logger("errors")


class AppError(Exception):
    def __init__(
        self,
        status_code: int,
        code: str,
        message: str,
        hint: str | None = None,
        details: dict | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.message = message
        self.hint = hint
        self.details = details


def error_body(code: str, message: str, hint: str | None = None, details: dict | None = None) -> dict:
    body: dict = {"code": code, "message": message, "request_id": request_id_var.get()}
    if hint:
        body["hint"] = hint
    if details:
        body["details"] = details
    return {"error": body}


def _json(status: int, code: str, message: str, hint: str | None = None, details: dict | None = None):
    return JSONResponse(status_code=status, content=error_body(code, message, hint, details))


def register_error_handlers(app: FastAPI) -> None:
    @app.exception_handler(AppError)
    async def _app_error(_: Request, exc: AppError):
        return _json(exc.status_code, exc.code, exc.message, exc.hint, exc.details)

    @app.exception_handler(RequestValidationError)
    async def _validation(_: Request, exc: RequestValidationError):
        fields = [
            {"field": ".".join(str(p) for p in e["loc"] if p != "body"), "problem": e["msg"]}
            for e in exc.errors()
        ]
        return _json(
            422,
            "validation_error",
            "The request was not valid.",
            "Fix the listed fields and try again.",
            {"fields": fields},
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(_: Request, exc: StarletteHTTPException):
        code = {404: "not_found", 405: "method_not_allowed"}.get(exc.status_code, "http_error")
        return _json(exc.status_code, code, str(exc.detail))

    @app.exception_handler(OperationalError)
    @app.exception_handler(InterfaceError)
    async def _db_down(_: Request, exc: SQLAlchemyError):
        log.error("database unavailable", extra={"error_type": type(exc).__name__})
        return _json(
            503,
            "database_unavailable",
            "The database is temporarily unavailable.",
            "Retry in a few seconds. If this persists, check DATABASE_URL and that Postgres is running.",
        )

    @app.exception_handler(DBAPIError)
    async def _db_err(_: Request, exc: DBAPIError):
        log.error("database error", extra={"error_type": type(exc).__name__}, exc_info=exc)
        return _json(500, "database_error", "A database error occurred.", "Check the server logs.")

    @app.exception_handler(Exception)
    async def _unhandled(_: Request, exc: Exception):
        log.error("unhandled exception", exc_info=exc)
        return _json(500, "internal_error", "Something went wrong on our side.", "Check the server logs.")
