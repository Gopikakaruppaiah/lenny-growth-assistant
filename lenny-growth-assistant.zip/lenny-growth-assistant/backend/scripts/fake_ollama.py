"""NOT Ollama. A tiny stand-in that speaks just enough of Ollama's HTTP API (/api/tags, /api/chat).

For smoke-testing the wiring (HTTP -> FastAPI -> retrieval -> PostgreSQL) in environments where Ollama
and a model cannot be installed, e.g. CI. It does no reasoning: it echoes the first excerpts as a
"grounded" reply. Answer quality can only be judged with a real model.

    python -m scripts.fake_ollama --port 11434
"""

from __future__ import annotations

import argparse
import json
import re
from http.server import BaseHTTPRequestHandler, HTTPServer

MODEL = "llama3.2:3b"


class H(BaseHTTPRequestHandler):
    def _send(self, code: int, body: dict) -> None:
        data = json.dumps(body).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self) -> None:  # noqa: N802
        self._send(200, {"models": [{"name": MODEL}]}) if self.path == "/api/tags" else self._send(404, {})

    def do_POST(self) -> None:  # noqa: N802
        body = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        user = body["messages"][-1]["content"]
        nums = re.findall(r'<excerpt n="(\d+)" guest="([^"]+)"', user)
        if not nums:
            return self._send(200, {"message": {"content": "[[VERDICT: UNSUPPORTED]]\nNo excerpts."}})
        (n1, g1), (n2, g2) = nums[0], nums[min(1, len(nums) - 1)]
        text = f"[[VERDICT: SUPPORTED]]\n(stand-in reply) {g1} discusses this in the first excerpt [{n1}], and {g2} touches on it too [{n2}]."
        self._send(200, {"message": {"role": "assistant", "content": text}, "prompt_eval_count": 1, "eval_count": 1})

    def log_message(self, *a) -> None:
        pass


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", type=int, default=11434)
    HTTPServer(("127.0.0.1", ap.parse_args().port), H).serve_forever()
