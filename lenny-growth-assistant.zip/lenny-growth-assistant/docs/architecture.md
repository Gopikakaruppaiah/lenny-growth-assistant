# Architecture

## 1. Topology

```
 Browser ──HTTPS──▶ Vercel (static React/Vite bundle)
    │
    │ fetch (CORS: exact origin, header X-Client-Id)
    ▼
 FastAPI backend  (Render / any persistent Python host; ONE instance)
    ├── PostgreSQL (Supabase or any Postgres 14+): sessions, messages, artifacts, transcript index
    ├── Provider "anthropic": Claude Agent SDK  ──▶ api.anthropic.com   (cloud, optional)
    └── Provider "ollama"   : HTTP /api/chat    ──▶ OLLAMA_BASE_URL     (local, required for the local demo)
```

* **The deployed (Vercel) site cannot reach your laptop's Ollama.** `localhost` on Render is Render. The
  local demo therefore runs frontend + backend + Postgres + Ollama on your machine (Docker Compose or
  native); the public demo uses `LLM_PROVIDER=anthropic`. Both are the same code, switched by environment.
* The backend is a **persistent process** (not serverless) because generation runs as in-process
  background jobs and essays can take minutes. This is why FastAPI is not deployed to Vercel Functions.

## 2. Components

| Component | Path | Responsibility |
|---|---|---|
| App factory, middleware | `backend/app/main.py` | CORS (exact origins), request-id, structured request log, security headers, lifespan wiring |
| Config | `app/config.py` | Every tunable from env; rejects wildcard CORS; normalises `postgres://` URLs |
| Errors | `app/errors.py` | One JSON error envelope for validation, HTTP, DB-down, and unhandled errors |
| Persistence | `app/models.py`, `alembic/` | SQLAlchemy 2 async + psycopg3; schema owned by Alembic (`alembic check` reports no drift) |
| Ingestion | `app/ingest.py` | Clone/refresh repo → parse → chunk → upsert; hash-based incremental updates; run log table |
| Parsing / chunking | `app/rag/parsing.py`, `chunking.py` | 3 transcript layouts; speaker-turn-aware ~300-word chunks with timestamps |
| Retrieval | `app/rag/query.py`, `retrieval.py` | tsquery builder (phrases, follow-up condensing, injection-safe), ranked FTS, per-episode diversity |
| Grounding | `app/rag/citations.py` | Verdict protocol + citation validation against the retrieved set |
| Providers | `app/llm/*` | `LLMProvider` interface; `OllamaProvider`; `ClaudeAgentProvider`; `ProviderRegistry` (fallback) |
| Skills | `app/skills/*` | `ship30` (essay), `artifact`, `sanitize`, `router`, `prompts`, `ship30_skill.md` |
| Orchestrator | `app/services/chat.py`, `jobs.py` | Message pairs, background jobs, history, provider routing, error mapping |
| API | `app/api/*` | Thin routers; typed with Pydantic (`app/schemas.py`) |
| Frontend | `frontend/src` | React + TS; `lib/api.ts` is the only network code; `useAssistant` owns state & polling |

## 3. Database schema (migration `0001`)

| Table | Key columns |
|---|---|
| `users` | `id uuid`, `client_id` (unique, browser-generated), `metadata jsonb` (user agent, locale), `created_at`, `last_seen_at` |
| `chat_sessions` | `id`, `user_id → users`, `title`, `created_at`, `updated_at` (idx `user_id, updated_at`) |
| `messages` | `id`, `session_id → chat_sessions (cascade)`, `role`, `kind` (chat/essay/artifact), `status` (pending/complete/error), `content`, `provider`, `model`, `fallback_from`, `sources jsonb`, `meta jsonb`, `error_code/message/hint`, `latency_ms`, `created_at`, `completed_at`; CHECK constraints on role/kind/status |
| `artifacts` | `id`, `session_id`, `message_id`, `kind` (markdown/html), `title`, `content` (sanitised), `sanitizer_report jsonb` |
| `transcript_documents` | `slug` (unique), `guest`, `title`, `youtube_url`, `publish_date`, `keywords`, `source_repo`, `source_commit`, `source_path`, `content_hash` |
| `transcript_chunks` | `document_id`, `chunk_index`, `start_seconds`, `end_seconds`, `speakers`, `text`, `tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', text)) STORED` + GIN index |
| `ingestion_runs` | per-run counts, commit SHA, status, warning/error |

Measured on the real corpus: 303 documents, 19,038 chunks, **66 MB** total (58 MB chunks incl. 9.8 MB GIN index) —
inside Supabase's free 500 MB tier.

## 4. API contract (`/api/v1`)

All session/artifact routes require header `X-Client-Id` (16–64 chars `[A-Za-z0-9_-]`).
Errors always look like `{"error": {"code", "message", "hint"?, "details"?, "request_id"}}`.

| Method & path | Purpose | Success |
|---|---|---|
| `GET /health` | Liveness; touches no dependency | 200 |
| `GET /health/ready` | DB + index + provider status | 200, or 503 if DB down |
| `GET /providers` | Default/fallback provider and readiness (never returns keys) | 200 |
| `GET /sources/stats` | Episodes, chunks, last ingest, source commit | 200 |
| `GET /sources/search?q=` | What retrieval returns for a query (no model call) | 200 |
| `POST /sessions` · `GET /sessions` | Create / list own sessions | 201 / 200 |
| `GET·PATCH·DELETE /sessions/{id}` | Read / rename / delete (cancels running jobs) | 200 / 204 |
| `GET /sessions/{id}/messages` | Full history | 200 |
| `POST /sessions/{id}/messages` | Ask (`mode: auto` routes essay/artifact intents) | **202** + pending message |
| `POST /sessions/{id}/essay` | Ship 30 essay on `topic` or last question | 202 |
| `POST /sessions/{id}/artifacts` | `{kind: markdown|html, instruction}` | 202 |
| `GET /sessions/{id}/messages/{mid}` | Poll until `status != pending` | 200 |
| `POST /sessions/{id}/messages/{mid}/retry` | Re-run a failed message | 202 |
| `GET /sessions/{id}/artifacts`, `GET /artifacts/{id}` | List / fetch (owner only) | 200 |

Status codes: 400 missing client id · 404 not found *or not yours* · 409 `generation_in_progress` ·
422 validation · 429 `rate_limited` · 503 `database_unavailable`.

### Why 202 + polling
A local model can take minutes for an essay (6 sequential calls). A single blocking request would hit proxy/load-balancer
timeouts. The POST persists a user message and a `pending` assistant message, starts an asyncio task, and returns at once;
the UI polls every ~1.2 s. Single-flight per session (409) prevents interleaved context. Jobs that die with the
process are marked `interrupted` on startup (and lazily on read) so nothing stays "pending" forever, and the UI offers Retry.
**Limitation:** in-process jobs mean one backend instance. Scaling out needs a queue (Redis/RQ, Procrastinate, etc.).

## 5. Ingestion & retrieval

**Source.** `github.com/ChatPRD/lennys-podcast-transcripts` (verified reachable; 303 `episodes/<slug>/transcript.md` at commit
`be8ab89`). Its README says the content is provided "for personal and educational use" and there is **no LICENSE file**, so
transcripts are never committed here: `python -m app.ingest` clones them at runtime into a git-ignored directory and indexes
them into *your* database. UI footer and README repeat the attribution. Findings: the README claims 269 episodes but the
directory holds 303; three turn layouts exist (301/1/1 files); a few episodes lack `youtube_url`/`publish_date`; and
`ryan-hoover/` has guest "Ryan Hoover" while its title names Ryan Singer — we index exactly what the source says.

**Refresh.** `python -m app.ingest --refresh` (git fetch/reset, then re-index only files whose SHA-256 changed; removed
episodes are pruned). Re-running with no upstream change processed 303 documents, changed 0, skipped 303.
User-supplied transcripts: `python -m app.ingest --path DIR` (same `episodes/<slug>/transcript.md` layout).

**Chunking.** Speaker-turn-aware greedy packing to ~300 words (≈256 median, 46–395 range), one trailing turn as overlap,
oversized turns split by sentence, each chunk keeps its first timestamp → YouTube deep link `…&t=<s>s`.

**Retrieval.** PostgreSQL full-text (`ts_rank_cd`, normalisation 32) over an OR-query of significant terms plus phrase
operators (`(product <-> market <-> fit)`); max 2 chunks/episode for diversity; typical latency 13–360 ms. Queries are built
from alphanumeric parts only (tested against tsquery-syntax injection). Follow-ups ("what about enterprise?") borrow terms
from the previous user turn only when anaphoric or a single bare term.

**Honest limits of lexical retrieval.** `scripts/eval_retrieval.py` (16 on-topic, 8 off-topic queries) shows the top relevance
scores **overlap** (lowest on-topic 0.44, highest off-topic 0.55), so a score threshold cannot reliably reject off-topic
questions. Therefore abstention is layered: (1) deterministic: no searchable terms / no matches ⇒ **no model call**;
(2) the model must emit `[[VERDICT: SUPPORTED|PARTIAL|UNSUPPORTED]]` and is told to answer only from excerpts;
(3) the server validates every `[n]` against the retrieved set, strips invalid ones, and flags answers with no valid citation
as ungrounded. Layer 2 depends on model quality — small local models may abstain less reliably than Claude. The documented
next step is embedding re-ranking (pgvector) — deliberately not built because it needs an embedding model available both locally
and in the cloud.

## 6. Agent layer and provider routing

```
 request ─▶ router (rules) ─▶ chat | essay | artifact
                │
                ▼
        retrieve ─▶ SourceRegistry (shared numbering)
                │
                ▼
        LLMRunner ─▶ ProviderRegistry.generate(preferred)
                         ├─ OllamaProvider      (pipeline: retrieve → ground → generate)
                         └─ ClaudeAgentProvider (Claude Agent SDK; agent may call search_transcripts)
                         on ProviderError and LLM_FALLBACK_PROVIDER set ⇒ run fallback, record fallback_from
```

* **Claude Agent SDK integration (real, not mocked in product code).** `claude-agent-sdk` runs the agent loop in its bundled
  runtime. We set `tools=[]` (all built-ins off: no shell/files/web), expose a single in-process MCP tool
  `search_transcripts` (`allowed_tools=["mcp__lenny__search_transcripts"]`) that queries our PostgreSQL index and feeds the *same*
  numbering registry, `setting_sources=[]` (ignore any `.claude` config), `permission_mode="dontAsk"`, a throwaway `cwd`,
  `max_budget_usd` and `max_turns` caps, and the key only via `env`. History is rendered into the prompt from PostgreSQL —
  no SDK-side sessions — so chats cannot leak into each other.
* **Why Ollama does not use the Agent SDK.** The SDK drives Anthropic models. Ollama is called directly through the same
  grounding pipeline, without tool use (small local models call tools unreliably). The UI badge states which path produced
  each answer; `meta.tool_calls` records agentic tool use.
* **Selection.** `LLM_PROVIDER` (default `ollama`) chooses the default; the UI can override per request (`provider`), stored in
  `localStorage`. **Missing cloud key never blocks Ollama** (`provider_not_configured` is raised only if Anthropic is selected).
* **Timeouts & fallback.** `LLM_TIMEOUT_SECONDS` per model call (and `asyncio.timeout` around the Agent SDK), plus a whole-job
  timeout. With `LLM_FALLBACK_PROVIDER` set, a primary timeout/unavailable/auth/rate-limit error triggers one visible fallback;
  after a fallback the job stays on the fallback to avoid repeated timeouts. The message row stores the provider that
  *actually* answered, `fallback_from`, and every `(provider, model)` used. If the fallback also fails, the **primary** error is reported.
* **Ollama errors** are mapped to actionable hints: unreachable ⇒ `ollama serve` / `OLLAMA_BASE_URL=http://host.docker.internal:11434`;
  model missing ⇒ `ollama pull <model>`; timeout ⇒ smaller model / `LLM_TIMEOUT_SECONDS`.

## 7. Ship 30 for 30 skill

`app/skills/ship30_skill.md` is the explicit, versioned skill (principles P1–P10 paraphrased from the Ship 30 guide, adapted
from 250-word atomic essays to ~1,250 words using the guide's long-form advice). It is injected into every essay prompt.
Pipeline: **plan** (headline, angle, approach) → **intro** (~170) → **3 sections** (~300 each) → **takeaway** (~180) → **measure**
(1,125–1,375 words else up to 2 correction passes) → **verify** (citations validated, renumbered 1..k in order of appearance,
auto-generated *Sources* list) → **checks** (length, title, ≥4 headings, ≥3 bullets, 3–15 bold spans, ≥5 citations, ≥3 episodes,
takeaway). Checks are returned to the UI; failures are shown, never hidden. Fewer than 3 excerpts from 2 episodes ⇒ the
skill refuses rather than padding with outside knowledge.

## 8. Security model

| Threat | Control |
|---|---|
| Malicious/hallucinated HTML artifact | **Layer 1** server sanitiser (`nh3` allow-list; all CSS `url()` dropped; `@import`, expressions, event handlers, scripts, forms, frames, svg/math, base/meta/link removed; ≤200 KB) → **Layer 2** `<iframe sandbox="">` (no scripts, opaque origin, no forms/popups/navigation) → **Layer 3** CSP meta in the document (`default-src 'none'; img-src data:; style-src 'unsafe-inline'`). 22 attack payloads are unit-tested. |
| XSS via markdown | `react-markdown` without raw-HTML support; unsafe URL schemes dropped; server-side scrub too |
| Prompt injection from transcript text | Excerpts are labelled untrusted data; the Claude agent has no built-in tools, only a read-only search tool; citations are validated server-side |
| Secrets | API key and DB URL exist only in backend env; frontend has one public variable (`VITE_API_BASE_URL`); built bundle scanned for secrets (none); logs redact `sk-…`, `password=`, and URL passwords |
| Cross-user access | Every query is scoped by `user_id`; other users' resources return 404 |
| CORS | Exact origin allow-list; wildcard rejected at startup; no credentials |
| Cost abuse | Per-client rate limit, per-request `max_budget_usd`, single-flight per session |
| SQL injection | ORM / bound parameters only; tsquery built from `[a-z0-9]` parts |
| Information leak | Error envelope never includes stack traces or connection strings |

**Anonymous identity is not authentication.** `X-Client-Id` is a random browser-held UUID: it separates users' chats but anyone
who obtains your id can act as you. Real auth (Supabase Auth, OIDC) is the documented next step. A public deployment with a cloud
key spends your money: keep the rate limit low and watch provider usage.

## 9. Observability
Structured JSON logs (`ts, level, logger, event, request_id, …`) with an `X-Request-Id` echoed to the client and included in
every error body; job lifecycle events (`job started/complete/failed`) record provider, fallback and latency.
Health: `/health` (liveness) and `/health/ready` (dependencies).
