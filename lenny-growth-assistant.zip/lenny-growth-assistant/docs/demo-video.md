# Demo video plan (2–3 minutes)

> **Status: NOT recorded.** This is a plan and script only. Do not claim a video exists until you have recorded and uploaded one
> and pasted the real link into the README.

**Setup before recording:** `docker compose up` (or native), transcripts ingested, Ollama running `llama3.2:3b` (or your model),
one warm-up question asked so the model is loaded, browser at 1440×900, notifications off, `.env` hidden from screen.
Optional second tab with the deployed Vercel URL.

| Time | On screen | Say (script) |
|---|---|---|
| 0:00–0:15 | Empty state | "This is the Lenny Growth Assistant: product and growth answers grounded in Lenny's Podcast transcripts, with sources you can verify. Local Ollama is running — you can see it in the provider pill." |
| 0:15–0:50 | Ask "How do I know if I have product-market fit?" → answer → click a `[n]` chip → click "Watch at…" | "Each claim carries a citation. Opening it shows the exact passage, the guest, the episode and the timestamp, and jumps to that moment on YouTube. The badge says this came from Ollama, a local model." |
| 0:50–1:10 | Follow-up "what about enterprise?" then new chat, ask something else | "Follow-ups use the conversation; a new chat is fully independent — all of this is persisted in PostgreSQL." |
| 1:10–1:30 | Ask nonsense/off-topic | "If the transcripts don't cover it, it says so instead of guessing." |
| 1:30–2:10 | Click **Write essay** → progress → essay card → open in viewer | "The Ship 30 for 30 skill plans a headline, writes section by section, then measures length — about 1,250 words — and shows a quality checklist, including anything that failed." |
| 2:10–2:40 | **Create artifact → HTML** → show viewer → DevTools showing `sandbox=""` and CSP | "Generated HTML renders in a sandboxed iframe with no scripts, and was sanitised on the server first." |
| 2:40–3:00 | Stop Ollama → ask → error with hint → provider menu showing Claude/fallback | "If Ollama is down you get an actionable error. Cloud providers are configuration, and any fallback is labelled — a cloud answer is never passed off as local." |

**Retake checklist:** audio clear · no secrets visible · real (not canned) responses · under 3:00 · link added to README.
