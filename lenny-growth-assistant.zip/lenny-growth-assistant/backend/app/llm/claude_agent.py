"""Anthropic provider built on the Claude Agent SDK (``claude-agent-sdk``).

The SDK runs the agent loop in a bundled runtime. We use it with:
  * all built-in tools disabled (``tools=[]``) — the agent cannot touch files or the shell;
  * one in-process MCP tool, ``search_transcripts``, backed by our PostgreSQL index;
  * filesystem settings disabled (``setting_sources=[]``) and a throwaway cwd;
  * a per-request spend cap (``max_budget_usd``) and turn cap (``max_turns``).

Conversation history is rendered into the prompt from PostgreSQL (the source of truth) rather
than using SDK-side sessions, so two chat sessions can never leak into each other.
"""

from __future__ import annotations

import asyncio
import tempfile
from collections.abc import AsyncIterator, Callable
from typing import Any

import claude_agent_sdk as sdk

from ..config import Settings
from ..logging_setup import get_logger
from .base import (
    GenerationRequest,
    GenerationResult,
    LLMProvider,
    ProviderAuthError,
    ProviderBadResponse,
    ProviderNotConfigured,
    ProviderRateLimited,
    ProviderStatus,
    ProviderTimeout,
    ProviderUnavailable,
)

log = get_logger("llm.claude_agent")

TOOL_SERVER = "lenny"
TOOL_NAME = "search_transcripts"
TOOL_FQN = f"mcp__{TOOL_SERVER}__{TOOL_NAME}"

QueryFn = Callable[..., AsyncIterator[Any]]


def render_prompt(req: GenerationRequest) -> str:
    """Render prior turns + the latest user message as one prompt string."""
    *history, last = req.turns
    parts: list[str] = []
    if history:
        convo = "\n".join(f"{t.role.upper()}: {t.content}" for t in history)
        parts.append(f"<conversation_so_far>\n{convo}\n</conversation_so_far>")
    parts.append(last.content)
    return "\n\n".join(parts)


class ClaudeAgentProvider(LLMProvider):
    name = "anthropic"

    def __init__(self, settings: Settings, query_fn: QueryFn | None = None) -> None:
        self.settings = settings
        self.model = settings.anthropic_model
        self._query: QueryFn = query_fn or sdk.query  # injectable for deterministic tests

    def _build_options(self, req: GenerationRequest, cwd: str) -> sdk.ClaudeAgentOptions:
        mcp_servers: dict[str, Any] = {}
        allowed: list[str] = []
        if req.search_tool is not None:
            search_fn = req.search_tool

            @sdk.tool(
                TOOL_NAME,
                "Search Lenny's Podcast transcripts for passages relevant to a query. "
                "Returns numbered excerpts you must cite as [n]. Use short keyword queries.",
                {"query": str},
            )
            async def search_transcripts(args: dict[str, Any]) -> dict[str, Any]:
                text = await search_fn(str(args.get("query", "")))
                return {"content": [{"type": "text", "text": text}]}

            mcp_servers[TOOL_SERVER] = sdk.create_sdk_mcp_server(TOOL_SERVER, tools=[search_transcripts])
            allowed.append(TOOL_FQN)

        key = self.settings.anthropic_api_key.get_secret_value() if self.settings.anthropic_api_key else ""
        return sdk.ClaudeAgentOptions(
            system_prompt=req.system,
            model=self.model,
            tools=[],  # disable every built-in tool (Bash, Read, Write, WebFetch, ...)
            allowed_tools=allowed,
            mcp_servers=mcp_servers,
            max_turns=self.settings.anthropic_max_turns if allowed else 1,
            max_budget_usd=self.settings.anthropic_max_budget_usd,
            setting_sources=[],  # isolation mode: ignore any user/project .claude settings
            permission_mode="dontAsk",  # headless: never prompt; only pre-approved tools run
            cwd=cwd,
            env={"ANTHROPIC_API_KEY": key},
        )

    async def generate(self, req: GenerationRequest) -> GenerationResult:
        if not self.settings.anthropic_configured:
            raise ProviderNotConfigured(
                "ANTHROPIC_API_KEY is not set, so the Claude provider cannot run.",
                hint="Set ANTHROPIC_API_KEY on the backend (never in the frontend), or switch LLM_PROVIDER=ollama.",
                provider=self.name,
            )
        text_blocks: list[str] = []
        result: sdk.ResultMessage | None = None
        tool_calls = 0
        model_used = self.model
        try:
            with tempfile.TemporaryDirectory(prefix="lga-agent-") as cwd:
                options = self._build_options(req, cwd)
                async with asyncio.timeout(req.timeout_s):
                    async for msg in self._query(prompt=render_prompt(req), options=options):
                        if isinstance(msg, sdk.AssistantMessage):
                            if msg.error:
                                raise self._map_assistant_error(msg.error)
                            model_used = msg.model or model_used
                            turn_text: list[str] = []
                            for block in msg.content:
                                if isinstance(block, sdk.TextBlock):
                                    turn_text.append(block.text)
                                elif isinstance(block, sdk.ToolUseBlock):
                                    tool_calls += 1
                            if turn_text:
                                text_blocks = turn_text  # keep only the most recent assistant turn
                        elif isinstance(msg, sdk.ResultMessage):
                            result = msg
        except TimeoutError as exc:
            raise ProviderTimeout(
                f"Claude did not finish within {int(req.timeout_s)}s.",
                hint="Retry, or raise LLM_TIMEOUT_SECONDS. Configure LLM_FALLBACK_PROVIDER=ollama for automatic fallback.",
                provider=self.name,
            ) from exc
        except sdk.CLINotFoundError as exc:
            raise ProviderUnavailable(
                "The Claude Agent SDK runtime was not found.",
                hint="Reinstall dependencies (`pip install claude-agent-sdk`) — the wheel bundles the runtime.",
                provider=self.name,
            ) from exc
        except sdk.ClaudeSDKError as exc:
            log.error("agent sdk error", extra={"error_type": type(exc).__name__}, exc_info=exc)
            raise ProviderUnavailable(
                "The Claude agent runtime failed to complete the request.",
                hint="Check network access to api.anthropic.com and the server logs.",
                provider=self.name,
            ) from exc

        if result is not None and result.is_error:
            raise self._map_result_error(result)
        text = (result.result if result and result.result else "\n".join(text_blocks)).strip()
        if not text:
            raise ProviderBadResponse("Claude returned an empty response.", provider=self.name)
        usage = dict(result.usage or {}) if result else {}
        if result and result.total_cost_usd is not None:
            usage["cost_usd"] = result.total_cost_usd
        return GenerationResult(text=text, provider=self.name, model=model_used, usage=usage, tool_calls=tool_calls)

    def _map_assistant_error(self, code: str):
        if code == "authentication_failed":
            return ProviderAuthError(
                "Anthropic rejected the API key.", hint="Check ANTHROPIC_API_KEY on the backend.", provider=self.name
            )
        if code == "rate_limit":
            return ProviderRateLimited("Anthropic rate limit reached.", hint="Wait a moment and retry.", provider=self.name)
        if code == "billing_error":
            return ProviderAuthError(
                "Anthropic reported a billing problem.", hint="Check credits on your Anthropic account.", provider=self.name
            )
        return ProviderBadResponse(f"Claude returned an error ({code}).", provider=self.name)

    def _map_result_error(self, r: sdk.ResultMessage):
        if r.api_error_status == 429:
            return self._map_assistant_error("rate_limit")
        if r.api_error_status in (401, 403):
            return self._map_assistant_error("authentication_failed")
        if r.subtype == "error_max_budget_usd":
            return ProviderBadResponse(
                "The per-request spend cap was reached.", hint="Raise ANTHROPIC_MAX_BUDGET_USD.", provider=self.name
            )
        if r.subtype == "error_max_turns":
            return ProviderBadResponse("The agent ran out of tool-use turns.", hint="Raise ANTHROPIC_MAX_TURNS.", provider=self.name)
        return ProviderBadResponse(f"Claude run failed ({r.subtype}).", provider=self.name)

    async def status(self) -> ProviderStatus:
        # We deliberately do not spend tokens to "ping" the API; we can only confirm configuration.
        def mk(ready: bool, detail: str, hint: str | None = None) -> ProviderStatus:
            return ProviderStatus(name=self.name, model=self.model, ready=ready, detail=detail, hint=hint, kind="cloud", agentic=True)

        if not self.settings.anthropic_configured:
            return mk(False, "ANTHROPIC_API_KEY is not set", "Add ANTHROPIC_API_KEY to the backend environment to enable Claude.")
        return mk(True, "API key configured (validity is checked on first request)")
