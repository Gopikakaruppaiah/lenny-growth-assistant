"""Calibrate the retrieval sufficiency gate against labeled queries (needs an ingested DB).

    python -m scripts.eval_retrieval

Prints, per query, the top ts_rank_cd score and how many distinct episodes clear it, so the
RETRIEVAL_MIN_SCORE default can be justified with data instead of guessed. Re-run after
changing chunking, the stopword list, or the corpus.
"""

from __future__ import annotations

import asyncio
import statistics
import sys

from app.config import get_settings
from app.db import make_engine, make_session_factory
from app.rag.retrieval import retrieve

ON_TOPIC = [
    "How do I know if I have product-market fit?",
    "How should I think about pricing for a B2B SaaS product?",
    "What do great PMs do to improve onboarding and activation?",
    "How do top teams run growth experiments?",
    "What makes a good product roadmap?",
    "How do I hire a great head of product?",
    "What is product-led growth and when does it work?",
    "How do you improve retention for a consumer app?",
    "How should founders think about prioritization?",
    "What is the best way to run user research?",
    "How do marketplaces solve the cold start problem?",
    "How should a PM work with engineers and designers?",
    "What is a North Star metric?",
    "How do I build a strong product culture?",
    "What do guests say about AI changing product management?",
    "How do I say no to stakeholders?",
]
OFF_TOPIC = [
    "What is the capital of France?",
    "How do I bake sourdough bread?",
    "hi",
    "Who won the 2018 FIFA World Cup?",
    "What is the boiling point of water at altitude?",
    "Write a python function to reverse a linked list",
    "What is the best way to train for a marathon?",
    "How do vaccines work?",
]


async def main() -> int:
    eng = make_engine(get_settings())
    sf = make_session_factory(eng)
    rows: dict[str, list[tuple[str, float, int]]] = {"on": [], "off": []}
    async with sf() as s:
        for label, qs in (("on", ON_TOPIC), ("off", OFF_TOPIC)):
            for q in qs:
                r = await retrieve(s, q, None, top_k=8, max_per_episode=2, min_coverage=0.0)
                top = r.sources[0].score if r.sources else 0.0
                rows[label].append((q, top, len({x.slug for x in r.sources if x.score >= 0})))
    await eng.dispose()
    for label in ("on", "off"):
        print(f"\n== {label.upper()}-TOPIC ==")
        for q, top, _ in rows[label]:
            print(f"  top={top:.3f}  {q}")
        tops = [t for _, t, _ in rows[label]]
        print(f"  min={min(tops):.3f} median={statistics.median(tops):.3f} max={max(tops):.3f}")
    on_min = min(t for _, t, _ in rows["on"])
    off_max = max(t for _, t, _ in rows["off"])
    print(f"\nlowest on-topic top-score = {on_min:.3f}; highest off-topic top-score = {off_max:.3f}")
    print("separable" if on_min > off_max else "OVERLAP: lexical score alone cannot separate these sets")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
