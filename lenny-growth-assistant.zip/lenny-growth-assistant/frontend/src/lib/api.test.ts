import { describe, expect, it } from "vitest";
import { ApiError, api, getClientId } from "./api";
import { SID, mockApi, providers } from "../test/fixtures";

describe("api client", () => {
  it("sends the persistent anonymous client id on every request", async () => {
    const { calls } = mockApi({ "GET /providers": () => providers });
    await api.providers();
    const id = (calls[0].init.headers as Record<string, string>)["X-Client-Id"];
    expect(id).toBe(getClientId());
    expect(getClientId()).toBe(id); // stable across calls
    expect(id).toMatch(/^[A-Za-z0-9_-]{16,64}$/);
  });

  it("calls the configured base URL under /api/v1", async () => {
    const { fn } = mockApi({ "GET /providers": () => providers });
    await api.providers();
    expect(String(fn.mock.calls[0][0])).toBe("http://localhost:8000/api/v1/providers");
  });

  it("parses the backend error envelope", async () => {
    mockApi({ [`GET /sessions/${SID}/messages`]: () => ({ __status: 404, body: { error: { code: "session_not_found", message: "Chat session not found.", hint: "h", request_id: "r1" } } }) });
    await expect(api.listMessages(SID)).rejects.toMatchObject({ code: "session_not_found", status: 404, hint: "h", requestId: "r1" });
  });

  it("turns a network failure into an actionable ApiError", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => { throw new TypeError("Failed to fetch"); }));
    const err = await api.listSessions().catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(err.code).toBe("network_error");
    expect(err.message).toContain("http://localhost:8000");
    expect(err.hint).toMatch(/CORS_ALLOWED_ORIGINS/);
  });

  it("handles non-JSON error bodies and 204", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response("<html>bad gateway</html>", { status: 502 })));
    await expect(api.listSessions()).rejects.toMatchObject({ code: "http_error", status: 502 });
    mockApi({ [`DELETE /sessions/${SID}`]: () => ({ __status: 204 }) });
    await expect(api.deleteSession(SID)).resolves.toBeUndefined();
  });
});
