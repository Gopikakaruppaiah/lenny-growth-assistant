# Skill: Ship 30 for 30 essay (long-form, transcript-grounded)

version: 1.0
source: "How To Start Writing Online: The Ship 30 for 30 Ultimate Guide" (Nicolas Cole & Dickie Bush) —
https://www.ship30for30.com/post/how-to-start-writing-online-the-ship-30-for-30-ultimate-guide
The principles below are paraphrased from that guide, then adapted: the guide's native "atomic essay"
is ~250 words, while this product targets **~1,250 words**, so the guide's own long-form advice
(wheels & spokes headings, a skeleton, consistent structure) is applied.

## What this skill is for
Turn a grounded answer about product/growth into a skimmable essay a busy PM would actually finish.
Every factual claim must come from the numbered transcript excerpts. Never add outside facts.

## Principles (each one is checked or enforced in code or in the prompts)

### P1 Headline answers three questions — WHO it is for, WHAT it is about, WHY read it (the promise)
- Name the audience and the outcome. Prefer clear over clever. A number or a container ("5 lessons")
  helps readers see what they are getting.
- Create a curiosity gap: state the beginning and the payoff, not the whole middle.
- Keep the promise. If the body cannot deliver the headline, change the headline (that is what separates
  a good hook from clickbait).

### P2 Credibility is stated, not implied
- This essay is *curating experts*: say early that the ideas come from named guests on Lenny's Podcast.
- Attribute each idea to a guest by name; paraphrase; quote at most a short phrase.

### P3 Choose one of four paths and stay on it
- actionable (how to), analytical (what the evidence/numbers say), aspirational (it can be done),
  anthropological (why people behave this way). Pick the one that fits the excerpts.

### P4 One proven approach, used consistently
- Organise every main section the same way: all Lessons, or all Steps, or all Mistakes, or all Principles.
  Do not mix. Fill each section with a short story, example, or advice taken from the excerpts.

### P5 Skeleton first
- Headline → introduction (restates promise in more detail) → main points → conclusion with the takeaway.

### P6 Skimmability = readability
- Use a title plus section headings ("wheels & spokes"): one `#` title, `##` for each main point.
- Turn any paragraph that is really a list into bullets. Use **bold** sparingly, only for the sentence
  a skimmer must not miss (aim for one per section).
- Alternate rhythm: a one-sentence opener, a few sentences of substance, a one-sentence closer (1/3/1).
  Avoid walls of text and avoid every sentence being its own paragraph.

### P7 Rate of revelation
- Every sentence should move the idea forward. If it repeats what was said, cut it.

### P8 Tell a short story alongside the advice (the golden intersection)
- Pair the practical point with a concrete moment from the excerpts (who, what happened, what changed).
  Only use stories that appear in the excerpts.

### P9 Say what has not been said (the tequila test)
- Skip the generic advice everyone gives. Prefer the specific, surprising, or contrarian point from the excerpts.

### P10 End with a specific, useful takeaway
- Close with one action the reader can do this week, plus a 3-bullet recap (a TL;DR).

## Hard constraints (checked after generation)
- Length: 1,250 words ± 10% (1,125–1,375), excluding the auto-generated Sources list.
- Structure: one `#` title; at least 4 `##` sections (hook/intro is untitled body under the title).
- At least 3 bullet items; between 3 and 15 bold spans.
- At least 5 valid citations `[n]` from at least 3 different excerpts when the excerpts allow it.
- No citation number that does not exist. No claim without an excerpt behind it.
- If the excerpts are insufficient, say so and stop — do not pad with general knowledge.

## Section plan (word budget sums to ~1,250)
| Part            | Words | Rhythm / job                                                        |
|-----------------|-------|---------------------------------------------------------------------|
| Intro (hook)    | ~170  | story or surprising fact → promise → who it's for → credibility     |
| Main point 1    | ~300  | heading in the shared pattern; story + advice; one bold line        |
| Main point 2    | ~300  | same pattern                                                        |
| Main point 3    | ~300  | same pattern                                                        |
| Takeaway        | ~180  | the one action; 3-bullet TL;DR                                      |
