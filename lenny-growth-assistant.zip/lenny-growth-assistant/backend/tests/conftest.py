from __future__ import annotations

import os
import shutil
import tempfile
import uuid
from pathlib import Path

import httpx
import pytest
import pytest_asyncio

pgserver = pytest.importorskip("pgserver", reason="pgserver provides the real PostgreSQL used by integration tests")

_TMP = Path(tempfile.mkdtemp(prefix="lga-pg-"))
_SERVER = pgserver.get_server(_TMP / "pgdata", cleanup_mode="stop")
_SERVER.psql("CREATE DATABASE lga_test;")
TEST_DB_URL = f"postgresql+psycopg://postgres:@/lga_test?host={_TMP / 'pgdata'}"
os.environ["DATABASE_URL"] = TEST_DB_URL  # must be set before app.config is first used
os.environ["LOG_LEVEL"] = "WARNING"

from alembic.config import Config  # noqa: E402
from pydantic import SecretStr  # noqa: E402
from sqlalchemy import create_engine, text  # noqa: E402

from alembic import command  # noqa: E402
from app.config import Settings, get_settings  # noqa: E402
from app.ingest import ingest_directory  # noqa: E402
from app.llm.claude_agent import ClaudeAgentProvider  # noqa: E402
from app.llm.ollama import OllamaProvider  # noqa: E402
from app.llm.registry import ProviderRegistry  # noqa: E402
from app.main import create_app  # noqa: E402

from .fakes import FakeOllama  # noqa: E402

BACKEND = Path(__file__).resolve().parents[1]
FIXTURES = Path(__file__).parent / "fixtures"


def pytest_sessionfinish(session, exitstatus):
    shutil.rmtree(_TMP, ignore_errors=True)


@pytest.fixture(scope="session", autouse=True)
def migrated_db():
    get_settings.cache_clear()
    cfg = Config(str(BACKEND / "alembic.ini"))
    cfg.set_main_option("script_location", str(BACKEND / "alembic"))
    command.upgrade(cfg, "head")
    engine = create_engine(TEST_DB_URL, connect_args={"prepare_threshold": None})
    ingest_directory(engine, FIXTURES, repo_label="test://synthetic", commit="deadbeef", target_words=120, overlap_words=20)
    yield engine
    engine.dispose()


@pytest.fixture(autouse=True)
def clean_user_data(migrated_db):
    with migrated_db.begin() as c:
        c.execute(text("TRUNCATE users CASCADE"))
    yield


def make_settings(**kw) -> Settings:
    base = dict(database_url=TEST_DB_URL, log_level="WARNING", llm_provider="ollama", rate_limit_per_minute=0,
                llm_timeout_seconds=5, essay_total_timeout_seconds=30, cors_allowed_origins="http://localhost:5173")
    base.update(kw)
    return Settings(**base)


class Harness:
    def __init__(self, app, client, ollama: FakeOllama, claude_query):
        self.app, self.client, self.ollama, self.claude_query = app, client, ollama, claude_query
        self.client_id = uuid.uuid4().hex

    def headers(self, client_id: str | None = None) -> dict:
        return {"X-Client-Id": client_id or self.client_id}

    async def new_session(self, client_id: str | None = None) -> str:
        r = await self.client.post("/api/v1/sessions", json={}, headers=self.headers(client_id))
        assert r.status_code == 201, r.text
        return r.json()["id"]

    async def wait(self, sid: str, mid: str, client_id: str | None = None, tries: int = 100) -> dict:
        import asyncio

        for _ in range(tries):
            r = await self.client.get(f"/api/v1/sessions/{sid}/messages/{mid}", headers=self.headers(client_id))
            assert r.status_code == 200, r.text
            if r.json()["status"] != "pending":
                return r.json()
            await asyncio.sleep(0.05)
        raise AssertionError("message stayed pending")

    async def ask(self, sid: str, content: str, client_id: str | None = None, **extra) -> dict:
        r = await self.client.post(f"/api/v1/sessions/{sid}/messages", json={"content": content, **extra}, headers=self.headers(client_id))
        assert r.status_code == 202, r.text
        return await self.wait(sid, r.json()["assistant_message"]["id"], client_id)


async def build_harness(settings: Settings | None = None, ollama: FakeOllama | None = None, claude_query=None):
    settings = settings or make_settings()
    ollama = ollama or FakeOllama()
    providers = ProviderRegistry(settings, {
        "ollama": OllamaProvider(settings, transport=ollama.transport()),
        "anthropic": ClaudeAgentProvider(settings, query_fn=claude_query),
    })
    app = create_app(settings, providers)
    ctx = app.router.lifespan_context(app)
    await ctx.__aenter__()
    client = httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="http://test")
    h = Harness(app, client, ollama, claude_query)
    h._ctx = ctx  # type: ignore[attr-defined]
    return h


async def close_harness(h: Harness) -> None:
    await h.client.aclose()
    await h._ctx.__aexit__(None, None, None)  # type: ignore[attr-defined]


@pytest_asyncio.fixture
async def h():
    harness = await build_harness()
    yield harness
    await close_harness(harness)


@pytest.fixture
def anthropic_settings():
    return make_settings(anthropic_api_key=SecretStr("sk-ant-test-0000000000000000"))
