from __future__ import annotations

import time

from fastapi import APIRouter, Request

from ..schemas import ProvidersOut, ProviderStatusOut

router = APIRouter(tags=["providers"])
_CACHE: dict[str, tuple[float, list[ProviderStatusOut]]] = {}


async def provider_statuses(request: Request) -> list[ProviderStatusOut]:
    reg = request.app.state.providers
    now = time.monotonic()
    hit = _CACHE.get(id(reg).__str__())
    if hit and now - hit[0] < 5:  # avoid hammering Ollama on every poll
        return hit[1]
    out = [
        ProviderStatusOut(**s.__dict__, is_default=s.name == reg.default_name, is_fallback=s.name == reg.fallback_name)
        for s in await reg.statuses()
    ]
    _CACHE[id(reg).__str__()] = (now, out)
    return out


@router.get("/providers", response_model=ProvidersOut)
async def providers(request: Request) -> ProvidersOut:
    """Which model provider is configured, which is the fallback, and whether each is actually usable.

    Never returns keys. Cloud 'ready' means a key is configured, not that it has been validated.
    """
    reg = request.app.state.providers
    return ProvidersOut(default=reg.default_name, fallback=reg.fallback_name, providers=await provider_statuses(request))
