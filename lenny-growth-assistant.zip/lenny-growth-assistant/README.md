# The Lenny Growth Assistant

Ask product and growth questions and get answers **grounded in Lenny's Podcast transcripts** — with citations that open the
exact passage and jump to the moment on YouTube. Keep independent chat sessions, generate a ~1,250-word **Ship 30 for 30**-style
essay with an explicit writing skill, and create **Markdown or HTML/CSS artifacts** rendered safely beside the chat.

| | |
|---|---|
| Backend | FastAPI · SQLAlchemy 2 (async) · Alembic · PostgreSQL full-text retrieval |
| Agent layer | **Claude Agent SDK** (cloud) with an in-process `search_transcripts` tool · direct **Ollama** (local) |
| Frontend | React 18 + TypeScript + Vite (Vercel-ready) |
| Docs | [PRD](docs/PRD.md) · [design](docs/design.md) · [architecture](docs/architecture.md) · [manual test plan](docs/manual-test-plan.md) · [deployment](docs/deployment.md) · [demo video plan](docs/demo-video.md) · [agent logs](agent-logs/) |

## Honest status (read this first)

| Item | Status |
|---|---|
| Backend: ruff, mypy, **119 pytest tests** (real PostgreSQL via `pgserver`) | ✅ run, all pass |
| Frontend: tsc, **30 vitest tests**, production build, bundle secret scan | ✅ run, all pass |
| Real transcript corpus ingested (303 episodes → 19,038 chunks, 66 MB DB), retrieval + HTTP smoke test | ✅ run |
| Claude Agent SDK options/tool wiring, error mapping | ✅ constructed against the real SDK and unit-tested with a **fake `query` stream** |
| **Real Claude API call** | ❌ **not run** (no API key in the build environment) |
| **Real Ollama model answers** | ❌ **not run** (no Ollama/model download possible). HTTP smoke test used a clearly-labelled stand-in (`scripts/fake_ollama.py`), so answer *quality* and verdict compliance of a real small model are unverified |
| Docker Compose / Dockerfiles | ⚠️ written, YAML parsed, **never built** (no Docker in the environment) |
| Visual/UI check in a real browser, screenshots, a11y audit | ❌ not done (no browser available) |
| Deployment (Vercel, Render, Supabase), live URL | ❌ **not done** — configs + exact steps provided; no URL exists |
| Demo video | ❌ **not recorded** — plan/script only |
| Agent transcripts | ⚠️ `agent-logs/` is a curated, honest log of the build, not a raw export |

## Prerequisites
Python 3.11+ · Node 20+ · PostgreSQL 14+ (or Docker) · git · [Ollama](https://ollama.com/download) · (optional) an Anthropic API key.
Docker Desktop/Engine ≥ 24 with Compose v2 if you use the one-command path.

## Quick start A — Docker Compose
```bash
cp .env.example .env                  # defaults work for local; no cloud key required
ollama pull llama3.2:3b               # on your machine (the containers reach it via host.docker.internal)
docker compose up --build             # db + backend (auto-migrates) + frontend
docker compose --profile tools run --rm ingest     # clone + index the transcripts (~1 min)
open http://localhost:5173
```
Ollama in Docker instead: `docker compose --profile ollama up --build`, set `OLLAMA_BASE_URL=http://ollama:11434` in `.env`,
then `docker compose exec ollama ollama pull llama3.2:3b`. Refresh transcripts later: `docker compose --profile tools run --rm ingest --refresh`.

## Quick start B — native
```bash
# 1. Postgres (skip if you have one)
docker run -d --name lga-db -e POSTGRES_USER=lenny -e POSTGRES_PASSWORD=lenny -e POSTGRES_DB=lenny -p 5432:5432 postgres:16-alpine

# 2. Backend
cd backend && python -m venv .venv && source .venv/bin/activate && pip install -r requirements-dev.txt
cp ../.env.example .env                           # backend/.env — the backend reads ./.env (or real env vars) from its working directory
alembic upgrade head                              # migrations
python -m app.ingest                              # clone + index (≈11 s); see "Transcripts" below
uvicorn app.main:app --reload --port 8000

# 3. Ollama (local model — required for the local demo)
ollama pull llama3.2:3b && ollama serve           # `serve` is unnecessary if the Ollama app is already running

# 4. Frontend (new terminal)
cd frontend && cp .env.example .env && npm install && npm run dev      # http://localhost:5173
```
Check: `curl localhost:8000/api/v1/health/ready` → `"status":"ready"`, provider `ollama` ready.
`make` shortcuts exist (`make setup migrate ingest api web test lint`).

## Choosing the model provider (config only)
| Goal | Set in backend env |
|---|---|
| Local Ollama (default) | `LLM_PROVIDER=ollama`, `OLLAMA_MODEL=llama3.2:3b` |
| Claude via Agent SDK | `LLM_PROVIDER=anthropic`, `ANTHROPIC_API_KEY=…`, optional `ANTHROPIC_MODEL` |
| Cloud primary, local fallback | `LLM_PROVIDER=anthropic`, `LLM_FALLBACK_PROVIDER=ollama` |
| Timeouts | `LLM_TIMEOUT_SECONDS` (per call), `ESSAY_TOTAL_TIMEOUT_SECONDS` |

The header pill shows the active provider/model and readiness; you can also switch per request. A fallback answer is always labelled.
Cloud key is **never** needed for Ollama. The default `ANTHROPIC_MODEL=claude-sonnet-5-5` was **not verified against the live API** — set it to a
model your account can use. Anthropic's SDK only drives Anthropic models, which is why Ollama is called directly (see architecture §6).

## Transcripts: source, terms, refresh
Source: <https://github.com/ChatPRD/lennys-podcast-transcripts> (303 episodes at commit `be8ab89`). Its README says the transcripts are
provided "for personal and educational use"; it has **no license file**. This repo therefore **does not contain transcript text**:
the ingest script clones them at runtime into git-ignored `data/` and indexes them into your database; the UI shows attribution.
* Refresh: `python -m app.ingest --refresh` (only changed files are re-indexed; removed episodes pruned).
* Your own permitted files: `python -m app.ingest --path DIR` where `DIR/episodes/<slug>/transcript.md` (YAML frontmatter + `Speaker (HH:MM:SS):` turns).
* If GitHub is unreachable the script exits with instructions instead of inventing data. Lenny's newsletter is **not** ingested (no verified machine-readable source).
* Source quirks found: README says 269 episodes but 303 exist; 3 turn layouts; a few episodes lack dates/URLs; `ryan-hoover/` metadata names a different guest in its title.

## Environment variables
Full, commented list: [`.env.example`](.env.example) (backend) and [`frontend/.env.example`](frontend/.env.example) (`VITE_API_BASE_URL` only).
Which go on Vercel vs the backend host: [docs/deployment.md](docs/deployment.md).

## Tests
```bash
cd backend && pytest -q                 # 119 tests; spins up an embedded PostgreSQL (pgserver), applies Alembic, ingests synthetic fixtures
cd backend && ruff check . && mypy app --ignore-missing-imports
cd frontend && npm test && npm run typecheck && npm run build
python -m scripts.eval_retrieval        # needs the real index: calibration of on/off-topic retrieval scores
```
Backend tests cover: validation, session isolation & ownership, persistence across app restart, grounded answers/citations (hallucinated
citations stripped), empty retrieval (no model call), follow-ups, provider routing, missing keys, Ollama down/missing model/timeout/500,
visible fallback, cloud timeout, DB down, rate limit, CORS, essay skill (length correction, fallback plan, refusal), 22 XSS/exfil
payloads for the sanitiser, SDK option lockdown and error mapping, ingest incremental/prune. Fixtures are **synthetic** (not real transcripts); LLM
backends are test doubles. Frontend tests cover API client, loading/error/retry states, session creation, provider switching, citation chips, fallback badge, artifact flow, sandbox attributes.

## Deploy
Frontend → **Vercel** (root `frontend`, Vite preset, `VITE_API_BASE_URL`). Backend → **Render** (Docker, `render.yaml`, one instance) or Railway/Fly.
Database → **Supabase** Postgres. Ollama stays local. Exact steps, smoke tests and the submission checklist: [docs/deployment.md](docs/deployment.md).

## Troubleshooting
| Symptom | Fix |
|---|---|
| Pill says "Ollama · local" with red dot / "not reachable" | `ollama serve`; in Docker set `OLLAMA_BASE_URL=http://host.docker.internal:11434` |
| "Model 'x' is not installed" | `ollama pull x` or change `OLLAMA_MODEL` |
| Banner "Can't reach the API" | backend not running, wrong `VITE_API_BASE_URL` (rebuild after changing it), or CORS: add the exact origin to `CORS_ALLOWED_ORIGINS` |
| "knowledge base is empty" | run the ingest step |
| `database_unavailable` | check `DATABASE_URL`; the app recovers automatically when Postgres returns |
| Supabase pooler errors | use the pooler string; prepared statements are already disabled |
| Essay slow / times out locally | smaller/faster model, raise `LLM_TIMEOUT_SECONDS` / `ESSAY_TOTAL_TIMEOUT_SECONDS` |
| Claude provider "runtime not found" | `pip install -r requirements.txt` (the SDK wheel bundles its runtime) |
| 429 `rate_limited` | raise `RATE_LIMIT_PER_MINUTE` |

## Known limitations
No authentication (anonymous browser id — not a security boundary) · single backend instance (in-process jobs) · no token streaming
(poll-based) · lexical retrieval can't reject off-topic questions by score alone (layered abstention; embeddings are the next step) ·
local-model behaviour (verdict protocol, essay length) unverified here · sponsor reads in transcripts are indexed · no newsletter ·
HTML artifact links are inert by design · accessibility not audited with assistive tech.

## Layout
```
backend/   app/{api,llm,rag,skills,services}  alembic/  scripts/  tests/  Dockerfile
frontend/  src/{components,hooks,lib,test}    vercel.json  nginx.conf  Dockerfile
docs/      PRD · design · architecture · manual-test-plan · deployment · demo-video
agent-logs/  docker-compose.yml  render.yaml  .env.example  Makefile
```
Code: no license file is included — add one (e.g. MIT) before publishing. Transcripts: © Lenny's Podcast and guests; not included.
