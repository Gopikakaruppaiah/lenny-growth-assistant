"""HTML/CSS sanitizer for model-generated artifacts. **Treat all model output as hostile.**

Defence in depth (see docs/architecture.md → Security):
  1. This module (server-side, before storage): allow-list tags/attributes, drop every script,
     event handler, form, frame, object, external URL, ``<link>``, ``<meta>``, ``<base>``; filter CSS.
  2. The browser renders the result in an <iframe sandbox=""> (no scripts, no same-origin).
  3. The iframe document carries a CSP meta: ``default-src 'none'`` + inline styles + data: images.

Any one layer failing should not be enough for compromise.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from html import escape

import nh3

ALLOWED_TAGS = {
    "div", "span", "p", "br", "hr", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li", "dl", "dt", "dd",
    "a", "strong", "em", "b", "i", "u", "s", "small", "sub", "sup", "mark", "code", "pre", "kbd", "blockquote",
    "table", "thead", "tbody", "tfoot", "tr", "th", "td", "caption", "colgroup", "col",
    "section", "article", "header", "footer", "nav", "main", "aside", "figure", "figcaption",
    "details", "summary", "img", "abbr", "cite", "q", "time", "label",
}
ALLOWED_ATTRS = {
    "*": {"class", "id", "style", "title", "lang", "dir", "role", "aria-label", "aria-hidden"},
    "a": {"href", "target"},
    "img": {"src", "alt", "width", "height"},
    "td": {"colspan", "rowspan"},
    "th": {"colspan", "rowspan", "scope"},
    "time": {"datetime"},
}
MAX_BYTES = 200_000

_STYLE_BLOCK = re.compile(r"<style\b[^>]*>(.*?)</style\s*>", re.I | re.S)
_BODY = re.compile(r"<body\b[^>]*>(.*)</body\s*>", re.I | re.S)
_TITLE = re.compile(r"<title\b[^>]*>(.*?)</title\s*>", re.I | re.S)
_IMPORT = re.compile(r"@import[^;]*;?", re.I)
_URL_OPEN = re.compile(r"url\s*\(", re.I)
# NB: '>' is a legal CSS child combinator, so only HTML-ish sequences are rejected, not bare angle brackets.
_BAD_CSS = re.compile(r"expression\s*\(|behavior\s*:|-moz-binding|javascript\s*:|vbscript\s*:|@charset|</|<!--|-->", re.I)
_SAFE_DATA_IMG = re.compile(r"^data:image/(?:png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=\s]+$", re.I)
_SAFE_HREF = re.compile(r"^(?:https?://|mailto:|#)", re.I)


@dataclass
class SanitizeReport:
    removed_tags: int = 0
    removed_style_rules: int = 0
    removed_urls: int = 0
    truncated: bool = False
    notes: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {
            "removed_tags_estimate": self.removed_tags,
            "css_constructs_removed": self.removed_style_rules,
            "external_urls_removed": self.removed_urls,
            "truncated": self.truncated,
            "notes": self.notes,
        }


def _strip_url_declarations(css: str, report: SanitizeReport) -> str:
    """Drop every CSS declaration that contains ``url(...)``.

    Policy: *no* CSS url() at all (not even data: URIs). Generated pages get images via
    <img src="data:image/...">, which is filtered separately. Handles nested parens and quotes.
    """
    out: list[str] = []
    i = 0
    while True:
        m = _URL_OPEN.search(css, i)
        if not m:
            out.append(css[i:])
            break
        start = max(css.rfind(";", 0, m.start()), css.rfind("{", 0, m.start())) + 1
        start = max(start, i)
        depth, j, quote = 1, m.end(), None
        while j < len(css) and depth:
            ch = css[j]
            if quote:
                if ch == quote:
                    quote = None
            elif ch in "\"'":
                quote = ch
            elif ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
            j += 1
        k = j
        while k < len(css) and css[k] not in ";}":
            k += 1
        out.append(css[i:start])
        report.removed_urls += 1
        i = k  # keep the terminator so the surrounding rule stays well-formed
    return "".join(out)


def sanitize_css(css: str, report: SanitizeReport | None = None) -> str:
    report = report or SanitizeReport()
    if _IMPORT.search(css):
        report.removed_style_rules += len(_IMPORT.findall(css))
        css = _IMPORT.sub("", css)
    css = _strip_url_declarations(css, report)
    if _BAD_CSS.search(css):
        report.removed_style_rules += len(_BAD_CSS.findall(css))
        css = _BAD_CSS.sub("", css)
    return css


def _attribute_filter(report: SanitizeReport):
    def f(tag: str, attr: str, value: str) -> str | None:
        v = value.strip()
        if attr == "style":
            cleaned = sanitize_css(v, report)
            return cleaned or None
        if tag == "a" and attr == "href":
            if _SAFE_HREF.match(v):
                return v
            report.removed_urls += 1
            return None
        if tag == "img" and attr == "src":
            if _SAFE_DATA_IMG.match(v):
                return v
            report.removed_urls += 1
            return None
        if attr == "target":
            return "_blank"
        return value

    return f


def sanitize_html_document(raw: str, fallback_title: str = "Artifact") -> tuple[str, str, SanitizeReport]:
    """Return ``(clean_document, title, report)``. Output is a complete, standalone HTML document."""
    report = SanitizeReport()
    if len(raw.encode("utf-8", "ignore")) > MAX_BYTES:
        raw = raw.encode("utf-8", "ignore")[:MAX_BYTES].decode("utf-8", "ignore")
        report.truncated = True
        report.notes.append(f"Input exceeded {MAX_BYTES} bytes and was truncated.")

    title_match = _TITLE.search(raw)
    title = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", title_match.group(1))).strip() if title_match else ""
    title = (title or fallback_title)[:200]

    css_blocks = [sanitize_css(m, report) for m in _STYLE_BLOCK.findall(raw)]
    no_style = _STYLE_BLOCK.sub("", raw)
    body_match = _BODY.search(no_style)
    fragment = body_match.group(1) if body_match else no_style
    # Remove <head>…</head> and <title> remnants if the model omitted <body>.
    fragment = re.sub(r"<head\b.*?</head\s*>", "", fragment, flags=re.I | re.S)
    fragment = re.sub(r"<title\b.*?</title\s*>", "", fragment, flags=re.I | re.S)

    before = len(re.findall(r"<\s*[a-zA-Z]", fragment))
    clean = nh3.clean(
        fragment,
        tags=ALLOWED_TAGS,
        attributes=ALLOWED_ATTRS,
        attribute_filter=_attribute_filter(report),
        url_schemes={"http", "https", "mailto", "data"},  # nh3 drops 'data' by default; attribute_filter below re-restricts it per tag
        link_rel="noopener noreferrer nofollow",
        strip_comments=True,
        clean_content_tags={"script", "style", "iframe", "object", "embed", "noscript", "template", "svg", "math"},
    )
    after = len(re.findall(r"<\s*[a-zA-Z]", clean))
    report.removed_tags = max(0, before - after)

    css = "\n".join(c.strip() for c in css_blocks if c.strip())
    doc = (
        '<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        f"<title>{escape(title)}</title>"
        f"<style>{css}</style></head><body>{clean}</body></html>"
    )
    return doc, title, report


_MD_SCRIPT = re.compile(r"<\s*(script|style|iframe|object|embed)\b.*?<\s*/\s*\1\s*>", re.I | re.S)
_MD_JS_LINK = re.compile(r"\]\(\s*(?:javascript|vbscript|data):[^)]*\)", re.I)


def sanitize_markdown(raw: str) -> tuple[str, SanitizeReport]:
    """Markdown is rendered by a renderer that ignores raw HTML; we still scrub obvious payloads."""
    report = SanitizeReport()
    if len(raw.encode("utf-8", "ignore")) > MAX_BYTES:
        raw = raw.encode("utf-8", "ignore")[:MAX_BYTES].decode("utf-8", "ignore")
        report.truncated = True
    scripts = _MD_SCRIPT.findall(raw)
    report.removed_tags = len(scripts)
    raw = _MD_SCRIPT.sub("", raw)
    links = _MD_JS_LINK.findall(raw)
    report.removed_urls = len(links)
    raw = _MD_JS_LINK.sub("](#)", raw)
    return raw.strip(), report
