import { useEffect, useRef, useState } from "react";
import type { ApiError } from "../lib/api";
import type { ProviderName, ProvidersResponse } from "../lib/types";

const LABEL = { ollama: "Ollama", anthropic: "Claude" } as const;

export function ProviderMenu({
  data, error, choice, onChoose,
}: { data: ProvidersResponse | null; error: ApiError | null; choice: ProviderName | null; onChoose: (p: ProviderName | null) => void }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    const onClick = (e: MouseEvent) => ref.current && !ref.current.contains(e.target as Node) && setOpen(false);
    document.addEventListener("keydown", onKey);
    document.addEventListener("mousedown", onClick);
    return () => { document.removeEventListener("keydown", onKey); document.removeEventListener("mousedown", onClick); };
  }, [open]);

  if (!data) {
    return <span className="provider-pill off" role="status">{error ? "API unreachable" : "Connecting…"}</span>;
  }
  const active = data.providers.find((p) => p.name === (choice ?? data.default))!;
  return (
    <div className="provider" ref={ref}>
      <button type="button" className={`provider-pill ${active.ready ? "ready" : "off"}`} aria-haspopup="true" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        <span className="dot" aria-hidden="true" />
        <span>{LABEL[active.name]} · {active.kind === "local" ? "local" : "cloud"}</span>
        <span className="muted model">{active.model}</span>
      </button>
      {open && (
        <div className="menu" role="menu" aria-label="Model provider">
          <p className="menu-note">Choose which model answers your next messages. The server default is <strong>{LABEL[data.default]}</strong>
            {data.fallback ? <>, with fallback to <strong>{LABEL[data.fallback as ProviderName]}</strong></> : ", with no fallback"}.</p>
          {[null, ...data.providers.map((p) => p.name)].map((opt) => {
            const p = opt ? data.providers.find((x) => x.name === opt)! : null;
            const selected = opt === choice;
            return (
              <button key={opt ?? "default"} role="menuitemradio" aria-checked={selected} className={`menu-item ${selected ? "on" : ""}`} onClick={() => { onChoose(opt); setOpen(false); }}>
                <span className="radio" aria-hidden="true" />
                <span className="menu-text">
                  <strong>{p ? `${LABEL[p.name]} (${p.kind})` : `Server default (${LABEL[data.default]})`}</strong>
                  {p && <span className={p.ready ? "ok-text" : "bad-text"}>{p.ready ? "● " : "○ "}{p.detail}</span>}
                  {p && !p.ready && p.hint && <span className="muted">{p.hint}</span>}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}
