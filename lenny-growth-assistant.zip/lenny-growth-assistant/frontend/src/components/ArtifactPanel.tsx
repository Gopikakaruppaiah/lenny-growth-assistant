import { useCallback, useEffect, useState } from "react";
import { ApiError, api } from "../lib/api";
import { IFRAME_SANDBOX, buildSrcDoc, copyText, download, safeFileName } from "../lib/artifactFrame";
import type { Artifact } from "../lib/types";
import type { Viewer } from "../hooks/useAssistant";
import { Markdown } from "./Markdown";

type Loaded = { kind: "markdown" | "html"; title: string; content: string; meta?: string };

/** The ONLY place untrusted HTML is rendered. Empty sandbox + CSP-wrapped srcdoc. */
export function ArtifactFrame({ html, title }: { html: string; title: string }) {
  return (
    <iframe
      className="artifact-frame"
      title={`Preview of ${title}`}
      sandbox={IFRAME_SANDBOX}
      referrerPolicy="no-referrer"
      srcDoc={buildSrcDoc(html)}
    />
  );
}

export function ArtifactPanel({ viewer, onClose }: { viewer: Viewer; onClose: () => void }) {
  const [data, setData] = useState<Loaded | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const [tab, setTab] = useState<"preview" | "source">("preview");
  const [copied, setCopied] = useState(false);

  const load = useCallback(async () => {
    if (!viewer) return;
    setError(null);
    if (viewer.type === "essay") {
      const m = viewer.message;
      setData({ kind: "markdown", title: m.content.match(/^#\s+(.+)$/m)?.[1] ?? "Essay", content: m.content, meta: `${m.meta.word_count ?? "?"} words · Ship 30 for 30 skill` });
      return;
    }
    setLoading(true);
    setData(null);
    try {
      const a: Artifact = await api.getArtifact(viewer.id);
      setData({ kind: a.kind, title: a.title, content: a.content, meta: `${a.provider ?? "model"}${a.model ? ` · ${a.model}` : ""}` });
    } catch (e) {
      setError(e instanceof ApiError ? e : new ApiError("unknown", "Could not load the artifact.", 0));
    } finally { setLoading(false); }
  }, [viewer]);

  useEffect(() => { setTab("preview"); void load(); }, [load]);

  if (!viewer) {
    return (
      <aside className="panel empty" aria-label="Artifact viewer">
        <div className="empty-art" aria-hidden="true"><span /><span /><span /></div>
        <h2>Artifact viewer</h2>
        <p className="muted">Essays, Markdown documents and HTML/CSS pages you generate open here, next to the chat.</p>
      </aside>
    );
  }

  const ext = data?.kind === "html" ? "html" : "md";
  return (
    <aside className="panel" aria-label="Artifact viewer">
      <header className="panel-head">
        <div className="panel-title">
          <span className="card-kicker">{data ? (data.kind === "html" ? "HTML / CSS" : "Markdown") : "Artifact"}</span>
          <h2 title={data?.title}>{data?.title ?? "Loading…"}</h2>
        </div>
        <div className="panel-actions">
          <div className="seg" role="tablist" aria-label="View">
            <button role="tab" aria-selected={tab === "preview"} className={tab === "preview" ? "on" : ""} onClick={() => setTab("preview")}>Preview</button>
            <button role="tab" aria-selected={tab === "source"} className={tab === "source" ? "on" : ""} onClick={() => setTab("source")}>{data?.kind === "html" ? "HTML" : "Markdown"}</button>
          </div>
          <button type="button" className="btn small" disabled={!data} onClick={async () => { if (data) { setCopied(await copyText(data.content)); setTimeout(() => setCopied(false), 1500); } }}>
            {copied ? "Copied" : "Copy"}
          </button>
          <button type="button" className="btn small" disabled={!data} onClick={() => data && download(safeFileName(data.title, ext), data.content, data.kind === "html" ? "text/html" : "text/markdown")}>
            Download
          </button>
          <button type="button" className="icon-btn" onClick={onClose} aria-label="Close viewer">✕</button>
        </div>
      </header>

      <div className="panel-body">
        {loading && <div className="state" role="status"><span className="dots" aria-hidden="true"><i /><i /><i /></span> Loading artifact…</div>}
        {error && (
          <div className="state error-card" role="alert">
            <strong>{error.message}</strong>
            {error.hint && <p>{error.hint}</p>}
            <button type="button" className="btn small" onClick={() => void load()}>Try again</button>
          </div>
        )}
        {data && tab === "preview" && data.kind === "markdown" && <div className="doc"><Markdown text={data.content} /></div>}
        {data && tab === "preview" && data.kind === "html" && (
          <>
            <ArtifactFrame html={data.content} title={data.title} />
            <p className="safe-note">
              Rendered in an isolated sandbox: scripts, forms, links and network requests are blocked. <span className="muted">{data.meta}</span>
            </p>
          </>
        )}
        {data && tab === "source" && <pre className="source-view" tabIndex={0}><code>{data.content}</code></pre>}
      </div>
    </aside>
  );
}
