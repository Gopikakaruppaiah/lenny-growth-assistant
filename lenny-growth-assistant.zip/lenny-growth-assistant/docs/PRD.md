# PRD — The Lenny Growth Assistant

## 1. Users and problem
**Primary user:** a product manager, founder, or growth lead who has 300 hours of Lenny's Podcast available but no time to
search it, and who distrusts generic AI answers that cannot show their source.
**Problem:** (a) finding what specific guests actually said about a topic is slow; (b) general chatbots blend memory with
invention and give no way to verify; (c) turning insight into shareable writing is a separate, manual job.
**Job to be done:** "Answer my question using what Lenny's guests really said, show me where, and help me turn it into an essay
or a one-page artifact I can share."

## 2. Success metrics
| Metric | Target | How measured |
|---|---|---|
| Answers carry ≥1 validated citation (when model called and verdict ≠ UNSUPPORTED) | ≥ 95 % | `meta.grounded` over the manual eval set |
| Invalid citations reaching the user | 0 | server validation; unit + integration tests |
| Off-topic questions that receive a confident ungrounded answer | ≤ 10 % of the 8-question off-topic set with the chosen model | manual eval (`scripts/eval_retrieval.py` + UI) |
| Essay length within 1,125–1,375 words | ≥ 80 % of runs | `meta.meets_target` |
| Essay passes all 8 structural checks | ≥ 75 % of runs | `meta.quality_checks` |
| Median time to first grounded answer (cloud model) | ≤ 15 s | `latency_ms` |
| Retrieval latency p95 | ≤ 500 ms | request logs (measured 13–362 ms locally) |
| Zero secrets in frontend bundle / repo | 0 | bundle scan, git grep |
| Hostile HTML artifact executes anything | 0 | 22 sanitiser payload tests + sandbox attribute tests |

*Targets for model-dependent metrics are hypotheses to be confirmed with real models; they have not been measured here.*

## 3. Assumptions
1. The transcript repo remains available and its terms stay "personal and educational use"; therefore it is indexed per-deployer, not redistributed.
2. Reviewers will run Ollama locally (≥ 8 GB RAM for a 3B model) and the public demo uses a cloud model.
3. Single instance and anonymous per-browser identity are acceptable for a take-home demo.
4. English-language corpus; PostgreSQL full-text search is adequate as the candidate retriever.

## 4. Scope
**In scope:** FastAPI backend; Claude Agent SDK + Ollama providers selectable by config; PostgreSQL persistence; transcript
ingestion with attribution; grounded chat with follow-ups and independent sessions; Ship 30 for 30 essay skill (~1,250 words);
Markdown and sandboxed HTML/CSS artifacts in a side viewer; health, logging, validation; Docker Compose; Vercel + Render configs; tests; docs.
**Out of scope (documented, not built):** authentication/accounts; streaming tokens; embeddings/semantic re-ranking;
multi-instance job queue; transcript redistribution; Lenny's newsletter (no verified legitimate machine-readable source was
found; user-supplied files are supported); PDF/Word export; analytics; i18n.

## 5. Workflows
1. **Ask** → type or pick a starter → pending state → answer with `[n]` chips → expand sources → open YouTube at the moment.
2. **Follow up** → "what about enterprise?" → condensed retrieval using the prior question, same session only.
3. **Not covered** → plain statement that transcripts don't cover it (no model call if nothing matched).
4. **Essay** → "Write essay" (or type "write an essay on…") → plan→sections→length check → quality checklist → open in viewer → copy/download `.md`.
5. **Artifact** → "Create artifact" → choose Markdown/HTML → generation → opens beside chat; HTML in isolated sandbox; Preview/Source tabs, copy, download.
6. **Provider** → pill shows provider/model/readiness; switch per request; fallback is always labelled.
7. **Failure** → readable error + hint + Retry (Ollama down, model missing, timeout, DB down, rate limit).

## 6. Acceptance criteria (selected; full mapping in `docs/manual-test-plan.md`)
- AC1 Every assistant answer displays provider+model, or "No model used".
- AC2 With Ollama stopped, asking shows "Ollama is not reachable…" with the `ollama serve` hint, and never a cloud answer unless a fallback is configured and labelled.
- AC3 With no `ANTHROPIC_API_KEY`, Ollama works normally; selecting Claude yields an actionable error.
- AC4 Two sessions never share context (verified by test on the exact prompt sent to the model).
- AC5 Reloading the page restores sessions and messages from PostgreSQL.
- AC6 A fabricated citation number from the model is removed and reported.
- AC7 HTML artifacts render with `sandbox=""` and a CSP; scripts do not run.
- AC8 Essay shows word count vs 1,250 target and the 8 checks; failing checks are visible.
- AC9 No secret appears in the frontend bundle or logs.
- AC10 Works at 375 px wide (tabs for chat/artifact) and ≥ 1100 px (side-by-side).

## 7. Risks and trade-offs
| Risk | Mitigation / trade-off |
|---|---|
| Lexical retrieval cannot reject off-topic queries by score alone (measured) | Layered abstention; model verdict; citation validation; documented embedding upgrade |
| Small local models ignore the verdict protocol or under-write essays | Server-side validation + warnings; section-wise writing with length correction; honest checks |
| Agent SDK is Anthropic-only | Two providers behind one interface; labelled in UI |
| Transcript licensing is unclear | No redistribution; runtime clone; attribution; user-supplied path |
| In-process jobs limit scale | Single instance documented; orphan sweep; queue as next step |
| Anonymous identity is not security | Documented; cost caps; rate limit |
| Public cloud demo costs money | Rate limit, `max_budget_usd`, optional budget alerts |
| CSP `style-src 'unsafe-inline'` is needed for artifact styles | Scripts remain blocked everywhere; artifacts also carry their own CSP + empty sandbox |

## 8. Implementation plan (as executed)
1. Verify sources & SDK docs → 2. schema + migration → 3. ingestion + parser (3 layouts) → 4. retrieval + calibration →
5. providers + registry → 6. chat vertical slice (frontend→API→model→retrieval→PostgreSQL) → 7. sessions/jobs/errors →
8. essay + artifact skills + sanitiser → 9. frontend polish → 10. tests (backend 119, frontend 30) → 11. Docker/Vercel/Render configs → 12. docs.
