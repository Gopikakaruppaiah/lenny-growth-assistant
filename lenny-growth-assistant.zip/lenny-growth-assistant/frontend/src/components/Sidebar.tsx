import type { Session } from "../lib/types";

function when(iso: string): string {
  const d = new Date(iso);
  const diff = Date.now() - d.getTime();
  if (diff < 60_000) return "just now";
  if (diff < 3_600_000) return `${Math.floor(diff / 60_000)}m ago`;
  if (diff < 86_400_000) return `${Math.floor(diff / 3_600_000)}h ago`;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function Sidebar({
  sessions, activeId, loading, onNew, onSelect, onDelete, open, onClose,
}: { sessions: Session[]; activeId: string | null; loading: boolean; onNew: () => void; onSelect: (id: string) => void; onDelete: (id: string) => void; open: boolean; onClose: () => void }) {
  return (
    <>
      {open && <div className="scrim mobile-only" onClick={onClose} aria-hidden="true" />}
      <nav className={`sidebar ${open ? "open" : ""}`} aria-label="Chat history">
        <div className="brand"><span className="logo" aria-hidden="true">L</span><span>Lenny Growth<br />Assistant</span></div>
        <button type="button" className="btn primary wide" onClick={() => { onNew(); onClose(); }}>＋ New chat</button>
        <h2 className="side-h">History</h2>
        <ul className="sessions">
          {loading && <li className="muted pad">Loading…</li>}
          {!loading && sessions.length === 0 && <li className="muted pad">No chats yet. Ask your first question.</li>}
          {sessions.map((s) => (
            <li key={s.id} className={s.id === activeId ? "active" : ""}>
              <button type="button" className="session-btn" aria-current={s.id === activeId ? "true" : undefined} onClick={() => { onSelect(s.id); onClose(); }}>
                <span className="session-title">{s.title}</span>
                <span className="muted small">{when(s.updated_at)}</span>
              </button>
              <button type="button" className="icon-btn del" aria-label={`Delete chat: ${s.title}`} onClick={() => { if (window.confirm("Delete this chat and its artifacts?")) onDelete(s.id); }}>🗑</button>
            </li>
          ))}
        </ul>
        <p className="side-foot muted small">Transcripts © Lenny's Podcast and guests, used for personal and educational purposes.</p>
      </nav>
    </>
  );
}
