"""FastAPI application factory."""

from __future__ import annotations

import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from . import __version__
from .api import health, providers, sessions, sources
from .config import Settings, get_settings
from .db import make_engine, make_session_factory
from .errors import register_error_handlers
from .llm.registry import ProviderRegistry
from .logging_setup import configure_logging, get_logger, request_id_var
from .services.chat import ChatService
from .services.jobs import JobManager, RateLimiter, mark_orphaned_pending

log = get_logger("app")


def create_app(settings: Settings | None = None, providers_registry: ProviderRegistry | None = None) -> FastAPI:
    settings = settings or get_settings()
    configure_logging(settings.log_level, settings.log_format)

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        engine = make_engine(settings)
        factory = make_session_factory(engine)
        jobs = JobManager()
        registry = providers_registry or ProviderRegistry(settings)
        app.state.settings, app.state.engine, app.state.session_factory = settings, engine, factory
        app.state.jobs, app.state.providers = jobs, registry
        app.state.chat = ChatService(settings, factory, registry, jobs)
        app.state.rate_limiter = RateLimiter(settings.rate_limit_per_minute)
        try:
            await mark_orphaned_pending(factory)
        except Exception as exc:  # noqa: BLE001 - app must still boot so /health works and errors are visible
            log.error("startup sweep skipped (database unavailable?)", extra={"error_type": type(exc).__name__})
        log.info("startup", extra={"provider": settings.llm_provider, "fallback": settings.llm_fallback_provider,
                                   "env": settings.app_env, "cors_origins": settings.cors_origins})
        yield
        await jobs.shutdown()
        await engine.dispose()

    app = FastAPI(title="Lenny Growth Assistant API", version=__version__, lifespan=lifespan)
    register_error_handlers(app)

    @app.middleware("http")
    async def request_context(request: Request, call_next):
        rid = (request.headers.get("x-request-id") or uuid.uuid4().hex)[:64]
        token = request_id_var.set(rid)
        t0 = time.monotonic()
        try:
            response = await call_next(request)
            response.headers["X-Request-Id"] = rid
            response.headers["X-Content-Type-Options"] = "nosniff"
            response.headers["Cache-Control"] = "no-store"
            if not request.url.path.startswith("/api/v1/health"):
                log.info("request", extra={"method": request.method, "path": request.url.path,
                                           "status": response.status_code, "ms": int((time.monotonic() - t0) * 1000)})
            return response
        finally:
            request_id_var.reset(token)

    app.add_middleware(
        CORSMiddleware, allow_origins=settings.cors_origins, allow_credentials=False,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"], allow_headers=["Content-Type", "X-Client-Id", "X-Request-Id"],
        expose_headers=["X-Request-Id"], max_age=600,
    )
    for r in (health.router, providers.router, sources.router, sessions.router):
        app.include_router(r, prefix="/api/v1")
    return app


app = create_app()
