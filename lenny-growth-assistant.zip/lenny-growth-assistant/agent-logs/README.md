# Coding-agent log

**What this is:** a curated, chronological record of the AI-assisted build (one Claude session), written from the actual
tool calls and outputs. **What it is not:** a raw export of the chat transcript — the platform did not give the agent a way to
dump it. No secrets appear here (none were ever available in the build environment). Claim nothing here that is not in the
"Verified" column of the root README.

## Timeline
| # | What happened | Kind |
|---|---|---|
| 1 | Read the assignment `.docx`; workspace was empty (greenfield). No Docker, Postgres, Ollama, browser or API keys in the sandbox → decided on embedded PostgreSQL (`pgserver`) for real DB tests and labelled test doubles for LLMs. | plan |
| 2 | Fetched the transcript repo. **Found no LICENSE; README says "personal and educational use".** Decision: never commit transcripts; clone at runtime. | finding |
| 3 | `web_fetch` of the Ship 30 guide URL failed with a permissions error (URL not seen in a prior search). | ❌ failure → fixed by searching first, then fetching |
| 4 | Introspected `claude-agent-sdk` 0.2.165 (options, `tool`, `create_sdk_mcp_server`, error enums) instead of coding from memory. Learned the SDK is Anthropic-only → two-provider design. | decision |
| 5 | `mkdir -p dir/{a,b}` under `/bin/sh` created nothing useful (no brace expansion). | ❌ failure → reran with `bash -c`. **Repeated later for `src/{components,…}`** (created a literal `{components,...}` folder) → cleaned up and recreated. |
| 6 | Ran the parser over all 303 episodes: **2 failed**. Inspected them: two other turn layouts (`[ts] Name: text` and untimed `Name:`). | ❌ failure → parser now handles 3 layouts; 303/303 parse |
| 7 | First retrieval check on the real corpus: on-topic queries good, but **"capital of France" and "bake sourdough bread" were judged sufficient** by my coverage gate. | ❌ design flaw |
| 8 | Wrote `scripts/eval_retrieval.py` (16 on-topic / 8 off-topic). Result: scores **overlap** — no threshold works. Replaced the "score gate" idea with layered abstention (deterministic no-match → model verdict → server-side citation validation) and documented the limit instead of shipping a fake threshold. | ✅ correction |
| 9 | `nh3` raised `ValueError` when `rel` was allow-listed together with `link_rel`. | ❌ → removed `rel` from allow-list |
| 10 | Red-teaming the sanitiser showed two sloppy outputs: a malformed value from nested `url(javascript:alert(7))`, and `>` (CSS child combinator) being stripped. | ❌ → declaration-level `url()` scanner; only HTML-ish sequences rejected |
| 11 | My synthetic test fixture had `title: Synthetic: …` (invalid YAML) → ingest "succeeded" with 0 documents. This exposed a **real bug**: parse failures weren't recorded and an all-failed run reported `complete`. | ❌ → run now records the warning, fails loudly if nothing parses; fixture quoted |
| 12 | Test expected user metadata refresh on return visits; code only set it on first insert. | design fix → merge metadata on every visit |
| 13 | Test double returned HTML for a markdown request (matched the word "HTML" in "no raw HTML"). Separately, **data-URI images were stripped** because `nh3` drops the `data` scheme before my filter runs. | fake bug + ❌ real bug → fixed both |
| 14 | mypy: 20 errors (mostly my `**base` dict-splat for `ProviderStatus`). | ❌ → explicit constructors; 0 errors |
| 15 | Frontend tests: 5 failed because `/chat a/i` matched both the session button and its "Delete chat: Chat A" button; one test I wrote was convoluted nonsense. | test bug → anchored selectors, rewrote test |
| 16 | HTTP smoke test: background servers died when the tool shell exited (needed `setsid nohup`). The embedded Postgres also died → **API correctly returned 503 `database_unavailable`, `/health` stayed 200, and it recovered by itself** when Postgres returned. | harness issue; useful resilience evidence |
| 17 | Retrieval output revealed `product-market` was fused into the never-matching token `productmarket`. | ❌ real bug → hyphenated terms become phrase operators (+ regression test; top score 0.47→0.64) |
| 18 | Smoke test: the nonsense query `zzqxv wwkpl` **inherited the previous question's topic** (follow-up heuristic too eager). | ❌ real bug → context borrowed only for anaphora / single bare term (+ 2 regression tests) |
| 19 | Request logs showed `request_id: "-"` (logged after resetting the context var). | ❌ → logged before reset |
| 20 | `pkill -f "<pattern>"` matched the agent's own shell command three times and killed it. | ❌ → kill by PID |
| 21 | README told users to copy `.env` to the repo root, but the backend reads `./.env` from its cwd. Verified empirically, corrected. | ❌ docs bug → fixed |
| 22 | Checked Vercel (Vite preset, `VITE_` is public) and Render (Docker blueprint) docs before writing config. Render facts came from secondary sources → flagged in docs. | verification |

## What the agent could not do (so you must)
Run a real Claude call, run real Ollama, build/run Docker, view the UI in a browser, deploy anywhere, record the video, and
export a raw transcript. See README "Honest status" and `docs/deployment.md`.
