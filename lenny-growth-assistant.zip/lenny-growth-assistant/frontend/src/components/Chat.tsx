import { useEffect, useRef, useState } from "react";
import type { CorpusStats, Message } from "../lib/types";
import { MessageView } from "./MessageView";

const STARTERS = [
  "How do I know if I have product-market fit?",
  "What do great PMs do to improve onboarding and activation?",
  "How should I think about pricing for a B2B SaaS product?",
  "How do top teams run growth experiments?",
];

export function EmptyState({ stats, onPick, disabled }: { stats: CorpusStats | null; onPick: (q: string) => void; disabled: boolean }) {
  return (
    <div className="empty-state">
      <p className="eyebrow">Grounded in Lenny's Podcast</p>
      <h1>Ask a product or growth question.</h1>
      <p className="lede">Answers cite the exact episode and moment they came from. If the transcripts don't cover it, you'll be told — not guessed at.</p>
      {stats && stats.chunks === 0 && (
        <div className="error-card" role="alert">
          <strong>The knowledge base is empty.</strong>
          <p>Run <code>python -m app.ingest</code> (or <code>docker compose run --rm ingest</code>) to index the transcripts.</p>
        </div>
      )}
      {stats && stats.chunks > 0 && <p className="stats">{stats.episodes} episodes · {stats.chunks.toLocaleString()} passages indexed{stats.source_commit ? ` · source ${stats.source_commit.slice(0, 7)}` : ""}</p>}
      <div className="starters">
        {STARTERS.map((q) => <button key={q} type="button" className="starter" disabled={disabled} onClick={() => onPick(q)}>{q}</button>)}
      </div>
    </div>
  );
}

export function Chat({
  messages, loading, generating, stats, onSend, onEssay, onArtifactDialog, onRetry, onOpenEssay, onOpenArtifact,
}: {
  messages: Message[]; loading: boolean; generating: boolean; stats: CorpusStats | null;
  onSend: (t: string) => Promise<boolean>; onEssay: (topic: string | null) => Promise<boolean>; onArtifactDialog: (seed: string) => void;
  onRetry: (id: string) => void; onOpenEssay: (m: Message) => void; onOpenArtifact: (id: string) => void;
}) {
  const [text, setText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const taRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" }); }, [messages.length, messages.at(-1)?.status]);
  useEffect(() => {
    const ta = taRef.current;
    if (ta) { ta.style.height = "auto"; ta.style.height = `${Math.min(ta.scrollHeight, 200)}px`; }
  }, [text]);

  const submit = async () => {
    const t = text.trim();
    if (!t || generating) return;
    setText("");
    if (!(await onSend(t))) setText(t);
  };
  const lastQuestion = [...messages].reverse().find((m) => m.role === "user" && m.kind === "chat")?.content ?? "";

  return (
    <section className="chat" aria-label="Conversation">
      <div className="scroll" role="log" aria-live="polite" aria-relevant="additions">
        {loading && <div className="state" role="status"><span className="dots" aria-hidden="true"><i /><i /><i /></span> Loading conversation…</div>}
        {!loading && messages.length === 0 && <EmptyState stats={stats} disabled={generating} onPick={(q) => void onSend(q)} />}
        <div className="thread">
          {messages.map((m) => <MessageView key={m.id} m={m} onRetry={onRetry} onOpenEssay={onOpenEssay} onOpenArtifact={onOpenArtifact} />)}
        </div>
        <div ref={endRef} />
      </div>

      <form className="composer" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
        <label htmlFor="composer-input" className="sr-only">Message</label>
        <textarea
          id="composer-input" ref={taRef} value={text} rows={1} maxLength={4000} disabled={false}
          placeholder={generating ? "Waiting for the current reply to finish…" : "Ask about onboarding, pricing, retention, hiring…"}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => { if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); void submit(); } }}
        />
        <div className="composer-row">
          <div className="actions">
            <button type="button" className="btn small" disabled={generating || (!text.trim() && !lastQuestion)} onClick={() => { const t = text.trim(); setText(""); void onEssay(t || null); }}
              title="Write a ~1,250-word Ship 30 for 30 essay on the text above, or on your last question">
              ✍️ Write essay
            </button>
            <button type="button" className="btn small" disabled={generating} onClick={() => onArtifactDialog(text.trim() || lastQuestion)}>◧ Create artifact</button>
          </div>
          <div className="send">
            {text.length > 3500 && <span className="muted">{text.length}/4000</span>}
            <button type="submit" className="btn primary" disabled={!text.trim() || generating}>{generating ? "Working…" : "Send"}</button>
          </div>
        </div>
      </form>
    </section>
  );
}
