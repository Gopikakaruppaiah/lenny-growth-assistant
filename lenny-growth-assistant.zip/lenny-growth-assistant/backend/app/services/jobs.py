"""In-process background job tracking + a sliding-window rate limiter.

Generation can take minutes on a local model, so POST endpoints return 202 immediately and the
client polls the pending assistant message. This is deliberately simple (single backend instance,
asyncio tasks). If you scale to multiple instances, move this to a queue (see docs/architecture.md).
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict, deque
from collections.abc import Coroutine
from typing import Any

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from ..logging_setup import get_logger

log = get_logger("jobs")


class JobManager:
    def __init__(self) -> None:
        self._tasks: dict[str, asyncio.Task[Any]] = {}

    def spawn(self, key: str, coro: Coroutine[Any, Any, Any]) -> None:
        task = asyncio.create_task(coro, name=f"job:{key}")
        self._tasks[key] = task
        task.add_done_callback(lambda _t: self._tasks.pop(key, None))  # type: ignore[arg-type,misc]

    def is_running(self, key: str) -> bool:
        return key in self._tasks

    async def wait(self, key: str, timeout: float = 30.0) -> None:  # used by tests
        task = self._tasks.get(key)
        if task:
            await asyncio.wait_for(asyncio.shield(task), timeout)

    async def shutdown(self) -> None:
        for t in self._tasks.values():
            t.cancel()
        await asyncio.gather(*self._tasks.values(), return_exceptions=True)


async def mark_orphaned_pending(factory: async_sessionmaker[AsyncSession]) -> int:
    """On startup, any message still 'pending' belongs to a job that died with the previous process."""
    async with factory() as db:
        res = await db.execute(
            text(
                "UPDATE messages SET status='error', error_code='interrupted', completed_at=now(), "
                "error_message='The server restarted while this was being generated.', "
                "error_hint='Press Retry to generate it again.' WHERE status='pending'"
            )
        )
        await db.commit()
        count = getattr(res, "rowcount", 0) or 0
    if count:
        log.warning("marked orphaned pending messages as failed", extra={"count": count})
    return count


class RateLimiter:
    def __init__(self, per_minute: int) -> None:
        self.per_minute = per_minute
        self._hits: dict[str, deque[float]] = defaultdict(deque)

    def check(self, key: str) -> int | None:
        """Return None if allowed, else seconds until the next slot."""
        if self.per_minute <= 0:
            return None
        now = time.monotonic()
        q = self._hits[key]
        while q and now - q[0] > 60:
            q.popleft()
        if len(q) >= self.per_minute:
            return max(1, int(60 - (now - q[0])) + 1)
        q.append(now)
        return None
