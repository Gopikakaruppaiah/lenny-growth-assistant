"""Integration tests: real FastAPI app + real PostgreSQL; only the LLM backends are test doubles."""

import asyncio
import uuid

import pytest

from .conftest import build_harness, close_harness, make_settings
from .fakes import FakeOllama

pytestmark = pytest.mark.asyncio(loop_scope="session")
API = "/api/v1"


# ------------------------------------------------------------------ health / contracts / validation
async def test_liveness_needs_no_dependencies(h):
    r = await h.client.get(f"{API}/health")
    assert r.status_code == 200 and r.json()["status"] == "ok"
    assert r.headers["x-request-id"]


async def test_readiness_reports_db_and_index(h):
    r = await h.client.get(f"{API}/health/ready")
    body = r.json()
    assert r.status_code == 200 and body["database"] == "up" and body["knowledge_base"] == "indexed"
    assert {p["name"] for p in body["providers"]} == {"ollama", "anthropic"}


async def test_missing_or_bad_client_id_is_400(h):
    r = await h.client.get(f"{API}/sessions")
    assert r.status_code == 400 and r.json()["error"]["code"] == "missing_client_id"
    r = await h.client.get(f"{API}/sessions", headers={"X-Client-Id": "short"})
    assert r.status_code == 400


@pytest.mark.parametrize("payload", [{"content": ""}, {"content": "   "}, {"content": "x" * 4001}, {"content": "hi", "provider": "gpt"},
                                     {"content": "hi", "mode": "weird"}, {}])
async def test_message_validation_returns_structured_422(h, payload):
    sid = await h.new_session()
    r = await h.client.post(f"{API}/sessions/{sid}/messages", json=payload, headers=h.headers())
    body = r.json()
    assert r.status_code == 422 and body["error"]["code"] == "validation_error" and body["error"]["details"]["fields"]
    assert body["error"]["request_id"]


async def test_bad_uuid_and_unknown_session(h):
    assert (await h.client.get(f"{API}/sessions/not-a-uuid", headers=h.headers())).status_code == 422
    r = await h.client.get(f"{API}/sessions/{uuid.uuid4()}", headers=h.headers())
    assert r.status_code == 404 and r.json()["error"]["code"] == "session_not_found"


async def test_nul_bytes_are_stripped_not_a_500(h):
    sid = await h.new_session()
    m = await h.ask(sid, "How does onboarding drive activation?\x00\x00")
    assert m["status"] == "complete"


async def test_unknown_route_uses_error_envelope(h):
    r = await h.client.get(f"{API}/nope")
    assert r.status_code == 404 and r.json()["error"]["code"] == "not_found"


async def test_cors_exact_origin_only(h):
    ok = await h.client.options(f"{API}/sessions", headers={"Origin": "http://localhost:5173", "Access-Control-Request-Method": "POST",
                                                           "Access-Control-Request-Headers": "x-client-id,content-type"})
    assert ok.headers.get("access-control-allow-origin") == "http://localhost:5173"
    bad = await h.client.options(f"{API}/sessions", headers={"Origin": "https://evil.example", "Access-Control-Request-Method": "POST"})
    assert "access-control-allow-origin" not in bad.headers


# ------------------------------------------------------------------ sessions: CRUD, isolation, persistence
async def test_session_crud_and_user_metadata_persisted(h, migrated_db):
    sid = await h.new_session()
    assert (await h.client.patch(f"{API}/sessions/{sid}", json={"title": "Pricing research"}, headers=h.headers())).json()["title"] == "Pricing research"
    assert (await h.client.patch(f"{API}/sessions/{sid}", json={"title": "  "}, headers=h.headers())).status_code == 422
    listed = (await h.client.get(f"{API}/sessions", headers={**h.headers(), "User-Agent": "pytest-agent", "Accept-Language": "en-IN"})).json()
    assert [s["id"] for s in listed] == [sid]
    from sqlalchemy import text
    with migrated_db.connect() as c:
        row = c.execute(text("select metadata->>'user_agent', metadata->>'locale' from users")).one()
    assert row[0] == "pytest-agent" and row[1] == "en-IN"
    assert (await h.client.delete(f"{API}/sessions/{sid}", headers=h.headers())).status_code == 204
    assert (await h.client.get(f"{API}/sessions/{sid}", headers=h.headers())).status_code == 404


async def test_other_users_cannot_see_or_touch_a_session(h):
    sid = await h.new_session()
    other = uuid.uuid4().hex
    assert (await h.client.get(f"{API}/sessions", headers=h.headers(other))).json() == []
    for method, path, kw in [("get", f"/sessions/{sid}", {}), ("get", f"/sessions/{sid}/messages", {}), ("delete", f"/sessions/{sid}", {}),
                             ("post", f"/sessions/{sid}/messages", {"json": {"content": "hello there"}})]:
        r = await getattr(h.client, method)(API + path, headers=h.headers(other), **kw)
        assert r.status_code == 404, (method, path)


async def test_sessions_keep_independent_context(h):
    a, b = await h.new_session(), await h.new_session()
    await h.ask(a, "Tell me about onboarding and activation")
    h.ollama.calls.clear()
    await h.ask(b, "How should I think about pricing for B2B SaaS?")
    sent = " ".join(m["content"] for m in h.ollama.calls[-1]["messages"])
    assert "Tell me about onboarding" not in sent
    ma = (await h.client.get(f"{API}/sessions/{a}/messages", headers=h.headers())).json()
    mb = (await h.client.get(f"{API}/sessions/{b}/messages", headers=h.headers())).json()
    assert len(ma) == 2 and len(mb) == 2 and {m["session_id"] for m in mb} == {b}


async def test_messages_persist_across_app_restart(h):
    sid = await h.new_session()
    await h.ask(sid, "How does onboarding drive activation?")
    await close_harness(h)
    h2 = await build_harness()
    h2.client_id = h.client_id
    try:
        msgs = (await h2.client.get(f"{API}/sessions/{sid}/messages", headers=h2.headers())).json()
        assert [m["role"] for m in msgs] == ["user", "assistant"] and msgs[1]["status"] == "complete" and msgs[1]["created_at"]
    finally:
        await close_harness(h2)


# ------------------------------------------------------------------ grounded chat
async def test_grounded_answer_has_attributed_sources_with_deep_links(h):
    sid = await h.new_session()
    m = await h.ask(sid, "How does onboarding drive activation for new users?")
    assert m["status"] == "complete" and m["provider"] == "ollama" and m["model"] == "llama3.2:3b" and m["fallback_from"] is None
    assert m["meta"]["grounded"] is True and m["meta"]["verdict"] == "SUPPORTED"
    cited = [s for s in m["sources"] if s["cited"]]
    assert cited and all(s["guest"].startswith("Test Guest") and s["snippet"] for s in cited)
    assert cited[0]["deep_link"].startswith("https://www.youtube.com/watch?v=") and "&t=" in cited[0]["deep_link"]
    assert cited[0]["transcript_url"] is None  # synthetic source repo is not a URL
    assert "[1]" in m["content"] and "VERDICT" not in m["content"]


async def test_hallucinated_citations_are_removed_and_reported():
    o = FakeOllama(lambda msgs: "[[VERDICT: SUPPORTED]]\nReal [1]. Made up [42].")
    h = await build_harness(ollama=o)
    try:
        sid = await h.new_session()
        m = await h.ask(sid, "How does onboarding drive activation?")
        assert "[42]" not in m["content"] and any("did not match" in w for w in m["meta"]["citation_warnings"])
    finally:
        await close_harness(h)


async def test_model_saying_unsupported_is_shown_honestly():
    o = FakeOllama(lambda msgs: "[[VERDICT: UNSUPPORTED]]\nThe excerpts talk about activation, not your question.")
    h = await build_harness(ollama=o)
    try:
        m = await h.ask(await h.new_session(), "How does onboarding drive activation?")
        assert m["content"].startswith("I couldn't find enough") and m["meta"]["grounded"] is False
    finally:
        await close_harness(h)


async def test_uncited_answer_gets_a_visible_warning():
    o = FakeOllama(lambda msgs: "[[VERDICT: SUPPORTED]]\nConfident but no citations.")
    h = await build_harness(ollama=o)
    try:
        m = await h.ask(await h.new_session(), "How does onboarding drive activation?")
        assert m["meta"]["grounded"] is False and "ungrounded" in m["content"]
    finally:
        await close_harness(h)


async def test_empty_retrieval_skips_the_model_entirely(h):
    sid = await h.new_session()
    h.ollama.calls.clear()
    m = await h.ask(sid, "zzqxv wwkpl")
    assert m["status"] == "complete" and m["provider"] is None and m["meta"]["model_called"] is False
    assert "couldn't find enough" in m["content"] and h.ollama.calls == [] and m["sources"] == []


async def test_followup_uses_session_history_and_condensed_retrieval(h):
    sid = await h.new_session()
    await h.ask(sid, "How should I think about pricing for B2B SaaS?")
    h.ollama.calls.clear()
    m = await h.ask(sid, "what about enterprise?")
    msgs = h.ollama.calls[-1]["messages"]
    assert any("pricing for B2B SaaS" in x["content"] for x in msgs if x["role"] == "user")
    assert m["status"] == "complete" and "pricing" in m["meta"]["retrieval"]["query"].lower()


async def test_one_generation_at_a_time_per_session():
    o = FakeOllama()
    o.gate = asyncio.Event()
    h = await build_harness(ollama=o)
    try:
        sid = await h.new_session()
        r1 = await h.client.post(f"{API}/sessions/{sid}/messages", json={"content": "How does onboarding drive activation?"}, headers=h.headers())
        assert r1.status_code == 202 and r1.json()["assistant_message"]["status"] == "pending"
        r2 = await h.client.post(f"{API}/sessions/{sid}/messages", json={"content": "and another?"}, headers=h.headers())
        assert r2.status_code == 409 and r2.json()["error"]["code"] == "generation_in_progress"
        o.gate.set()
        assert (await h.wait(sid, r1.json()["assistant_message"]["id"]))["status"] == "complete"
    finally:
        await close_harness(h)


async def test_rate_limit_returns_429():
    h = await build_harness(make_settings(rate_limit_per_minute=2))
    try:
        sid = await h.new_session()
        for _ in range(2):
            await h.ask(sid, "How does onboarding drive activation?")
        r = await h.client.post(f"{API}/sessions/{sid}/messages", json={"content": "again please"}, headers=h.headers())
        assert r.status_code == 429 and r.json()["error"]["code"] == "rate_limited"
    finally:
        await close_harness(h)


# ------------------------------------------------------------------ provider routing & failure modes
async def test_providers_endpoint_never_leaks_keys(anthropic_settings):
    h = await build_harness(anthropic_settings)
    try:
        r = await h.client.get(f"{API}/providers")
        body = r.json()
        assert body["default"] == "ollama" and body["fallback"] is None
        assert "sk-ant" not in r.text
        by = {p["name"]: p for p in body["providers"]}
        assert by["ollama"]["ready"] and by["ollama"]["is_default"] and by["anthropic"]["ready"] and by["anthropic"]["kind"] == "cloud"
    finally:
        await close_harness(h)


async def test_provider_switch_by_config_only(anthropic_settings):
    from .fakes import sdk_stream
    s = anthropic_settings.model_copy(update={"llm_provider": "anthropic"})
    q = sdk_stream(text="[[VERDICT: SUPPORTED]]\nClaude says activation matters [1].", tool_uses=1)
    h = await build_harness(s, claude_query=q)
    try:
        m = await h.ask(await h.new_session(), "How does onboarding drive activation?")
        assert m["provider"] == "anthropic" and m["model"] == "claude-test" and m["meta"]["tool_calls"] == 1
        assert h.ollama.calls == []  # Ollama was never contacted
    finally:
        await close_harness(h)


async def test_per_request_provider_override(h):
    sid = await h.new_session()
    m = await h.ask(sid, "How does onboarding drive activation?", provider="anthropic")
    assert m["status"] == "error" and m["error"]["code"] == "provider_not_configured" and "ANTHROPIC_API_KEY" in m["error"]["hint"]
    assert m["provider"] is None  # nothing pretended to answer


async def test_missing_cloud_key_never_blocks_local_ollama(h):
    m = await h.ask(await h.new_session(), "How does onboarding drive activation?")
    assert m["status"] == "complete" and m["provider"] == "ollama"


@pytest.mark.parametrize("mode,code,hint_part", [
    ("down", "provider_unavailable", "ollama serve"),
    ("missing_model", "model_not_installed", "ollama pull llama3.2:3b"),
    ("timeout", "model_timeout", "LLM_TIMEOUT_SECONDS"),
    ("http500", "provider_bad_response", "Ollama server logs"),
    ("garbage", "provider_bad_response", None),
])
async def test_ollama_failure_modes_give_actionable_errors(mode, code, hint_part):
    o = FakeOllama()
    o.mode = mode
    h = await build_harness(ollama=o)
    try:
        m = await h.ask(await h.new_session(), "How does onboarding drive activation?")
        assert m["status"] == "error" and m["error"]["code"] == code
        if hint_part:
            assert hint_part in m["error"]["hint"]
        assert m["provider"] is None and m["content"] == ""
    finally:
        await close_harness(h)


async def test_retry_after_failure_recovers(monkeypatch):
    o = FakeOllama()
    o.mode = "down"
    h = await build_harness(ollama=o)
    try:
        sid = await h.new_session()
        failed = await h.ask(sid, "How does onboarding drive activation?")
        assert failed["status"] == "error"
        o.mode = "ok"
        r = await h.client.post(f"{API}/sessions/{sid}/messages/{failed['id']}/retry", headers=h.headers())
        assert r.status_code == 202
        done = await h.wait(sid, failed["id"])
        assert done["status"] == "complete" and done["error"] is None and done["provider"] == "ollama"
        assert (await h.client.post(f"{API}/sessions/{sid}/messages/{failed['id']}/retry", headers=h.headers())).status_code == 409
    finally:
        await close_harness(h)


async def test_visible_fallback_never_pretends_to_be_primary():
    s = make_settings(llm_provider="anthropic", llm_fallback_provider="ollama")  # no cloud key
    h = await build_harness(s)
    try:
        m = await h.ask(await h.new_session(), "How does onboarding drive activation?")
        assert m["status"] == "complete" and m["provider"] == "ollama" and m["fallback_from"] == "anthropic"
    finally:
        await close_harness(h)


async def test_cloud_timeout_falls_back_to_ollama(anthropic_settings):
    from .fakes import sdk_stream
    s = anthropic_settings.model_copy(update={"llm_provider": "anthropic", "llm_fallback_provider": "ollama", "llm_timeout_seconds": 0.2})
    h = await build_harness(s, claude_query=sdk_stream(text="late", delay=2))
    try:
        m = await h.ask(await h.new_session(), "How does onboarding drive activation?")
        assert m["provider"] == "ollama" and m["fallback_from"] == "anthropic"
    finally:
        await close_harness(h)


async def test_no_fallback_configured_surfaces_cloud_timeout(anthropic_settings):
    from .fakes import sdk_stream
    s = anthropic_settings.model_copy(update={"llm_provider": "anthropic", "llm_timeout_seconds": 0.2})
    h = await build_harness(s, claude_query=sdk_stream(text="late", delay=2))
    try:
        m = await h.ask(await h.new_session(), "How does onboarding drive activation?")
        assert m["status"] == "error" and m["error"]["code"] == "model_timeout" and m["fallback_from"] is None
    finally:
        await close_harness(h)


# ------------------------------------------------------------------ database failure
async def test_database_down_is_graceful():
    h = await build_harness(make_settings(database_url="postgresql+psycopg://x:y@127.0.0.1:1/nope", db_connect_timeout_seconds=1))
    try:
        assert (await h.client.get(f"{API}/health")).status_code == 200
        ready = await h.client.get(f"{API}/health/ready")
        assert ready.status_code == 503 and ready.json()["database"] == "down"
        r = await h.client.get(f"{API}/sessions", headers=h.headers())
        assert r.status_code == 503 and r.json()["error"]["code"] == "database_unavailable" and r.json()["error"]["hint"]
        assert "postgresql" not in r.text.lower().replace("postgres is running", "")  # no connection string leaked
    finally:
        await close_harness(h)


# ------------------------------------------------------------------ sources
async def test_sources_endpoints(h):
    stats = (await h.client.get(f"{API}/sources/stats")).json()
    assert stats["episodes"] == 3 and stats["chunks"] > 3 and stats["source_commit"] == "deadbeef"
    res = (await h.client.get(f"{API}/sources/search", params={"q": "onboarding activation"})).json()
    assert res["sources"] and res["sources"][0]["guest"].startswith("Test Guest")
    assert (await h.client.get(f"{API}/sources/search", params={"q": "x"})).status_code == 422


async def test_nonsense_mid_conversation_still_skips_the_model(h):
    sid = await h.new_session()
    await h.ask(sid, "How should I think about pricing for B2B SaaS?")
    h.ollama.calls.clear()
    m = await h.ask(sid, "zzqxv wwkpl")
    assert m["meta"]["model_called"] is False and m["provider"] is None and h.ollama.calls == []
