"""Turn a user message (plus recent context) into a safe PostgreSQL tsquery."""

from __future__ import annotations

import re
from dataclasses import dataclass

STOPWORDS = frozenset(
    """a about above after again all also am an and any are aren't as at be because been before being
    below between both but by can can't cannot could couldn't did didn't do does doesn't doing don't down
    during each few for from further get gets got had has have haven't having he her here hers him his how
    i i'd i'll i'm i've if in into is isn't it it's its just let me more most my no nor not of off on once
    only or other our out over own really same she should so some such than that the their theirs them then
    there these they this those through to too under until up us very was we were what when where which
    while who whom why will with would you your yours yourself tell explain describe give show say said
    says talk talks think thought want need know like make makes using use used one two lenny podcast
    episode episodes guest guests according please can could should would might best way ways thing
    things something anything much many how's what's write writes essay essays word words article articles
    draft create generate compose ship 30 1250 blog post long form markdown html css artifact document turn convert based
    conversation chat above earlier previous""".split()
)

_TOKEN = re.compile(r"[a-z0-9][a-z0-9'\-]*")
_FOLLOWUP_HINT = re.compile(
    r"\b(it|that|this|those|these|they|them|he|she|his|her|their|the same|what about|how about|and for|"
    r"more|another|instead|why|elaborate|expand|example)\b",
    re.I,
)


@dataclass(frozen=True)
class BuiltQuery:
    tsquery: str  # safe to pass as a bound parameter to to_tsquery('english', :q)
    terms: list[str]  # significant single terms
    focus_terms: list[str]  # terms used for the sufficiency check
    condensed_text: str  # human-readable query actually used (for logs / UI)


def significant_terms(text: str) -> list[str]:
    seen: dict[str, None] = {}
    for tok in _TOKEN.findall(text.lower()):
        tok = tok.strip("'-")
        if len(tok) < 2 or tok in STOPWORDS or tok.isdigit():
            continue
        seen.setdefault(tok.replace("'", ""), None)
    return list(seen)


def _parts(term: str) -> list[str]:
    """Split on hyphens/punctuation into tsquery-safe alphanumeric parts ("product-market" -> product, market)."""
    return [p for p in re.split(r"[^a-z0-9]+", term.lower()) if p]


def _lex(term: str) -> str:
    """A tsquery-safe expression for one term. Hyphenated terms become a phrase: (product <-> market)."""
    parts = _parts(term)
    if not parts:
        return ""
    return parts[0] if len(parts) == 1 else "(" + " <-> ".join(parts) + ")"


def _phrases(text: str) -> list[str]:
    """Adjacent significant-token n-grams (no stopword between) become phrase operators."""
    toks = [t.strip("'-") for t in _TOKEN.findall(text.lower())]
    out: list[str] = []
    run: list[str] = []
    for tok in toks + [None]:  # type: ignore[list-item]
        if tok and tok not in STOPWORDS and len(tok) > 1:
            run.extend(_parts(tok))
        else:
            for n in (3, 2):
                for i in range(0, max(0, len(run) - n + 1)):
                    gram = run[i : i + n]
                    if len(gram) == n:
                        out.append("(" + " <-> ".join(gram) + ")")
            run = []
    return list(dict.fromkeys(out))[:6]


def build_query(message: str, previous_user_messages: list[str] | None = None) -> BuiltQuery:
    """Build an OR-of-terms query, boosted with phrases.

    Follow-ups ("what about for B2B?") are condensed deterministically: if the latest message has
    few significant terms or contains anaphora, terms from the previous user turn are appended.
    This avoids an extra LLM round-trip (latency/cost) and is unit-testable.
    """
    own = significant_terms(message)
    # Borrow context only for genuine follow-ups: anaphora ("what about…", "it", "that") or a single bare term.
    # A self-contained 2+ term message stands alone, so nonsense never silently inherits the previous topic.
    use_history = bool(previous_user_messages) and (len(own) < 2 or bool(_FOLLOWUP_HINT.search(message)))
    combined_text = message
    terms = list(own)
    if use_history:
        prev = previous_user_messages[-1]  # type: ignore[index]
        combined_text = f"{prev} {message}"
        for t in significant_terms(prev):
            if t not in terms:
                terms.append(t)
    terms = terms[:14]
    lexemes = [_lex(t) for t in terms if _lex(t)]
    parts = _phrases(combined_text) + lexemes
    tsquery = " | ".join(dict.fromkeys(parts))
    focus = own if len(own) >= 2 else terms
    return BuiltQuery(tsquery=tsquery, terms=terms, focus_terms=focus, condensed_text=combined_text.strip())
