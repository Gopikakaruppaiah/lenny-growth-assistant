"""Artifact skill: produce a Markdown document or a standalone HTML/CSS page, then sanitize it."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

from ..llm.base import ChatTurn, GenerationRequest
from ..rag.citations import validate_citations
from ..rag.retrieval import SourceRef, SourceRegistry
from .prompts import ARTIFACT_HTML_RULES, ARTIFACT_MARKDOWN_RULES, ARTIFACT_SYSTEM, format_excerpts
from .sanitize import sanitize_html_document, sanitize_markdown

ArtifactKind = Literal["markdown", "html"]
_FENCE = re.compile(r"^\s*```[a-zA-Z]*\s*\n(.*?)\n```\s*$", re.S)
_H1 = re.compile(r"^#\s+(.+?)\s*$", re.M)


@dataclass
class ArtifactDraft:
    kind: ArtifactKind
    title: str
    content: str
    report: dict
    warnings: list[str]


def strip_fences(text: str) -> str:
    text = text.strip()
    m = _FENCE.match(text)
    if m:
        return m.group(1).strip()
    # Model wrapped the artifact in prose + fence: take the first fenced block.
    m2 = re.search(r"```(?:html|markdown|md)?\s*\n(.*?)\n```", text, re.S | re.I)
    return m2.group(1).strip() if m2 and len(m2.group(1)) > 80 else text


def build_request(
    kind: ArtifactKind, instruction: str, sources: list[SourceRef], context: str, timeout_s: float
) -> GenerationRequest:
    rules = ARTIFACT_HTML_RULES if kind == "html" else ARTIFACT_MARKDOWN_RULES
    user = (
        f"<excerpts>\n{format_excerpts(sources)}\n</excerpts>\n\n"
        + (f"Conversation so far (context only):\n{context[:2500]}\n\n" if context else "")
        + f"Create this artifact: {instruction}"
    )
    return GenerationRequest(
        system=ARTIFACT_SYSTEM.format(format_rules=rules),
        turns=[ChatTurn("user", user)],
        max_tokens=3500 if kind == "html" else 2200,
        temperature=0.4,
        timeout_s=timeout_s,
    )


def finalize_artifact(kind: ArtifactKind, raw: str, instruction: str, registry: SourceRegistry) -> ArtifactDraft:
    raw = strip_fences(raw)
    fallback_title = instruction.strip().rstrip(".")[:80] or "Artifact"
    warnings: list[str] = []
    if kind == "html":
        doc, title, rep = sanitize_html_document(raw, fallback_title)
        if len(re.sub(r"<[^>]+>", "", doc).strip()) < 40:
            warnings.append("The generated page had almost no visible content after sanitizing.")
        return ArtifactDraft("html", title, doc, rep.as_dict(), warnings)
    cleaned, rep = sanitize_markdown(raw)
    cites = validate_citations(cleaned, registry)
    warnings += [w for w in cites.warnings if "verdict" not in w]
    m = _H1.search(cites.text)
    return ArtifactDraft("markdown", (m.group(1) if m else fallback_title)[:200], cites.text, rep.as_dict(), warnings)
