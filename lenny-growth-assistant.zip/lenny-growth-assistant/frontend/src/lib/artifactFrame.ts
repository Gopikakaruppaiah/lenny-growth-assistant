/**
 * Safe rendering of untrusted, model-generated HTML.
 *
 * Layer 2 + 3 of the defence (layer 1 is server-side sanitisation, see docs/architecture.md):
 *   - the <iframe> uses an EMPTY sandbox attribute: no scripts, no same-origin access (opaque origin),
 *     no forms, no popups, no top navigation, no downloads, no pointer lock;
 *   - the document carries its own CSP: nothing may load from the network at all.
 */
export const IFRAME_SANDBOX = ""; // intentionally empty: every capability is denied

export const ARTIFACT_CSP = [
  "default-src 'none'",
  "img-src data:",
  "style-src 'unsafe-inline'",
  "font-src data:",
  "base-uri 'none'",
  "form-action 'none'",
].join("; ");

const CSP_META = `<meta http-equiv="Content-Security-Policy" content="${ARTIFACT_CSP}">`;
const EXISTING_CSP = /<meta[^>]+http-equiv\s*=\s*["']?content-security-policy["']?[^>]*>/gi;

export function buildSrcDoc(html: string): string {
  const cleaned = html.replace(EXISTING_CSP, "");
  if (/<head[^>]*>/i.test(cleaned)) return cleaned.replace(/<head[^>]*>/i, (m) => `${m}${CSP_META}`);
  return `<!doctype html><html><head><meta charset="utf-8">${CSP_META}</head><body>${cleaned}</body></html>`;
}

/** Turn [n] citation markers into in-page links the markdown renderer can style as chips. */
export function linkifyCitations(md: string): string {
  return md.replace(/\[(\d{1,3})\](?!\()/g, "[$1](#src-$1)");
}

export function safeFileName(title: string, ext: string): string {
  const base = title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "artifact";
  return `${base}.${ext}`;
}

export function download(name: string, content: string, mime: string): void {
  const url = URL.createObjectURL(new Blob([content], { type: mime }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    const ta = document.createElement("textarea");
    ta.value = text;
    ta.style.position = "fixed";
    ta.style.opacity = "0";
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand("copy");
    ta.remove();
    return ok;
  }
}
