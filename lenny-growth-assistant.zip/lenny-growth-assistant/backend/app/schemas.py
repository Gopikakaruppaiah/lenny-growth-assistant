"""Typed request/response contracts."""

from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

ProviderLiteral = Literal["ollama", "anthropic"]


def _clean(v: str) -> str:
    return v.replace("\x00", "").strip()  # NUL bytes are rejected by PostgreSQL text columns


class SessionCreate(BaseModel):
    title: str | None = Field(default=None, max_length=120)

    @field_validator("title")
    @classmethod
    def _t(cls, v: str | None) -> str | None:
        return _clean(v) or None if v else None


class SessionRename(BaseModel):
    title: str = Field(min_length=1, max_length=120)

    @field_validator("title")
    @classmethod
    def _t(cls, v: str) -> str:
        v = _clean(v)
        if not v:
            raise ValueError("title must not be blank")
        return v


class SessionOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: uuid.UUID
    title: str
    created_at: datetime
    updated_at: datetime
    message_count: int = 0


class MessageCreate(BaseModel):
    content: str = Field(min_length=1, max_length=4000)
    provider: ProviderLiteral | None = None
    mode: Literal["auto", "chat"] = "auto"

    @field_validator("content")
    @classmethod
    def _c(cls, v: str) -> str:
        v = _clean(v)
        if not v:
            raise ValueError("message must not be blank")
        return v


class EssayCreate(BaseModel):
    topic: str | None = Field(default=None, max_length=500)
    provider: ProviderLiteral | None = None

    @field_validator("topic")
    @classmethod
    def _t(cls, v: str | None) -> str | None:
        return _clean(v) or None if v else None


class ArtifactCreate(BaseModel):
    kind: Literal["markdown", "html"]
    instruction: str = Field(min_length=3, max_length=1000)
    provider: ProviderLiteral | None = None

    @field_validator("instruction")
    @classmethod
    def _i(cls, v: str) -> str:
        v = _clean(v)
        if len(v) < 3:
            raise ValueError("instruction is too short")
        return v


class ErrorInfo(BaseModel):
    code: str
    message: str
    hint: str | None = None


class ArtifactRef(BaseModel):
    id: uuid.UUID
    kind: Literal["markdown", "html"]
    title: str


class MessageOut(BaseModel):
    id: uuid.UUID
    session_id: uuid.UUID
    role: Literal["user", "assistant"]
    kind: Literal["chat", "essay", "artifact"]
    status: Literal["pending", "complete", "error"]
    content: str
    provider: str | None = None
    model: str | None = None
    fallback_from: str | None = None
    sources: list[dict[str, Any]] = []
    meta: dict[str, Any] = {}
    error: ErrorInfo | None = None
    artifact: ArtifactRef | None = None
    latency_ms: int | None = None
    created_at: datetime
    completed_at: datetime | None = None


class AcceptedOut(BaseModel):
    user_message: MessageOut
    assistant_message: MessageOut
    routed_as: Literal["chat", "essay", "artifact"]


class ArtifactOut(BaseModel):
    id: uuid.UUID
    session_id: uuid.UUID
    message_id: uuid.UUID | None
    kind: Literal["markdown", "html"]
    title: str
    content: str
    provider: str | None
    model: str | None
    sanitizer_report: dict[str, Any]
    created_at: datetime


class ProviderStatusOut(BaseModel):
    name: ProviderLiteral
    model: str
    kind: Literal["local", "cloud"]
    ready: bool
    detail: str
    hint: str | None = None
    agentic: bool = False
    is_default: bool = False
    is_fallback: bool = False


class ProvidersOut(BaseModel):
    default: ProviderLiteral
    fallback: str | None
    providers: list[ProviderStatusOut]


class CorpusStats(BaseModel):
    episodes: int
    chunks: int
    last_ingested_at: datetime | None
    source_repo: str | None
    source_commit: str | None


class HealthOut(BaseModel):
    status: Literal["ok"] = "ok"
    version: str


class ReadyOut(BaseModel):
    status: Literal["ready", "degraded"]
    database: Literal["up", "down"]
    knowledge_base: Literal["indexed", "empty", "unknown"]
    providers: list[ProviderStatusOut]
