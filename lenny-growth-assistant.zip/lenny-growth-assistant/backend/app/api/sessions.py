from __future__ import annotations

import uuid
from typing import Any

from fastapi import APIRouter, Depends, Request, Response
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from ..deps import enforce_rate_limit, get_db, get_user, owned_session
from ..errors import AppError
from ..models import Artifact, ChatSession, Message, User
from ..schemas import (
    AcceptedOut,
    ArtifactCreate,
    ArtifactOut,
    ArtifactRef,
    ErrorInfo,
    EssayCreate,
    MessageCreate,
    MessageOut,
    SessionCreate,
    SessionOut,
    SessionRename,
)
from ..skills.router import route_message

router = APIRouter(tags=["sessions"])


def to_message_out(m: Message, art: Artifact | None = None) -> MessageOut:
    err = ErrorInfo(code=m.error_code, message=m.error_message or "", hint=m.error_hint) if m.error_code else None
    ref = ArtifactRef(id=art.id, kind=art.kind, title=art.title) if art else None  # type: ignore[arg-type]
    meta = {k: v for k, v in (m.meta or {}).items() if k != "params"}
    return MessageOut(id=m.id, session_id=m.session_id, role=m.role, kind=m.kind, status=m.status, content=m.content,  # type: ignore[arg-type]
                      provider=m.provider, model=m.model, fallback_from=m.fallback_from, sources=m.sources or [], meta=meta,
                      error=err, artifact=ref, latency_ms=m.latency_ms, created_at=m.created_at, completed_at=m.completed_at)


async def _artifacts_by_message(db: AsyncSession, ids: list[uuid.UUID]) -> dict[uuid.UUID, Artifact]:
    if not ids:
        return {}
    rows = (await db.execute(select(Artifact).where(Artifact.message_id.in_(ids)))).scalars().all()
    return {a.message_id: a for a in rows if a.message_id}


# ------------------------------------------------------------------ sessions CRUD
@router.post("/sessions", response_model=SessionOut, status_code=201)
async def create_session(body: SessionCreate, user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    s = ChatSession(user_id=user.id, title=body.title or "New chat")
    db.add(s)
    await db.commit()
    await db.refresh(s)
    return SessionOut(id=s.id, title=s.title, created_at=s.created_at, updated_at=s.updated_at, message_count=0)


@router.get("/sessions", response_model=list[SessionOut])
async def list_sessions(user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    rows = (await db.execute(
        select(ChatSession, func.count(Message.id)).outerjoin(Message, Message.session_id == ChatSession.id)
        .where(ChatSession.user_id == user.id).group_by(ChatSession.id).order_by(ChatSession.updated_at.desc()).limit(100)
    )).all()
    return [SessionOut(id=s.id, title=s.title, created_at=s.created_at, updated_at=s.updated_at, message_count=n) for s, n in rows]


@router.get("/sessions/{session_id}", response_model=SessionOut)
async def get_session(session_id: uuid.UUID, user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    s = await owned_session(session_id, user, db)
    n = (await db.execute(select(func.count()).select_from(Message).where(Message.session_id == s.id))).scalar_one()
    return SessionOut(id=s.id, title=s.title, created_at=s.created_at, updated_at=s.updated_at, message_count=n)


@router.patch("/sessions/{session_id}", response_model=SessionOut)
async def rename_session(session_id: uuid.UUID, body: SessionRename, user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    s = await owned_session(session_id, user, db)
    s.title = body.title
    await db.commit()
    return SessionOut(id=s.id, title=s.title, created_at=s.created_at, updated_at=s.updated_at)


@router.delete("/sessions/{session_id}", status_code=204)
async def delete_session(session_id: uuid.UUID, request: Request, user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    s = await owned_session(session_id, user, db)
    running = (await db.execute(select(Message.id).where(Message.session_id == s.id, Message.status == "pending"))).scalars().all()
    for mid in running:
        t = request.app.state.jobs._tasks.get(str(mid))
        if t:
            t.cancel()
    await db.delete(s)
    await db.commit()
    return Response(status_code=204)


# ------------------------------------------------------------------ messages
@router.get("/sessions/{session_id}/messages", response_model=list[MessageOut])
async def list_messages(session_id: uuid.UUID, user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    s = await owned_session(session_id, user, db)
    msgs = (await db.execute(select(Message).where(Message.session_id == s.id).order_by(Message.created_at, Message.role.desc()))).scalars().all()
    arts = await _artifacts_by_message(db, [m.id for m in msgs if m.kind == "artifact"])
    return [to_message_out(m, arts.get(m.id)) for m in msgs]


@router.get("/sessions/{session_id}/messages/{message_id}", response_model=MessageOut)
async def get_message(session_id: uuid.UUID, message_id: uuid.UUID, request: Request, user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    s = await owned_session(session_id, user, db)
    m = (await db.execute(select(Message).where(Message.id == message_id, Message.session_id == s.id))).scalar_one_or_none()
    if m is None:
        raise AppError(404, "message_not_found", "Message not found.")
    # Lazy reaper: a pending message with no live task and well past the timeout was orphaned.
    cfg = request.app.state.settings
    age = (await db.execute(select(func.extract("epoch", func.now() - m.created_at)))).scalar_one()
    if m.status == "pending" and not request.app.state.jobs.is_running(str(m.id)) and age > cfg.essay_total_timeout_seconds + 60:
        m.status, m.error_code, m.error_message, m.error_hint = "error", "interrupted", "This generation was interrupted.", "Press Retry."
        await db.commit()
    arts = await _artifacts_by_message(db, [m.id]) if m.kind == "artifact" else {}
    return to_message_out(m, arts.get(m.id))


async def _accept(request: Request, db: AsyncSession, s: ChatSession, text_: str, kind: str, provider: str | None, params: dict[str, Any]) -> AcceptedOut:
    svc = request.app.state.chat
    params = {**params, "provider": provider}
    user_msg, asst = await svc.create_pair(db, s, text_, kind, params)
    svc.start(asst, user_msg, kind, provider, params)
    return AcceptedOut(user_message=to_message_out(user_msg), assistant_message=to_message_out(asst), routed_as=kind)  # type: ignore[arg-type]


@router.post("/sessions/{session_id}/messages", response_model=AcceptedOut, status_code=202)
async def send_message(session_id: uuid.UUID, body: MessageCreate, request: Request, user: User = Depends(enforce_rate_limit), db: AsyncSession = Depends(get_db)):
    """Queue a reply. Poll GET .../messages/{assistant_message.id} until status != 'pending'."""
    s = await owned_session(session_id, user, db)
    route = route_message(body.content) if body.mode == "auto" else None
    if route and route.intent == "essay":
        return await _accept(request, db, s, body.content, "essay", body.provider, {"topic": None})
    if route and route.intent == "artifact":
        return await _accept(request, db, s, body.content, "artifact", body.provider, {"kind": route.artifact_kind, "instruction": body.content})
    return await _accept(request, db, s, body.content, "chat", body.provider, {})


@router.post("/sessions/{session_id}/essay", response_model=AcceptedOut, status_code=202)
async def create_essay(session_id: uuid.UUID, body: EssayCreate, request: Request, user: User = Depends(enforce_rate_limit), db: AsyncSession = Depends(get_db)):
    """Run the Ship 30 for 30 skill on `topic`, or on the last question in this chat if omitted."""
    s = await owned_session(session_id, user, db)
    topic = body.topic
    if not topic:
        topic = (await db.execute(select(Message.content).where(Message.session_id == s.id, Message.role == "user", Message.kind == "chat")
                                  .order_by(Message.created_at.desc()).limit(1))).scalar_one_or_none()
    if not topic:
        raise AppError(422, "topic_required", "There is nothing to write about yet.", "Ask a question first, or provide a topic.")
    label = f"Write a Ship 30 essay: {topic}"
    return await _accept(request, db, s, label[:4000], "essay", body.provider, {"topic": topic})


@router.post("/sessions/{session_id}/artifacts", response_model=AcceptedOut, status_code=202)
async def create_artifact(session_id: uuid.UUID, body: ArtifactCreate, request: Request, user: User = Depends(enforce_rate_limit), db: AsyncSession = Depends(get_db)):
    s = await owned_session(session_id, user, db)
    label = f"Create a {body.kind} artifact: {body.instruction}"
    return await _accept(request, db, s, label[:4000], "artifact", body.provider, {"kind": body.kind, "instruction": body.instruction})


@router.post("/sessions/{session_id}/messages/{message_id}/retry", response_model=MessageOut, status_code=202)
async def retry_message(session_id: uuid.UUID, message_id: uuid.UUID, request: Request, user: User = Depends(enforce_rate_limit), db: AsyncSession = Depends(get_db)):
    s = await owned_session(session_id, user, db)
    m = (await db.execute(select(Message).where(Message.id == message_id, Message.session_id == s.id))).scalar_one_or_none()
    if m is None:
        raise AppError(404, "message_not_found", "Message not found.")
    m = await request.app.state.chat.retry(db, s, m)
    return to_message_out(m)


# ------------------------------------------------------------------ artifacts
@router.get("/sessions/{session_id}/artifacts", response_model=list[ArtifactRef])
async def list_artifacts(session_id: uuid.UUID, user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    s = await owned_session(session_id, user, db)
    rows = (await db.execute(select(Artifact).where(Artifact.session_id == s.id).order_by(Artifact.created_at.desc()))).scalars().all()
    return [ArtifactRef(id=a.id, kind=a.kind, title=a.title) for a in rows]  # type: ignore[arg-type]


@router.get("/artifacts/{artifact_id}", response_model=ArtifactOut)
async def get_artifact(artifact_id: uuid.UUID, user: User = Depends(get_user), db: AsyncSession = Depends(get_db)):
    a = (await db.execute(select(Artifact).join(ChatSession, ChatSession.id == Artifact.session_id)
                          .where(Artifact.id == artifact_id, ChatSession.user_id == user.id))).scalar_one_or_none()
    if a is None:
        raise AppError(404, "artifact_not_found", "Artifact not found.")
    return ArtifactOut(id=a.id, session_id=a.session_id, message_id=a.message_id, kind=a.kind, title=a.title, content=a.content,  # type: ignore[arg-type]
                       provider=a.provider, model=a.model, sanitizer_report=a.sanitizer_report, created_at=a.created_at)
