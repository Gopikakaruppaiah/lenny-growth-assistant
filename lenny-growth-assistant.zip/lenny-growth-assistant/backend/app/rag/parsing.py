"""Parse a transcript file from the ChatPRD/lennys-podcast-transcripts repository.

Three turn layouts exist in the source repo (verified by scanning all 303 files:
301 use A, 1 uses B, 1 uses C). Frontmatter is YAML between ``---`` fences, followed by
a ``# Title`` heading and a ``## Transcript`` heading.

A (primary)::

    Brian Chesky (00:00:00):
    text...

    (00:01:27):            <- same speaker continues; name omitted
    text...

B (inline)::   [00:00:28] Lenny: text...
C (untimed)::  Adriel Frederick:\n text...      (no timestamps -> no deep-link time)
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

import yaml

_TS = r"(?:\d{1,2}:)?\d{1,2}:\d{2}"
_TURN_A = re.compile(rf"^(?:(?P<speaker>[^\n()]{{1,120}}?)\s+)?\((?P<ts>{_TS})\):\s*$")
_TURN_B = re.compile(rf"^\[(?P<ts>{_TS})\]\s+(?P<speaker>[^:\n]{{1,80}}):\s*(?P<text>.*)$")
_TURN_C = re.compile(r"^(?P<speaker>[A-Z][^\n:()\[\]]{1,60}):\s*$")
_FRONTMATTER_RE = re.compile(r"\A---\s*\n(.*?)\n(?:---|\.\.\.)\s*\n", re.DOTALL)


@dataclass
class Turn:
    speaker: str
    start_seconds: int | None
    text: str


@dataclass
class ParsedTranscript:
    meta: dict[str, Any]
    turns: list[Turn] = field(default_factory=list)


class TranscriptParseError(ValueError):
    pass


def ts_to_seconds(ts: str) -> int:
    parts = [int(p) for p in ts.split(":")]
    while len(parts) < 3:
        parts.insert(0, 0)
    h, m, s = parts
    return h * 3600 + m * 60 + s


def _coerce_date(value: Any) -> date | None:
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if isinstance(value, str):
        try:
            return date.fromisoformat(value.strip()[:10])
        except ValueError:
            return None
    return None


def parse_transcript(raw: str) -> ParsedTranscript:
    match = _FRONTMATTER_RE.match(raw)
    if not match:
        raise TranscriptParseError("missing YAML frontmatter")
    try:
        meta = yaml.safe_load(match.group(1)) or {}
    except yaml.YAMLError as exc:  # pragma: no cover - defensive
        raise TranscriptParseError(f"invalid frontmatter: {exc}") from exc
    if not isinstance(meta, dict):
        raise TranscriptParseError("frontmatter is not a mapping")
    meta["publish_date"] = _coerce_date(meta.get("publish_date"))

    body = raw[match.end() :]
    marker = re.search(r"^##\s+Transcript\s*$", body, re.MULTILINE)
    if marker:
        body = body[marker.end() :]

    lines = [ln.strip() for ln in body.splitlines()]
    counts = {
        "A": sum(1 for ln in lines if _TURN_A.match(ln)),
        "B": sum(1 for ln in lines if _TURN_B.match(ln)),
        "C": sum(1 for ln in lines if _TURN_C.match(ln)),
    }
    # Prefer A, then B; C is only trusted when neither timed layout is present, because a
    # stray "Note:" line in a type-A file must not be mistaken for a speaker header.
    layout = "A" if counts["A"] >= 3 else "B" if counts["B"] >= 3 else "C" if counts["C"] >= 3 else None
    if layout is None:
        raise TranscriptParseError("no speaker turns found")
    pattern = {"A": _TURN_A, "B": _TURN_B, "C": _TURN_C}[layout]

    turns: list[Turn] = []
    speaker = "Unknown"
    ts: int | None = None
    buf: list[str] = []
    open_turn = False

    def flush() -> None:
        nonlocal buf, open_turn
        if open_turn:
            text = " ".join(x for x in buf if x).strip()
            if text:
                turns.append(Turn(speaker, ts, text))
        buf, open_turn = [], False

    for ln in lines:
        m = pattern.match(ln)
        if m:
            flush()
            groups = m.groupdict()
            if groups.get("speaker"):
                speaker = groups["speaker"].strip()
            ts = ts_to_seconds(groups["ts"]) if groups.get("ts") else None
            open_turn = True
            if groups.get("text"):
                buf.append(groups["text"].strip())
        elif open_turn:
            buf.append(ln)
    flush()

    if not turns:
        raise TranscriptParseError("no speaker turns found")
    return ParsedTranscript(meta=meta, turns=turns)
