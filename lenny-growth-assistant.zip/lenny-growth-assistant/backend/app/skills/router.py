"""Deterministic intent router. Rules (not an LLM call) so routing is instant, free, and testable."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Literal

Intent = Literal["chat", "essay", "artifact"]

_WRITE = r"(?:write|draft|turn|convert|generate|create|compose|produce)"
_ESSAY = re.compile(
    rf"\b{_WRITE}\b[^.?!]{{0,60}}\b(?:essay|ship\s*30|atomic essay|long[- ]form (?:post|article)|article|blog ?post)\b"
    r"|\bship\s*30\b|\b1,?250[- ]word\b",
    re.I,
)
_ARTIFACT = re.compile(
    r"\b(?:create|make|build|generate|draft|design|produce|write)\b[^.?!]{0,60}\b(?:an?\s+)?"
    r"(?:html|css|markdown|landing page|web ?page|one[- ]pager|cheat ?sheet|checklist|template|"
    r"dashboard|infographic|poster|brief|framework doc|playbook doc|artifact|document|memo)\b",
    re.I,
)
_HTML_HINT = re.compile(r"\b(html|css|landing page|web ?page|dashboard|infographic|poster|styled|visual)\b", re.I)


@dataclass(frozen=True)
class Route:
    intent: Intent
    artifact_kind: Literal["markdown", "html"] | None = None


def route_message(text: str) -> Route:
    if _ESSAY.search(text):
        return Route("essay")
    if _ARTIFACT.search(text):
        return Route("artifact", "html" if _HTML_HINT.search(text) else "markdown")
    return Route("chat")
