import { vi } from "vitest";
import { render, screen, waitFor, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { describe, expect, it } from "vitest";
import App from "./App";
import { SID, mockApi, msg, providers, session, source } from "./test/fixtures";

const stats = { episodes: 303, chunks: 19038, last_ingested_at: null, source_repo: "r", source_commit: "be8ab89a89" };
const base = { "GET /providers": () => providers, "GET /sources/stats": () => stats };

describe("App integration (real components, mocked HTTP)", () => {
  it("shows the empty state with live corpus stats and the provider indicator", async () => {
    mockApi({ ...base, "GET /sessions": () => [] });
    render(<App />);
    expect(await screen.findByRole("heading", { name: /ask a product or growth question/i })).toBeInTheDocument();
    expect(await screen.findByText(/303 episodes/)).toBeInTheDocument();
    expect(await screen.findByRole("button", { name: /ollama · local/i })).toBeInTheDocument();
    expect(screen.getByText(/no chats yet/i)).toBeInTheDocument();
  });

  it("warns when the knowledge base is empty", async () => {
    mockApi({ ...base, "GET /sources/stats": () => ({ ...stats, episodes: 0, chunks: 0 }), "GET /sessions": () => [] });
    render(<App />);
    expect(await screen.findByText(/knowledge base is empty/i)).toBeInTheDocument();
  });

  it("creates a session on first send, polls, and renders a cited answer with provider badge", async () => {
    const pending = msg({ id: "a1", status: "pending", provider: null, model: null, latency_ms: null, completed_at: null });
    const done = msg({
      id: "a1", content: "Activation drives retention [1].", sources: [source], meta: { grounded: true, verdict: "SUPPORTED" },
    });
    const { calls } = mockApi({
      ...base,
      "GET /sessions": () => [],
      "POST /sessions": () => session(),
      [`POST /sessions/${SID}/messages`]: () => ({ routed_as: "chat", user_message: msg({ role: "user", content: "What is activation?", provider: null, model: null }), assistant_message: pending }),
      [`GET /sessions/${SID}/messages/a1`]: () => done,
      [`GET /sessions/${SID}/messages`]: () => [],
    });
    render(<App />);
    await userEvent.type(await screen.findByLabelText("Message"), "What is activation?");
    await userEvent.click(screen.getByRole("button", { name: "Send" }));

    expect(await screen.findByText("What is activation?")).toBeInTheDocument();
    expect(await screen.findByText(/searching transcripts/i)).toBeInTheDocument(); // loading state
    expect(await screen.findByText(/activation drives retention/i, {}, { timeout: 4000 })).toBeInTheDocument();
    expect(screen.getByText(/Ollama \(local\) · llama3.2:3b/)).toBeInTheDocument();
    expect(screen.getByText(/Grounded · 1 cited/)).toBeInTheDocument();
    expect(screen.getByText("Test Guest Alpha")).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /watch at 1:00/i })).toHaveAttribute("href", expect.stringContaining("&t=60s"));
    const order = calls.map((c) => c.key);
    expect(order.indexOf("POST /sessions")).toBeLessThan(order.indexOf(`POST /sessions/${SID}/messages`));
  });

  it("clicking a citation chip opens that source", async () => {
    mockApi({
      ...base, "GET /sessions": () => [session({ title: "Chat A" })],
      [`GET /sessions/${SID}/messages`]: () => [msg({ role: "user", content: "q", provider: null }), msg({ id: "a1", content: "Claim [1].", sources: [source], meta: { grounded: true } })],
    });
    render(<App />);
    await userEvent.click(await screen.findByRole("button", { name: /^chat a/i }));
    await userEvent.click(await screen.findByRole("button", { name: /show source 1/i }));
    expect(await screen.findByText(/Activation is the moment a user first experiences value/)).toBeVisible();
  });

  it("shows a fallback notice instead of pretending the primary answered", async () => {
    mockApi({
      ...base, "GET /sessions": () => [session({ title: "Chat A" })],
      [`GET /sessions/${SID}/messages`]: () => [
        msg({ role: "user", content: "q", provider: null }),
        msg({ id: "a1", content: "ok [1]", sources: [source], provider: "ollama", fallback_from: "anthropic", meta: { grounded: true } }),
      ],
    });
    render(<App />);
    await userEvent.click(await screen.findByRole("button", { name: /^chat a/i }));
    expect(await screen.findByText(/Ollama \(local\) · llama3.2:3b/)).toBeInTheDocument();
    expect(screen.getByText(/Fallback — Claude \(cloud\) was unavailable/)).toBeInTheDocument();
  });

  it("says plainly when no model was used because nothing was retrieved", async () => {
    mockApi({
      ...base, "GET /sessions": () => [session({ title: "Chat A" })],
      [`GET /sessions/${SID}/messages`]: () => [
        msg({ role: "user", content: "zzz", provider: null }),
        msg({ id: "a1", content: "I couldn't find enough in Lenny's Podcast transcripts to answer that.", provider: null, model: null, meta: { grounded: false, model_called: false } }),
      ],
    });
    render(<App />);
    await userEvent.click(await screen.findByRole("button", { name: /^chat a/i }));
    expect(await screen.findByText("No model used")).toBeInTheDocument();
    expect(screen.getByText(/Not grounded in transcripts/)).toBeInTheDocument();
  });

  it("shows model errors with a hint and Retry, and retry re-polls to success", async () => {
    let retried = false;
    mockApi({
      ...base, "GET /sessions": () => [session({ title: "Chat A" })],
      [`GET /sessions/${SID}/messages`]: () => [msg({ role: "user", content: "q", provider: null }),
        msg({ id: "a1", status: "error", content: "", provider: null, model: null, error: { code: "provider_unavailable", message: "Ollama is not reachable at http://localhost:11434.", hint: "Start it with `ollama serve`." } })],
      [`POST /sessions/${SID}/messages/a1/retry`]: () => { retried = true; return msg({ id: "a1", status: "pending", provider: null, model: null }); },
      [`GET /sessions/${SID}/messages/a1`]: () => msg({ id: "a1", content: "Recovered [1].", sources: [source], meta: { grounded: true } }),
    });
    render(<App />);
    await userEvent.click(await screen.findByRole("button", { name: /^chat a/i }));
    const alert = await screen.findByRole("alert");
    expect(alert).toHaveTextContent("Ollama is not reachable");
    expect(alert).toHaveTextContent("ollama serve");
    await userEvent.click(within(alert).getByRole("button", { name: "Retry" }));
    expect(retried).toBe(true);
    expect(await screen.findByText(/recovered/i, {}, { timeout: 4000 })).toBeInTheDocument();
  });

  it("shows an actionable banner when the API is unreachable", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => { throw new TypeError("Failed to fetch"); }));
    render(<App />);
    expect(await screen.findByRole("alert")).toHaveTextContent(/can't reach the api/i);
    expect(screen.getByText(/api unreachable/i)).toBeInTheDocument();
  });

  it("disables sending while a reply is pending (one generation per chat)", async () => {
    mockApi({
      ...base, "GET /sessions": () => [session({ title: "Chat A" })],
      [`GET /sessions/${SID}/messages`]: () => [msg({ role: "user", content: "q", provider: null }), msg({ id: "a1", status: "pending", provider: null, model: null })],
      [`GET /sessions/${SID}/messages/a1`]: () => msg({ id: "a1", status: "pending", provider: null }),
    });
    render(<App />);
    await userEvent.click(await screen.findByRole("button", { name: /^chat a/i }));
    expect(await screen.findByRole("button", { name: "Working…" })).toBeDisabled();
    expect(screen.getByRole("button", { name: /write essay/i })).toBeDisabled();
  });

  it("generates an artifact from the dialog and opens it in the viewer", async () => {
    const art = { id: "art1", session_id: SID, message_id: "a2", kind: "html", title: "One-pager", provider: "ollama", model: "m", sanitizer_report: {}, created_at: "", content: "<!doctype html><html><head><title>One-pager</title></head><body><p>x</p></body></html>" };
    const { calls } = mockApi({
      ...base, "GET /sessions": () => [session({ title: "Chat A" })],
      [`GET /sessions/${SID}/messages`]: () => [msg({ role: "user", content: "How do I improve onboarding?", provider: null }), msg({ content: "Answer [1]", sources: [source], meta: { grounded: true } })],
      [`POST /sessions/${SID}/artifacts`]: () => ({ routed_as: "artifact", user_message: msg({ role: "user", kind: "chat", content: "Create a html artifact", provider: null }), assistant_message: msg({ id: "a2", kind: "artifact", status: "pending", provider: null, model: null }) }),
      [`GET /sessions/${SID}/messages/a2`]: () => msg({ id: "a2", kind: "artifact", content: "Created a html artifact: **One-pager**.", sources: [source], artifact: { id: "art1", kind: "html", title: "One-pager" } }),
      "GET /artifacts/art1": () => art,
    });
    render(<App />);
    await userEvent.click(await screen.findByRole("button", { name: /^chat a/i }));
    await userEvent.click(await screen.findByRole("button", { name: /create artifact/i }));
    const dialog = await screen.findByRole("dialog");
    await userEvent.click(within(dialog).getByLabelText(/html \/ css page/i));
    await userEvent.click(within(dialog).getByRole("button", { name: "Generate" }));
    expect(await screen.findByTitle(/preview of one-pager/i, {}, { timeout: 5000 })).toBeInTheDocument();
    const body = JSON.parse(String(calls.find((c) => c.key.endsWith("/artifacts"))!.init.body));
    expect(body).toMatchObject({ kind: "html", instruction: "How do I improve onboarding?" });
  });

  it("persists the chosen provider and sends it with requests", async () => {
    const { calls } = mockApi({
      ...base, "GET /sessions": () => [],
      "POST /sessions": () => session(),
      [`POST /sessions/${SID}/messages`]: () => ({ routed_as: "chat", user_message: msg({ role: "user", provider: null, content: "hi there" }), assistant_message: msg({ id: "a1", status: "pending", provider: null }) }),
      [`GET /sessions/${SID}/messages`]: () => [], [`GET /sessions/${SID}/messages/a1`]: () => msg({ id: "a1", status: "pending", provider: null }),
    });
    render(<App />);
    await userEvent.click(await screen.findByRole("button", { name: /ollama · local/i }));
    await userEvent.click(screen.getByRole("menuitemradio", { name: /claude \(cloud\)/i }));
    expect(localStorage.getItem("lga.provider")).toBe("anthropic");
    await userEvent.type(screen.getByLabelText("Message"), "hi there{enter}");
    await waitFor(() => expect(calls.some((c) => c.key.endsWith("/messages") && c.init.method === "POST")).toBe(true));
    const sent = JSON.parse(String(calls.find((c) => c.key.endsWith("/messages") && c.init.method === "POST")!.init.body));
    expect(sent.provider).toBe("anthropic");
  });

  it("New chat clears the conversation without deleting history", async () => {
    mockApi({
      ...base, "GET /sessions": () => [session({ title: "Chat A" })],
      [`GET /sessions/${SID}/messages`]: () => [msg({ role: "user", content: "old question", provider: null }), msg({ content: "old answer" })],
    });
    render(<App />);
    await userEvent.click(await screen.findByRole("button", { name: /^chat a/i }));
    expect(await screen.findByText("old answer")).toBeInTheDocument();
    await userEvent.click(screen.getAllByRole("button", { name: /new chat/i })[0]);
    expect(await screen.findByRole("heading", { name: /ask a product or growth question/i })).toBeInTheDocument();
    expect(screen.queryByText("old answer")).toBeNull();
    expect(screen.getByRole("button", { name: /^chat a/i })).toBeInTheDocument();
  });
});
