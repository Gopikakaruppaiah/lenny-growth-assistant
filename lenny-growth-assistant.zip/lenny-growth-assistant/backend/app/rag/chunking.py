"""Speaker-turn-aware chunking with timestamps so every chunk can be deep-linked."""

from __future__ import annotations

import re
from dataclasses import dataclass

from .parsing import Turn

_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")


@dataclass
class Chunk:
    index: int
    start_seconds: int | None
    end_seconds: int | None
    speakers: list[str]
    text: str
    word_count: int


def _wc(s: str) -> int:
    return len(s.split())


def _split_long_turn(turn: Turn, max_words: int) -> list[Turn]:
    if _wc(turn.text) <= max_words:
        return [turn]
    out: list[Turn] = []
    buf: list[str] = []
    n = 0
    for sent in _SENT_SPLIT.split(turn.text):
        w = _wc(sent)
        if buf and n + w > max_words:
            out.append(Turn(turn.speaker, turn.start_seconds, " ".join(buf)))
            buf, n = [], 0
        buf.append(sent)
        n += w
    if buf:
        out.append(Turn(turn.speaker, turn.start_seconds, " ".join(buf)))
    return out


def chunk_turns(turns: list[Turn], target_words: int = 300, overlap_words: int = 40) -> list[Chunk]:
    """Greedy-pack turns into ~``target_words`` chunks; carry one trailing turn as overlap."""
    if target_words <= 0:
        raise ValueError("target_words must be positive")
    pieces: list[Turn] = []
    for t in turns:
        pieces.extend(_split_long_turn(t, int(target_words * 1.25)))

    chunks: list[Chunk] = []
    cur: list[Turn] = []
    cur_words = 0

    def emit() -> None:
        if not cur:
            return
        text = "\n".join(f"{t.speaker}: {t.text}" for t in cur)
        speakers = list(dict.fromkeys(t.speaker for t in cur))
        stamps = [t.start_seconds for t in cur if t.start_seconds is not None]
        chunks.append(
            Chunk(
                index=len(chunks),
                start_seconds=stamps[0] if stamps else None,
                end_seconds=stamps[-1] if stamps else None,
                speakers=speakers,
                text=text,
                word_count=_wc(text),
            )
        )

    for piece in pieces:
        w = _wc(piece.text)
        if cur and cur_words + w > target_words:
            emit()
            tail = cur[-1]
            keep = [tail] if _wc(tail.text) <= overlap_words else []
            cur = list(keep)
            cur_words = sum(_wc(t.text) for t in cur)
        cur.append(piece)
        cur_words += w
    # Avoid a tiny orphan tail chunk: merge into previous if very short.
    if cur and cur_words >= max(30, target_words // 5) or not chunks:
        emit()
    elif cur and chunks:
        prev = chunks[-1]
        extra = "\n".join(f"{t.speaker}: {t.text}" for t in cur)
        prev.text += "\n" + extra
        tail_stamps = [t.start_seconds for t in cur if t.start_seconds is not None]
        prev.end_seconds = tail_stamps[-1] if tail_stamps else prev.end_seconds
        prev.word_count = _wc(prev.text)
        prev.speakers = list(dict.fromkeys(prev.speakers + [t.speaker for t in cur]))
    return chunks
